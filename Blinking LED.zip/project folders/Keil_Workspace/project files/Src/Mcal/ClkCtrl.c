


#include "ClkCtrl.h"




void ClkCtrl_Init(void)
{
	
	while(PLLSTAT->data)
		;
#if (SYSTEM_CLOCK_SOURCE>EXTERNAL_MAIN_OSCILLATOR_25MHZ_USB)
{
	
	#if (SYSTEM_CLOCK_SOURCE==PLL_400MHZ)
	{
	     #if (USB_SYSTEM_CLOCK_SOURCE==MAIN_OSCILLATOR_PER_8)
	     {
	         
        	RCC2->data=(0X80006800|(SYSTEM_CLOCK_DIVISOR-1)<<23|SYSTEM_CLOCK_SOURCE);
           
	     }
	     #else
	     {
			    
	        RCC2->data=(0X80002800|(SYSTEM_CLOCK_DIVISOR-1)<<23|SYSTEM_CLOCK_SOURCE);
           
		      
	        
	     }
	     #endif
	     
  }
	#else
	{
	     #if (USB_CLOCK_SOURCE==MAIN_OSCILLATOR_PER_8)
	     {
			  
	         RCC2->data=((SYSTEM_CLOCK_SOURCE-0X1A0)|0X80004000|(SYSTEM_CLOCK_DIVISOR-1)<<22);
            
        	
	     }
	     #else
	     {
			  
	         RCC2->data=((SYSTEM_CLOCK_SOURCE-0X1A0)|0X80000000|(SYSTEM_CLOCK_DIVISOR-1)<<22);
            
		      
	        
	     }
	     #endif
	     
	}
	#endif
	RCC->data=0X400001|PWM_CLOCK_SOURCE|PWM_CLOCK_DIVISOR;
 }
#else
{
	  
	#if (SYSTEM_CLOCK_SOURCE==PLL_200MHZ)
	{
	     #if (USB_CLOCK_SOURCE==MAIN_OSCILLATOR_PER_8)
	     {
		 
	         RCC2->data=(0X80006800|(SYSTEM_CLOCK_DIVISOR-1)<<23); 
            
        	
	     }
	     #else
	     {
				 
	         RCC2->data=(0X80002800|(SYSTEM_CLOCK_DIVISOR-1)<<23);
            
		      
	        
	     }
	     #endif
	     
  }
	#else
	{
	     #if (USB_SYSTEM_CLOCK_SOURCE==MAIN_OSCILLATOR_PER_8)
	     {
	      
	         RCC2->data=(0X80004000|(SYSTEM_CLOCK_DIVISOR-1)<<22|SYSTEM_CLOCK_SOURCE);
           
        	
	     }
	     #else
	     {
	        
	         RCC2->data=(0X80000000|(SYSTEM_CLOCK_DIVISOR-1)<<22|SYSTEM_CLOCK_SOURCE);
           
		      
	        
	     }
	     #endif
	     
	}
	#endif
	RCC->data=0x400000|PWM_CLOCK_SOURCE|PWM_CLOCK_DIVISOR|SYSTEM_CLOCK_SOURCE;
}

#endif

  #if (UART0_BAUD_CLOCK_SOURCE==_16MHZ )
  UART0_UARTCC->data=1;
  #else
  UART0_UARTCC->data=0;
  #endif
#if (UART1_BAUD_CLOCK_SOURCE==_16MHZ )
  UART1_UARTCC->data=1;
  #else
  UART1_UARTCC->data=0;
  #endif
#if (UART2_BAUD_CLOCK_SOURCE==_16MHZ )
  UART2_UARTCC->data=1;
  #else
  UART2_UARTCC->data=0;
  #endif
#if (UART3_BAUD_CLOCK_SOURCE==_16MHZ )
  UART3_UARTCC->data=1;
  #else
  UART3_UARTCC->data=0;
  #endif
#if (UART4_BAUD_CLOCK_SOURCE==_16MHZ )
  UART4_UARTCC->data=1;
  #else
  UART4_UARTCC->data=0;
  #endif
	#if (UART5_BAUD_CLOCK_SOURCE==_16MHZ )
  UART5_UARTCC->data=1;
  #else
  UART5_UARTCC->data=0;
  #endif
	#if (UART6_BAUD_CLOCK_SOURCE==_16MHZ )
  UART6_UARTCC->data=1;
  #else
  UART6_UARTCC->data=0;
  #endif
	#if (UART7_BAUD_CLOCK_SOURCE==_16MHZ )
  UART7_UARTCC->data=1;
  #else
  UART7_UARTCC->data=0;
  #endif
	
	
	//----------------
	
  #if (SSI0_BAUD_CLOCK_SOURCE==INTERNAL_OSCILLATOR_16MHZ )
  SSI0_SSICC->data=1;
  #else
	SSI0_SSICC->data=0;
  #endif
	
	
	#if (SSI1_BAUD_CLOCK_SOURCE==INTERNAL_OSCILLATOR_16MHZ )
  SSI1_SSICC->data=1;
  #else
	SSI1_SSICC->data=0;
  #endif
	
	
	#if (SSI2_BAUD_CLOCK_SOURCE==INTERNAL_OSCILLATOR_16MHZ )
  SSI2_SSICC->data=1;
  #else
	SSI2_SSICC->data=0;
  #endif
	
	
	#if (SSI3_BAUD_CLOCK_SOURCE==INTERNAL_OSCILLATOR_16MHZ )
  SSI3_SSICC->data=1;
  #else
	SSI3_SSICC->data=0;
  #endif
	
	
	//----------------
	
	
	
  #if (ADC0_CLOCK_SOURCE==_16MHZ )
	    #if(SYSTEM_CLOCK_SOURCE==PLL_200MHZ||SYSTEM_CLOCK_SOURCE==PLL_400MHZ)
	
      ADC0_ADCCC->data=1;
	
	    #else
			ADC0_ADCCC->data=0;
	    #endif
  #else
	ADC0_ADCCC->data=0;
  #endif
	
	
	#if (ADC1_CLOCK_SOURCE==_16MHZ )
  #if(SYSTEM_CLOCK_SOURCE==PLL_200MHZ||SYSTEM_CLOCK_SOURCE==PLL_400MHZ)
	
      ADC1_ADCCC->data=1;
	
	    #else
			ADC1_ADCCC->data=0;
	    #endif
  #else
	ADC1_ADCCC->data=0;
  #endif
 


	
}
