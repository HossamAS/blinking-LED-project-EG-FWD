/*
 * Port.c
 *
 * Created: 
 *  Author: hossam
 */ 
 #include "Mcu_Hw.h"
#include "Port.h"
#include "string.h"
void Port_Init(const Port_Config* ConfigPtr)
{

switch(ConfigPtr->Port)
	{case PortA:
		GPIOHBCTL->data=GPIOHBCTL->data|1<<PortA;
		RCGCGPIO->data=RCGCGPIO->data|1<<PortA;
		GPIO_PORT_A_AHB_GPIOLOCK->data=0x4C4F434B;
	
		switch(ConfigPtr->PinType.PortA_Pins)
		{
			case PortA_Pin0:
				   GPIODIR_A_AHB_BIT0_ALIAS->data=ConfigPtr->PinDirection;
			     GPIODEN_A_AHB_BIT0_ALIAS->data=1;	
			switch(ConfigPtr->PinMode.PortA.A0)
			{
				case DIO_A0:				
				  GPIOAFSEL_A_AHB_BIT0_ALIAS->data=0;
					break;
				case U0Rx:
				case CAN1Rx:
					GPIOAFSEL_A_AHB_BIT0_ALIAS->data=1;
					GPIO_PORT_A_AHB_GPIOPCTL->data=GPIO_PORT_A_AHB_GPIOPCTL->data&(((UINT32_L)(ConfigPtr->PinMode.PortA.A0))|0XFFFFFFF0);
					
				break;
/*				case U0Rx:
					GPIOAFSEL_A_AHB_BIT0_ALIAS->data=1;
				GPIOPCTL_A_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_A_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT3_ALIAS->data=0;
					break;
				case CAN1Rx:
					GPIOAFSEL_A_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT0_ALIAS->data=0;
			    GPIOPCTL_A_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT3_ALIAS->data=1;
				break;*/
			 }
					
					
				
			switch(ConfigPtr->OutputCurrent.PortA_OutputCurrent.Pin0OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_A_AHB_BIT0_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_A_AHB_BIT0_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_A_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
  
			switch(ConfigPtr->InternalAttach.PortA_InternalAttach.Pin0InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_A_AHB_BIT0_ALIAS->data=0;
					 GPIOPDR_A_AHB_BIT0_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_A_AHB_BIT0_ALIAS->data=0;
					 GPIOPUR_A_AHB_BIT0_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_A_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
			 
				GPIODATA_A_AHB_BIT0_ALIAS->data=ConfigPtr->PinLevel;
			 
				break;
			case PortA_Pin1:
				   GPIODIR_A_AHB_BIT1_ALIAS->data=ConfigPtr->PinDirection;
			     GPIODEN_A_AHB_BIT1_ALIAS->data=1;
			     
           
			switch(ConfigPtr->PinMode.PortA.A1)
			{
				case DIO_A1:
					
				  GPIOAFSEL_A_AHB_BIT1_ALIAS->data=0;	      				
					break;
				
				 case U0Tx:
				 case CAN1Tx:
					 GPIOAFSEL_A_AHB_BIT1_ALIAS->data=1;
					GPIO_PORT_A_AHB_GPIOPCTL->data=GPIO_PORT_A_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortA.A1))<<4)|0XFFFFFF0F);
				 	
				 break;
				/*
					GPIOAFSEL_A_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_A_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT7_ALIAS->data=0;
					break;
				
					GPIOAFSEL_A_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT4_ALIAS->data=0;
			    GPIOPCTL_A_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT7_ALIAS->data=0;
			 
					
					break;*/
				
			}
			switch(ConfigPtr->OutputCurrent.PortA_OutputCurrent.Pin1OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_A_AHB_BIT1_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_A_AHB_BIT1_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_A_AHB_BIT1_ALIAS->data=0;
					 break;
			     
			 }  	  
			switch(ConfigPtr->InternalAttach.PortA_InternalAttach.Pin1InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_A_AHB_BIT1_ALIAS->data=0;
					 GPIOPDR_A_AHB_BIT1_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_A_AHB_BIT1_ALIAS->data=0;
					 GPIOPUR_A_AHB_BIT1_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_A_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
			 
				GPIODATA_A_AHB_BIT1_ALIAS->data=ConfigPtr->PinLevel;	
			 
				break;
			case PortA_Pin2:
					GPIODIR_A_AHB_BIT2_ALIAS->data=ConfigPtr->PinDirection;
			     GPIODEN_A_AHB_BIT2_ALIAS->data=1;
			
         	
			switch(ConfigPtr->PinMode.PortA.A2)
			{
				case DIO_A2:
					
				  GPIOAFSEL_A_AHB_BIT2_ALIAS->data=0;	      				
					break;
				case SSI0Clk:
					GPIOAFSEL_A_AHB_BIT2_ALIAS->data=1;
					GPIO_PORT_A_AHB_GPIOPCTL->data=GPIO_PORT_A_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortA.A2))<<8)|0XFFFFF0FF);
					
				 /*GPIOPCTL_A_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_A_AHB_BIT9_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT10_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT11_ALIAS->data=0;*/
					break;
				
			 
					
					
				
			}
			 switch(ConfigPtr->OutputCurrent.PortA_OutputCurrent.Pin2OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_A_AHB_BIT2_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_A_AHB_BIT2_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_A_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }    
			switch(ConfigPtr->InternalAttach.PortA_InternalAttach.Pin2InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_A_AHB_BIT2_ALIAS->data=0;
					 GPIOPDR_A_AHB_BIT2_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_A_AHB_BIT2_ALIAS->data=0;
					 GPIOPUR_A_AHB_BIT2_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_A_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
			 
				GPIODATA_A_AHB_BIT2_ALIAS->data=ConfigPtr->PinLevel;	
			 

				break;
			case PortA_Pin3:
						GPIODIR_A_AHB_BIT3_ALIAS->data=ConfigPtr->PinDirection;	  
			     GPIODEN_A_AHB_BIT3_ALIAS->data=1;
			 
        
			switch(ConfigPtr->PinMode.PortA.A3)
			{
				case DIO_A3:
					
				  GPIOAFSEL_A_AHB_BIT3_ALIAS->data=0;	      				
					break;
				case SSI0Fss:
				GPIOAFSEL_A_AHB_BIT3_ALIAS->data=1;	
				GPIO_PORT_A_AHB_GPIOPCTL->data=GPIO_PORT_A_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortA.A3))<<12)|0XFFFF0FFF);

					
				/*
				  GPIOPCTL_A_AHB_BIT12_ALIAS->data=0;
			    GPIOPCTL_A_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT14_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT15_ALIAS->data=0;*/
					break;
				
			 
					
					
				
			}
			switch(ConfigPtr->OutputCurrent.PortA_OutputCurrent.Pin3OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_A_AHB_BIT3_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_A_AHB_BIT3_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_A_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }  	  
			switch(ConfigPtr->InternalAttach.PortA_InternalAttach.Pin3InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_A_AHB_BIT3_ALIAS->data=0;
					 GPIOPDR_A_AHB_BIT3_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_A_AHB_BIT3_ALIAS->data=0;
					 GPIOPUR_A_AHB_BIT3_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_A_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
			 
				
			  GPIODATA_A_AHB_BIT3_ALIAS->data=ConfigPtr->PinLevel;	

				break;
			case PortA_Pin4:
					 GPIODIR_A_AHB_BIT4_ALIAS->data=ConfigPtr->PinDirection;
			     GPIODEN_A_AHB_BIT4_ALIAS->data=1;
           		 
			switch(ConfigPtr->PinMode.PortA.A4)
			{
				case DIO_A4:
					
				  GPIOAFSEL_A_AHB_BIT4_ALIAS->data=0;	      				
					break;
				
				case SSI0Rx:
					GPIOAFSEL_A_AHB_BIT4_ALIAS->data=1;
					GPIO_PORT_A_AHB_GPIOPCTL->data=GPIO_PORT_A_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortA.A4)<<16))|0XFFF0FFFF);

					/*
				  GPIOPCTL_A_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_A_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT19_ALIAS->data=0;
			 
					*/
					break;
				
			}
			switch(ConfigPtr->OutputCurrent.PortA_OutputCurrent.Pin4OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_A_AHB_BIT4_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_A_AHB_BIT4_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_A_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }   
			switch(ConfigPtr->InternalAttach.PortA_InternalAttach.Pin4InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_A_AHB_BIT4_ALIAS->data=0;
					 GPIOPDR_A_AHB_BIT4_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_A_AHB_BIT4_ALIAS->data=0;
					 GPIOPUR_A_AHB_BIT4_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_A_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
			 
				
			 GPIODATA_A_AHB_BIT4_ALIAS->data=ConfigPtr->PinLevel;

				break;
			case PortA_Pin5:
					 GPIODIR_A_AHB_BIT5_ALIAS->data=ConfigPtr->PinDirection;
			     GPIODEN_A_AHB_BIT5_ALIAS->data=1;
			     
           	
			switch(ConfigPtr->PinMode.PortA.A5)
			{
				case DIO_A5:
					
				  GPIOAFSEL_A_AHB_BIT5_ALIAS->data=0;	      				
					break;
				
				case SSI0Tx:
          GPIOAFSEL_A_AHB_BIT5_ALIAS->data=1;					
					GPIO_PORT_A_AHB_GPIOPCTL->data=GPIO_PORT_A_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortA.A5)<<20))|0XFF0FFFFF);
					
				/*
				  GPIOPCTL_A_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_A_AHB_BIT21_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT23_ALIAS->data=0;
			  */
					break;
				
			}
			 switch(ConfigPtr->OutputCurrent.PortA_OutputCurrent.Pin5OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_A_AHB_BIT5_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_A_AHB_BIT5_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_A_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
				 	  
			switch(ConfigPtr->InternalAttach.PortA_InternalAttach.Pin5InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_A_AHB_BIT5_ALIAS->data=0;
					 GPIOPDR_A_AHB_BIT5_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_A_AHB_BIT5_ALIAS->data=0;
					 GPIOPUR_A_AHB_BIT5_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_A_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
			 
			 GPIODATA_A_AHB_BIT5_ALIAS->data=ConfigPtr->PinLevel;

				break;
			case PortA_Pin6:
					 GPIODIR_A_AHB_BIT6_ALIAS->data=ConfigPtr->PinDirection;
			     GPIODEN_A_AHB_BIT6_ALIAS->data=1;
           
			switch(ConfigPtr->PinMode.PortA.A6)
			{
				case DIO_A6:
					
				  GPIOAFSEL_A_AHB_BIT6_ALIAS->data=0;	      				
					break;
				case I2C1SCL:
				case M1PWM2:			
					GPIO_PORT_A_AHB_GPIOPCTL->data=GPIO_PORT_A_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortA.A6)<<24))|0XF0FFFFFF);
          GPIOAFSEL_A_AHB_BIT6_ALIAS->data=1;
				break;
				
	  	/* case I2C1SCL:
					GPIOAFSEL_A_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT24_ALIAS->data=1;
			    GPIOPCTL_A_AHB_BIT25_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT26_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT27_ALIAS->data=0;
					break;
				case M1PWM2:
					GPIOAFSEL_A_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT24_ALIAS->data=1;
			    GPIOPCTL_A_AHB_BIT25_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT26_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT27_ALIAS->data=0;
			 
					
					break;*/
				
			}
			switch(ConfigPtr->OutputCurrent.PortA_OutputCurrent.Pin6OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_A_AHB_BIT6_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_A_AHB_BIT6_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_A_AHB_BIT6_ALIAS->data=1;
					 break;
			     
			 }   	  
			switch(ConfigPtr->InternalAttach.PortA_InternalAttach.Pin6InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_A_AHB_BIT6_ALIAS->data=0;
					 GPIOPDR_A_AHB_BIT6_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_A_AHB_BIT6_ALIAS->data=0;
					 GPIOPUR_A_AHB_BIT6_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_A_AHB_BIT6_ALIAS->data=1;
					 break;
			     
			 }
			 
				
			 GPIODATA_A_AHB_BIT6_ALIAS->data=ConfigPtr->PinLevel;	

				break;
			case PortA_Pin7:
					 GPIODIR_A_AHB_BIT7_ALIAS->data=ConfigPtr->PinDirection;
			     GPIODEN_A_AHB_BIT7_ALIAS->data=1;
			     
           
			switch(ConfigPtr->PinMode.PortA.A7)
			{
				case DIO_A7:
					
				  GPIOAFSEL_A_AHB_BIT7_ALIAS->data=0;	      				
					break;
				case I2C1SDA:
					case M1PWM3:
					GPIO_PORT_A_AHB_GPIOPCTL->data=GPIO_PORT_A_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortA.A7))<<28)|0X0FFFFFFF);
					GPIOAFSEL_A_AHB_BIT7_ALIAS->data=1;
					break;
			/*case I2C1SDA:
					GPIOAFSEL_A_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT28_ALIAS->data=1;
			    GPIOPCTL_A_AHB_BIT29_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT30_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT31_ALIAS->data=0;
					break;
				case M1PWM3:
					GPIOAFSEL_A_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT28_ALIAS->data=1;
			    GPIOPCTL_A_AHB_BIT29_ALIAS->data=0;
				  GPIOPCTL_A_AHB_BIT30_ALIAS->data=1;
				  GPIOPCTL_A_AHB_BIT31_ALIAS->data=0;
			 
					
					break;*/
				
			}
			switch(ConfigPtr->OutputCurrent.PortA_OutputCurrent.Pin7OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_A_AHB_BIT7_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_A_AHB_BIT7_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_A_AHB_BIT7_ALIAS->data=1;
					 break;
			     
			 }   	  
			switch(ConfigPtr->InternalAttach.PortA_InternalAttach.Pin7InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_A_AHB_BIT7_ALIAS->data=0;
					 GPIOPDR_A_AHB_BIT7_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_A_AHB_BIT7_ALIAS->data=0;
					 GPIOPUR_A_AHB_BIT7_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_A_AHB_BIT7_ALIAS->data=1;
					 break;
			     
			 }
			 
				
			 GPIODATA_A_AHB_BIT7_ALIAS->data=ConfigPtr->PinLevel;	

				break;
				
		}
			GPIO_PORT_A_AHB_GPIOCR->data=1;
		break;
		case PortB:
			GPIOHBCTL->data=GPIOHBCTL->data|1<<PortB;
		RCGCGPIO->data=RCGCGPIO->data|1<<PortB;	
   GPIO_PORT_B_AHB_GPIOLOCK->data=0x4C4F434B;		
		
		switch(ConfigPtr->PinType.PortB_Pins)
		{
			case PortB_Pin0:
				   
			     
			switch(ConfigPtr->PinMode.PortB.B0)
			{
				case DIO_B0:
					
				  GPIOAFSEL_B_AHB_BIT0_ALIAS->data=0;
			    GPIOAMSEL_B_AHB_BIT0_ALIAS->data=0;
					break;
				case U1Rx:
				case T2CCP0:
				GPIO_PORT_B_AHB_GPIOPCTL->data=GPIO_PORT_B_AHB_GPIOPCTL->data&(((UINT32_L)(ConfigPtr->PinMode.PortB.B0))|0XFFFFFFF0);
				GPIODEN_B_AHB_BIT0_ALIAS->data=1;
				GPIOAMSEL_B_AHB_BIT0_ALIAS->data=0;
				GPIOAFSEL_B_AHB_BIT0_ALIAS->data=1;
					break;
			/*case U1Rx:
					GPIODEN_B_AHB_BIT0_ALIAS->data=1;
					GPIOAMSEL_B_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_B_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT3_ALIAS->data=0;
					break;
				case T2CCP0:
					GPIODEN_B_AHB_BIT0_ALIAS->data=1;
					GPIOAMSEL_B_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_B_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT3_ALIAS->data=0;
					break;*/
				case USB0ID:
					GPIODEN_B_AHB_BIT0_ALIAS->data=0;
					GPIOAMSEL_B_AHB_BIT0_ALIAS->data=1;
				  GPIOAFSEL_B_AHB_BIT0_ALIAS->data=0;
				  break;
			 }
					
					
				
			
			 			    
					 GPIODIR_B_AHB_BIT0_ALIAS->data=ConfigPtr->PinDirection;
           GPIODATA_B_AHB_BIT0_ALIAS->data=ConfigPtr->PinLevel;						
			     
			switch(ConfigPtr->InternalAttach.PortB_InternalAttach.Pin0InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_B_AHB_BIT0_ALIAS->data=0;
					 GPIOPDR_B_AHB_BIT0_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_B_AHB_BIT0_ALIAS->data=0;
					 GPIOPUR_B_AHB_BIT0_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_B_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortB_OutputCurrent.Pin0OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_B_AHB_BIT0_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_B_AHB_BIT0_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_B_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortB_Pin1:
				  
			     
			switch(ConfigPtr->PinMode.PortB.B1)
			{
				case DIO_B1:
					GPIODEN_B_AHB_BIT1_ALIAS->data=1;
				  GPIOAFSEL_B_AHB_BIT1_ALIAS->data=0;
          GPIOAMSEL_B_AHB_BIT1_ALIAS->data=0;				
					break;
				case U1Tx:
					case T2CCP1:
					GPIO_PORT_B_AHB_GPIOPCTL->data=GPIO_PORT_B_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortB.B1))<<4)|0XFFFFFF0F);
				  GPIODEN_B_AHB_BIT1_ALIAS->data=1;
					GPIOAMSEL_B_AHB_BIT1_ALIAS->data=0;
					GPIOAFSEL_B_AHB_BIT1_ALIAS->data=1;
					break;
       /* case U1Tx:
					GPIODEN_B_AHB_BIT1_ALIAS->data=1;
					GPIOAMSEL_B_AHB_BIT1_ALIAS->data=0;
					GPIOAFSEL_B_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT7_ALIAS->data=0;
					break;
				case T2CCP1:
					GPIODEN_B_AHB_BIT1_ALIAS->data=1;
					GPIOAMSEL_B_AHB_BIT1_ALIAS->data=0;
					GPIOAFSEL_B_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT7_ALIAS->data=0;
			 
					
					break;*/
				case USB0VBUS:
					GPIODEN_B_AHB_BIT1_ALIAS->data=0;
					GPIOAMSEL_B_AHB_BIT1_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT1_ALIAS->data=0;
					break;
			}
			   GPIODIR_B_AHB_BIT1_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_B_AHB_BIT1_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortB_InternalAttach.Pin1InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_B_AHB_BIT1_ALIAS->data=0;
					 GPIOPDR_B_AHB_BIT1_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_B_AHB_BIT1_ALIAS->data=0;
					 GPIOPUR_B_AHB_BIT1_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_B_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortB_OutputCurrent.Pin1OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_B_AHB_BIT1_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_B_AHB_BIT1_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_B_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortB_Pin2:
					
			     GPIODEN_B_AHB_BIT2_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortB.B2)
			{
				case DIO_B2:
					
				  GPIOAFSEL_B_AHB_BIT2_ALIAS->data=0;	      				
					break;
				case I2C0SCL:
					case T3CCP0:
					GPIOAFSEL_B_AHB_BIT2_ALIAS->data=1;
					GPIO_PORT_B_AHB_GPIOPCTL->data=GPIO_PORT_B_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortB.B2))<<8)|0XFFFFF0FF);
         	break;
			/*	case I2C0SCL:
	
					GPIOAFSEL_B_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT9_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT10_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT11_ALIAS->data=0;
					break;
				case T3CCP0:
					GPIOAFSEL_B_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT9_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT10_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT11_ALIAS->data=0;
					break;
			 */
					
				
				
			}
			   GPIODIR_B_AHB_BIT2_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_B_AHB_BIT2_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortB_InternalAttach.Pin2InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_B_AHB_BIT2_ALIAS->data=0;
					 GPIOPDR_B_AHB_BIT2_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_B_AHB_BIT2_ALIAS->data=0;
					 GPIOPUR_B_AHB_BIT2_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_B_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortB_OutputCurrent.Pin2OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_B_AHB_BIT2_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_B_AHB_BIT2_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_B_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortB_Pin3:
					
			     GPIODEN_B_AHB_BIT3_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortB.B3)
			{
				case DIO_B3:
					
				  GPIOAFSEL_B_AHB_BIT3_ALIAS->data=0;	      				
					break;
				case I2C0SDA:
					case T3CCP1:
					GPIO_PORT_B_AHB_GPIOPCTL->data=GPIO_PORT_B_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortB.B3))<<12)|0XFFFF0FFF);
          GPIOAFSEL_B_AHB_BIT3_ALIAS->data=1;
					break;
					/*
				case I2C0SDA:
					
					GPIOAFSEL_B_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT14_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT15_ALIAS->data=0;
					break;
				case T3CCP1:
					GPIOAFSEL_B_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT14_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT15_ALIAS->data=0;
					break;*/
			 
					
					
				
			}
			   GPIODIR_B_AHB_BIT3_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_B_AHB_BIT3_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortB_InternalAttach.Pin3InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_B_AHB_BIT3_ALIAS->data=0;
					 GPIOPDR_B_AHB_BIT3_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_B_AHB_BIT3_ALIAS->data=0;
					 GPIOPUR_B_AHB_BIT3_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_B_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortB_OutputCurrent.Pin3OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_B_AHB_BIT3_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_B_AHB_BIT3_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_B_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortB_Pin4:
							  
			     
			switch(ConfigPtr->PinMode.PortB.B4)
			{
				case DIO_B4:
					GPIODEN_B_AHB_BIT4_ALIAS->data=1;
				  GPIOAFSEL_B_AHB_BIT4_ALIAS->data=0;	
          GPIOAMSEL_B_AHB_BIT4_ALIAS->data=0;				
					break;
				case SSI2Clk:
				case M0PWM2:
				case T1CCP0:
				case	CAN0Rx:
					GPIO_PORT_B_AHB_GPIOPCTL->data=GPIO_PORT_B_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortB.B4))<<16)|0XFFF0FFFF);
          GPIODEN_B_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_B_AHB_BIT4_ALIAS->data=0;
				break;
				/*case SSI2Clk:
					GPIODEN_B_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_B_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case M0PWM2:
					GPIODEN_B_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_B_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT17_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case T1CCP0:
					GPIODEN_B_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_B_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT16_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case CAN0Rx:
					GPIODEN_B_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_B_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT17_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT19_ALIAS->data=1;
			 
					
					break;*/
				case AIN10:
					GPIODEN_B_AHB_BIT4_ALIAS->data=0;
					GPIOAMSEL_B_AHB_BIT4_ALIAS->data=1;
				  GPIOAFSEL_B_AHB_BIT4_ALIAS->data=0;
			 
					
					break;
				
			}
			   GPIODIR_B_AHB_BIT4_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_B_AHB_BIT4_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortB_InternalAttach.Pin4InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_B_AHB_BIT4_ALIAS->data=0;
					 GPIOPDR_B_AHB_BIT4_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_B_AHB_BIT4_ALIAS->data=0;
					 GPIOPUR_B_AHB_BIT4_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_B_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortB_OutputCurrent.Pin4OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_B_AHB_BIT4_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_B_AHB_BIT4_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_B_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortB_Pin5:
							  
			     
			switch(ConfigPtr->PinMode.PortB.B5)
			{
				case DIO_B5:
					GPIODEN_B_AHB_BIT5_ALIAS->data=1;
				  GPIOAFSEL_B_AHB_BIT5_ALIAS->data=0;
          GPIOAMSEL_B_AHB_BIT5_ALIAS->data=0;				
					break;
				case SSI2Fss:
				case M0PWM3:
				case T1CCP1:
				case CAN0Tx:
					GPIO_PORT_B_AHB_GPIOPCTL->data=GPIO_PORT_B_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortB.B5))<<20)|0XFF0FFFFF);
          GPIODEN_B_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_B_AHB_BIT5_ALIAS->data=0;	
				break;
			/*	case SSI2Fss:
					GPIODEN_B_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_B_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_B_AHB_BIT20_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT21_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case M0PWM3:
					GPIODEN_B_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_B_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_B_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT22_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case T1CCP1:
					GPIODEN_B_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_B_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_B_AHB_BIT20_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT21_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT22_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case CAN0Tx:
					GPIODEN_B_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_B_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_B_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_B_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT23_ALIAS->data=1;
			 
					
					break;
				*/
				case AIN11:
					GPIODEN_B_AHB_BIT5_ALIAS->data=0;
					GPIOAFSEL_B_AHB_BIT5_ALIAS->data=0;
				  GPIOAMSEL_B_AHB_BIT5_ALIAS->data=1;
			 
					
					break;
				
			}
			   GPIODIR_B_AHB_BIT5_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_B_AHB_BIT5_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortB_InternalAttach.Pin5InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_B_AHB_BIT5_ALIAS->data=0;
					 GPIOPDR_B_AHB_BIT5_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_B_AHB_BIT5_ALIAS->data=0;
					 GPIOPUR_B_AHB_BIT5_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_B_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortB_OutputCurrent.Pin5OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_B_AHB_BIT5_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_B_AHB_BIT5_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_B_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortB_Pin6:
							  
			     GPIODEN_B_AHB_BIT6_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortB.B6)
			{
				case DIO_B6:
					
				  GPIOAFSEL_B_AHB_BIT6_ALIAS->data=0;	      				
					break;
				case SSI2Rx:
				case M0PWM0:
        case T0CCP0:					
					GPIO_PORT_B_AHB_GPIOPCTL->data=GPIO_PORT_B_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortB.B6))<<24)|0XF0FFFFFF);
         GPIOAFSEL_B_AHB_BIT6_ALIAS->data=1;
				break;
				/*case SSI2Rx:
					GPIOAFSEL_B_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT24_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT25_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT26_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT27_ALIAS->data=0;
					break;
				case M0PWM0:
					GPIOAFSEL_B_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT24_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT25_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT26_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT27_ALIAS->data=0;
			 
					
					break;
				case T0CCP0:
					GPIOAFSEL_B_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT24_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT25_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT26_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT27_ALIAS->data=0;
			 
					
					break;*/
			}
			   GPIODIR_B_AHB_BIT6_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_B_AHB_BIT6_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortB_InternalAttach.Pin6InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_B_AHB_BIT6_ALIAS->data=0;
					 GPIOPDR_B_AHB_BIT6_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_B_AHB_BIT6_ALIAS->data=0;
					 GPIOPUR_B_AHB_BIT6_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_B_AHB_BIT6_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortB_OutputCurrent.Pin6OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_B_AHB_BIT6_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_B_AHB_BIT6_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_B_AHB_BIT6_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortB_Pin7:
					 
			     GPIODEN_B_AHB_BIT7_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortB.B7)
			{
				case DIO_B7:
					
				  GPIOAFSEL_B_AHB_BIT7_ALIAS->data=0;	      				
					break;
					case SSI2Tx:
          case M0PWM1:
          case T0CCP1:						
					GPIO_PORT_B_AHB_GPIOPCTL->data=GPIO_PORT_B_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortB.B6))<<28)|0X0FFFFFFF);
          GPIOAFSEL_B_AHB_BIT7_ALIAS->data=1;
					break;
				/*case SSI2Tx:
					GPIOAFSEL_B_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT28_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT29_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT30_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT31_ALIAS->data=0;
					break;
				case M0PWM1:
					GPIOAFSEL_B_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT28_ALIAS->data=0;
			    GPIOPCTL_B_AHB_BIT29_ALIAS->data=0;
				  GPIOPCTL_B_AHB_BIT30_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT31_ALIAS->data=0;
			 
					
					break;
				case T0CCP1:
					GPIOAFSEL_B_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT28_ALIAS->data=1;
			    GPIOPCTL_B_AHB_BIT29_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT30_ALIAS->data=1;
				  GPIOPCTL_B_AHB_BIT31_ALIAS->data=0;
			 
					
					break;*/
				
			}
			   GPIODIR_B_AHB_BIT7_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_B_AHB_BIT7_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortB_InternalAttach.Pin7InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_B_AHB_BIT7_ALIAS->data=0;
					 GPIOPDR_B_AHB_BIT7_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_B_AHB_BIT7_ALIAS->data=0;
					 GPIOPUR_B_AHB_BIT7_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_B_AHB_BIT7_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortB_OutputCurrent.Pin7OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_B_AHB_BIT7_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_B_AHB_BIT7_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_B_AHB_BIT7_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
				
		}
			GPIO_PORT_B_AHB_GPIOCR->data=1;
		break;	
		case PortC:
						GPIOHBCTL->data=GPIOHBCTL->data|1<<PortC;
		RCGCGPIO->data=RCGCGPIO->data|1<<PortC;	
   GPIO_PORT_C_AHB_GPIOLOCK->data=0x4C4F434B;	
		switch(ConfigPtr->PinType.PortC_Pins)
		{
			case PortC_Pin0:
				  
			     GPIODEN_C_AHB_BIT0_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortC.C0)
			{
				case DIO_C0:
					
				  GPIOAFSEL_C_AHB_BIT0_ALIAS->data=0;
			    
					break;
					case TCK_SWCLK:
          case T4CCP0:						
					GPIO_PORT_C_AHB_GPIOPCTL->data=GPIO_PORT_C_AHB_GPIOPCTL->data&(((UINT32_L)(ConfigPtr->PinMode.PortC.C0))|0XFFFFFFF0);
          GPIOAFSEL_C_AHB_BIT0_ALIAS->data=1;
					break;
				/*case TCK_SWCLK:
					GPIOAFSEL_C_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT3_ALIAS->data=0;
					break;
				case T4CCP0:
					
					GPIOAFSEL_C_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT3_ALIAS->data=0;
					break;*/
				
			 }
					
					
				
			
			 			    
					 GPIODIR_C_AHB_BIT0_ALIAS->data=ConfigPtr->PinDirection;
           GPIODATA_C_AHB_BIT0_ALIAS->data=ConfigPtr->PinLevel;						
			     
			switch(ConfigPtr->InternalAttach.PortC_InternalAttach.Pin0InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_C_AHB_BIT0_ALIAS->data=0;
					 GPIOPDR_C_AHB_BIT0_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_C_AHB_BIT0_ALIAS->data=0;
					 GPIOPUR_C_AHB_BIT0_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_C_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortC_OutputCurrent.Pin0OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_C_AHB_BIT0_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_C_AHB_BIT0_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_C_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortC_Pin1:
				   
			     GPIODEN_C_AHB_BIT1_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortC.C1)
			{
				case DIO_C1:
					
				  GPIOAFSEL_C_AHB_BIT1_ALIAS->data=0;	      				
					break;
				case TMS_SWDIO:
				case T4CCP1:
					GPIOAFSEL_C_AHB_BIT1_ALIAS->data=1;					
					GPIO_PORT_C_AHB_GPIOPCTL->data=GPIO_PORT_C_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortC.C1))<<4)|0XFFFFFF0F);
         
				break;
				/*
				case TMS_SWDIO:
					
					GPIOAFSEL_C_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT7_ALIAS->data=0;
					break;
				case T4CCP1:
					
					GPIOAFSEL_C_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT7_ALIAS->data=0;
			 
					
					break;*/
				
			}
			   GPIODIR_C_AHB_BIT1_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_C_AHB_BIT1_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortC_InternalAttach.Pin1InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_C_AHB_BIT1_ALIAS->data=0;
					 GPIOPDR_C_AHB_BIT1_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_C_AHB_BIT1_ALIAS->data=0;
					 GPIOPUR_C_AHB_BIT1_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_C_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortC_OutputCurrent.Pin1OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_C_AHB_BIT1_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_C_AHB_BIT1_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_C_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortC_Pin2:
					 
			     GPIODEN_C_AHB_BIT2_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortC.C2)
			{
				case DIO_C2:
					
				  GPIOAFSEL_C_AHB_BIT2_ALIAS->data=0;	      				
					break;
				case TDI:	
				case T5CCP0:
					GPIO_PORT_C_AHB_GPIOPCTL->data=GPIO_PORT_C_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortC.C2))<<8)|0XFFFFF0FF);
          GPIOAFSEL_C_AHB_BIT2_ALIAS->data=1;
				break;
				/*case TDI:
					GPIOAFSEL_C_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT9_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT10_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT11_ALIAS->data=0;
					break;
				case T5CCP0:
					GPIOAFSEL_C_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT9_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT10_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT11_ALIAS->data=0;
					break;*/
			 
					
				
				
			}
			   GPIODIR_C_AHB_BIT2_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_C_AHB_BIT2_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortC_InternalAttach.Pin2InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_C_AHB_BIT2_ALIAS->data=0;
					 GPIOPDR_C_AHB_BIT2_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_C_AHB_BIT2_ALIAS->data=0;
					 GPIOPUR_C_AHB_BIT2_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_C_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortC_OutputCurrent.Pin2OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_C_AHB_BIT2_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_C_AHB_BIT2_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_C_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortC_Pin3:
							   
			     GPIODEN_C_AHB_BIT3_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortC.C3)
			{
				case DIO_C3:
					
				  GPIOAFSEL_C_AHB_BIT3_ALIAS->data=0;	      				
					break;
				  case TDO_SWO:
					case T5CCP1:
					GPIO_PORT_C_AHB_GPIOPCTL->data=GPIO_PORT_C_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortC.C3))<<12)|0XFFFF0FFF);
          GPIOAFSEL_C_AHB_BIT3_ALIAS->data=1;
					break;
				/*case TDO_SWO:
					GPIOAFSEL_C_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT13_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT14_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT15_ALIAS->data=0;
					break;
				case T5CCP1:
					GPIOAFSEL_C_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT14_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT15_ALIAS->data=0;
					break;*/
			 
					
					
				
			}
			   GPIODIR_C_AHB_BIT3_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_C_AHB_BIT3_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortC_InternalAttach.Pin3InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_C_AHB_BIT3_ALIAS->data=0;
					 GPIOPDR_C_AHB_BIT3_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_C_AHB_BIT3_ALIAS->data=0;
					 GPIOPUR_C_AHB_BIT3_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_C_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortC_OutputCurrent.Pin3OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_C_AHB_BIT3_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_C_AHB_BIT3_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_C_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortC_Pin4:
							  
			     
			switch(ConfigPtr->PinMode.PortC.C4)
			{
				case DIO_C4:
					GPIODEN_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAFSEL_C_AHB_BIT4_ALIAS->data=0;	
          GPIOAMSEL_C_AHB_BIT4_ALIAS->data=0;				
					break;
				case U4Rx:
				case U1Rx_:
        case M0PWM6:
        case IDX1:
        case WT0CCP0:	
        case U1RTS:					
					GPIO_PORT_C_AHB_GPIOPCTL->data=GPIO_PORT_C_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortC.C4))<<16)|0XFFF0FFFF);
          GPIODEN_C_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_C_AHB_BIT4_ALIAS->data=0;
				break;
			/*	
				  case U4Rx:
					GPIODEN_C_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_C_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT16_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT17_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case U1Rx_:
					GPIODEN_C_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_C_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT16_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case M0PWM6:
					GPIODEN_C_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_C_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT17_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case IDX1:
					GPIODEN_C_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_C_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case WT0CCP0:
					GPIODEN_C_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_C_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT16_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case U1RTS:
					GPIODEN_C_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_C_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT17_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT19_ALIAS->data=1;
			 
					
					break;*/
				
				case C1_MINUS:
					GPIODEN_C_AHB_BIT4_ALIAS->data=0;
					GPIOAMSEL_C_AHB_BIT4_ALIAS->data=1;
				  GPIOAFSEL_C_AHB_BIT4_ALIAS->data=0;
			 
					
					break;
				
			}
			   GPIODIR_C_AHB_BIT4_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_C_AHB_BIT4_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortC_InternalAttach.Pin4InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_C_AHB_BIT4_ALIAS->data=0;
					 GPIOPDR_C_AHB_BIT4_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_C_AHB_BIT4_ALIAS->data=0;
					 GPIOPUR_C_AHB_BIT4_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_C_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortC_OutputCurrent.Pin4OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_C_AHB_BIT4_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_C_AHB_BIT4_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_C_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortC_Pin5:
							   
			     
			switch(ConfigPtr->PinMode.PortC.C5)
			{
				case DIO_C5:
					GPIODEN_C_AHB_BIT5_ALIAS->data=1;
				  GPIOAFSEL_C_AHB_BIT5_ALIAS->data=0;
          GPIOAMSEL_C_AHB_BIT5_ALIAS->data=0;				
					break;
				case U4Tx:
				case U1Tx_:	
				case M0PWM7:
				case PhA1:
        case WT0CCP1:	
        case U1CTS:					
					GPIO_PORT_C_AHB_GPIOPCTL->data=GPIO_PORT_C_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortC.C5))<<20)|0XFF0FFFFF);
          GPIODEN_C_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_C_AHB_BIT5_ALIAS->data=0;
				
				break;
				
				/*
				case U4Tx:
					GPIODEN_C_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_C_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_C_AHB_BIT20_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case U1Tx_:
					GPIODEN_C_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_C_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_C_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT21_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case M0PWM7:
					GPIODEN_C_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_C_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_C_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT22_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case PhA1:
					GPIODEN_C_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_C_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_C_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT21_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT22_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case WT0CCP1:
					GPIODEN_C_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_C_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_C_AHB_BIT20_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT21_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT22_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case U1CTS:
					GPIODEN_C_AHB_BIT5_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT5_ALIAS->data=1;
          GPIOAMSEL_C_AHB_BIT5_ALIAS->data=0;	
				  GPIOPCTL_C_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT23_ALIAS->data=1;
			 
					
					break;*/
				case AIN11:
					GPIODEN_C_AHB_BIT5_ALIAS->data=0;
					GPIOAFSEL_C_AHB_BIT5_ALIAS->data=0;
				  GPIOAMSEL_C_AHB_BIT5_ALIAS->data=1;
			    
					
					break;
				
			}
			   GPIODIR_C_AHB_BIT5_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_C_AHB_BIT5_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortC_InternalAttach.Pin5InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_C_AHB_BIT5_ALIAS->data=0;
					 GPIOPDR_C_AHB_BIT5_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_C_AHB_BIT5_ALIAS->data=0;
					 GPIOPUR_C_AHB_BIT5_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_C_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortC_OutputCurrent.Pin5OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_C_AHB_BIT5_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_C_AHB_BIT5_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_C_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortC_Pin6:
							   
			     
			switch(ConfigPtr->PinMode.PortC.C6)
			{
				case DIO_C6:
					
				  GPIOAFSEL_C_AHB_BIT6_ALIAS->data=0;
          GPIOAMSEL_C_AHB_BIT6_ALIAS->data=0;
          GPIODEN_C_AHB_BIT6_ALIAS->data=1;				
					break;
				case U3Rx:
				case PhB1:
				case WT1CCP0:	
        case USB0EPEN:					
					GPIO_PORT_C_AHB_GPIOPCTL->data=GPIO_PORT_C_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortC.C6))<<24)|0XF0FFFFFF);
          GPIOAMSEL_C_AHB_BIT6_ALIAS->data=0;
          GPIODEN_C_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT6_ALIAS->data=1;
				break;
			/*	
				case U3Rx:
					GPIOAMSEL_C_AHB_BIT6_ALIAS->data=0;
          GPIODEN_C_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT24_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT25_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT26_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT27_ALIAS->data=0;
					break;
				case PhB1:
					GPIOAMSEL_C_AHB_BIT6_ALIAS->data=0;
          GPIODEN_C_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT24_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT25_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT26_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT27_ALIAS->data=0;
			 
					
					break;
				case WT1CCP0:
					GPIOAMSEL_C_AHB_BIT6_ALIAS->data=0;
          GPIODEN_C_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT24_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT25_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT26_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT27_ALIAS->data=0;
			 
					
					break;
				case USB0EPEN:
					GPIOAMSEL_C_AHB_BIT6_ALIAS->data=0;
          GPIODEN_C_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_C_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT24_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT25_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT26_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT27_ALIAS->data=1;
			 
					
					break;*/
				case C0_PLUS:
					GPIOAFSEL_C_AHB_BIT6_ALIAS->data=0;
				  GPIOAMSEL_C_AHB_BIT6_ALIAS->data=1;
			    GPIODEN_C_AHB_BIT7_ALIAS->data=0;
					
					break;
			}
			   GPIODIR_C_AHB_BIT6_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_C_AHB_BIT6_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortC_InternalAttach.Pin6InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_C_AHB_BIT6_ALIAS->data=0;
					 GPIOPDR_C_AHB_BIT6_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_C_AHB_BIT6_ALIAS->data=0;
					 GPIOPUR_C_AHB_BIT6_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_C_AHB_BIT6_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortC_OutputCurrent.Pin6OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_C_AHB_BIT6_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_C_AHB_BIT6_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_C_AHB_BIT6_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortC_Pin7:
			
			     
			switch(ConfigPtr->PinMode.PortC.C7)
			{
				case DIO_C7:
					
				  GPIOAFSEL_C_AHB_BIT7_ALIAS->data=0;	
          GPIOAMSEL_C_AHB_BIT7_ALIAS->data=0;
          GPIODEN_C_AHB_BIT7_ALIAS->data=1;				
					break;
				case U3Tx:
				case WT1CCP1:
				case USB0PFLT:					
					GPIO_PORT_C_AHB_GPIOPCTL->data=GPIO_PORT_C_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortC.C7))<<28)|0X0FFFFFFF);
        GPIOAMSEL_C_AHB_BIT7_ALIAS->data=0;
          GPIODEN_C_AHB_BIT7_ALIAS->data=1;	
					GPIOAFSEL_C_AHB_BIT7_ALIAS->data=1;
				break;
			/*
				case U3Tx:
					GPIOAMSEL_C_AHB_BIT7_ALIAS->data=0;
          GPIODEN_C_AHB_BIT7_ALIAS->data=1;	
					GPIOAFSEL_C_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT28_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT29_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT30_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT31_ALIAS->data=0;
					break;
				
				case WT1CCP1:
					GPIOAMSEL_C_AHB_BIT7_ALIAS->data=0;
          GPIODEN_C_AHB_BIT7_ALIAS->data=1;	
					GPIOAFSEL_C_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT28_ALIAS->data=1;
			    GPIOPCTL_C_AHB_BIT29_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT30_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT31_ALIAS->data=0;
			 
					
					break;
				case USB0PFLT:
					GPIOAMSEL_C_AHB_BIT7_ALIAS->data=0;
          GPIODEN_C_AHB_BIT7_ALIAS->data=1;	
					GPIOAFSEL_C_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_C_AHB_BIT28_ALIAS->data=0;
			    GPIOPCTL_C_AHB_BIT29_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT30_ALIAS->data=0;
				  GPIOPCTL_C_AHB_BIT31_ALIAS->data=1;
			 
					
					break;*/
				case C0_MINUS:
					GPIODEN_C_AHB_BIT7_ALIAS->data=0;
					GPIOAFSEL_C_AHB_BIT7_ALIAS->data=0;
          GPIOAMSEL_C_AHB_BIT7_ALIAS->data=1;

			 
					
					break;
				
			}
			   GPIODIR_C_AHB_BIT7_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_C_AHB_BIT7_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortC_InternalAttach.Pin7InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_C_AHB_BIT7_ALIAS->data=0;
					 GPIOPDR_C_AHB_BIT7_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_C_AHB_BIT7_ALIAS->data=0;
					 GPIOPUR_C_AHB_BIT7_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_C_AHB_BIT7_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortC_OutputCurrent.Pin7OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_C_AHB_BIT7_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_C_AHB_BIT7_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_C_AHB_BIT7_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
				
		}
			GPIO_PORT_C_AHB_GPIOCR->data=1;
		break;	
		case PortD:
				GPIOHBCTL->data=GPIOHBCTL->data|1<<PortD;
		RCGCGPIO->data=RCGCGPIO->data|1<<PortD;	
   GPIO_PORT_D_AHB_GPIOLOCK->data=0x4C4F434B;	
		switch(ConfigPtr->PinType.PortD_Pins)
		{
			case PortD_Pin0:
				  
			     
			switch(ConfigPtr->PinMode.PortD.D0)
			{
				case DIO_D0:
					
				  GPIOAFSEL_D_AHB_BIT0_ALIAS->data=0;
			    GPIOAMSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIODEN_D_AHB_BIT0_ALIAS->data=1;
					break;
				case SSI3Clk:
				case SSI1Clk:
				case I2C3SCL:
				case M0PWM6_:
				case M1PWM0:
				case WT2CCP0:
								
					GPIO_PORT_D_AHB_GPIOPCTL->data=GPIO_PORT_D_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortD.D0)))|0XFFFFFFF0);
          GPIOAMSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIODEN_D_AHB_BIT0_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT0_ALIAS->data=1;
				
				break;
				/*
				case SSI3Clk:
			    GPIOAMSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIODEN_D_AHB_BIT0_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT3_ALIAS->data=0;
					break;
				case SSI1Clk:
			    GPIOAMSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIODEN_D_AHB_BIT0_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT0_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT3_ALIAS->data=0;
					break;
				case I2C3SCL:
					
			    GPIOAMSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIODEN_D_AHB_BIT0_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT3_ALIAS->data=0;
					break;
				case M0PWM6_:
					
			    GPIOAMSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIODEN_D_AHB_BIT0_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT0_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT3_ALIAS->data=0;
					break;
					case M1PWM0:
					
			    GPIOAMSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIODEN_D_AHB_BIT0_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT3_ALIAS->data=0;
					break;
					case WT2CCP0:
					
			    GPIOAMSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIODEN_D_AHB_BIT0_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT3_ALIAS->data=0;
					break;*/
					case AIN7:
					
			    
				  GPIODEN_D_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_D_AHB_BIT0_ALIAS->data=0;
				  GPIOAMSEL_D_AHB_BIT0_ALIAS->data=1;
					break;
			 }
					 GPIODIR_D_AHB_BIT0_ALIAS->data=ConfigPtr->PinDirection;
           GPIODATA_D_AHB_BIT0_ALIAS->data=ConfigPtr->PinLevel;						
			switch(ConfigPtr->InternalAttach.PortD_InternalAttach.Pin0InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_D_AHB_BIT0_ALIAS->data=0;
					 GPIOPDR_D_AHB_BIT0_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_D_AHB_BIT0_ALIAS->data=0;
					 GPIOPUR_D_AHB_BIT0_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_D_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortD_OutputCurrent.Pin0OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_D_AHB_BIT0_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_D_AHB_BIT0_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_D_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortD_Pin1:
				   
			     
			switch(ConfigPtr->PinMode.PortD.D1)
			{
				case DIO_D1:
					GPIOAMSEL_D_AHB_BIT1_ALIAS->data=0;
          GPIODEN_D_AHB_BIT1_ALIAS->data=1;			 	
				  GPIOAFSEL_D_AHB_BIT1_ALIAS->data=0;	      				
					break;
				case SSI3Fss:
				case SSI1Fss:
				case I2C3SDA:
				case M0PWM7_:
				case M1PWM1:
				case WT2CCP1:
					GPIO_PORT_D_AHB_GPIOPCTL->data=GPIO_PORT_D_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortD.D1))<<4)|0XFFFFFF0F);
          GPIOAMSEL_D_AHB_BIT1_ALIAS->data=0;
          GPIODEN_D_AHB_BIT1_ALIAS->data=1;		
					GPIOAFSEL_D_AHB_BIT1_ALIAS->data=1;
          break;				
			/*	
				case SSI3Fss:
					
					GPIOAMSEL_D_AHB_BIT1_ALIAS->data=0;
          GPIODEN_D_AHB_BIT1_ALIAS->data=1;		
					GPIOAFSEL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT7_ALIAS->data=0;
					break;
				case SSI1Fss:
					
					GPIOAMSEL_D_AHB_BIT1_ALIAS->data=0;
          GPIODEN_D_AHB_BIT1_ALIAS->data=1;		
					GPIOAFSEL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT4_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT7_ALIAS->data=0;
			 
					
					break;
				case I2C3SDA:
					
					GPIOAMSEL_D_AHB_BIT1_ALIAS->data=0;
          GPIODEN_D_AHB_BIT1_ALIAS->data=1;		
					GPIOAFSEL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT7_ALIAS->data=0;
			 
					
					break;
				case M0PWM7_:
					
					GPIOAMSEL_D_AHB_BIT1_ALIAS->data=0;
          GPIODEN_D_AHB_BIT1_ALIAS->data=1;		
					GPIOAFSEL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT4_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT7_ALIAS->data=0;
			 
					
					break;
				case M1PWM1:
					
					GPIOAMSEL_D_AHB_BIT1_ALIAS->data=0;
          GPIODEN_D_AHB_BIT1_ALIAS->data=1;		
					GPIOAFSEL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT7_ALIAS->data=0;
			 
					
					break;
				case WT2CCP1:
					
					GPIOAMSEL_D_AHB_BIT1_ALIAS->data=0;
          GPIODEN_D_AHB_BIT1_ALIAS->data=1;		
					GPIOAFSEL_D_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT7_ALIAS->data=0;
			 
					
					break;*/
				case AIN6:
					

          GPIODEN_D_AHB_BIT1_ALIAS->data=0;		
					GPIOAFSEL_D_AHB_BIT1_ALIAS->data=0;
					GPIOAMSEL_D_AHB_BIT1_ALIAS->data=1;
				  
			 
					
					break;
				
			}
			   GPIODIR_D_AHB_BIT1_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_D_AHB_BIT1_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortD_InternalAttach.Pin1InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_D_AHB_BIT1_ALIAS->data=0;
					 GPIOPDR_D_AHB_BIT1_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_D_AHB_BIT1_ALIAS->data=0;
					 GPIOPUR_D_AHB_BIT1_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_D_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortD_OutputCurrent.Pin1OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_D_AHB_BIT1_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_D_AHB_BIT1_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_D_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortD_Pin2:
					 
			     GPIODEN_D_AHB_BIT2_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortD.D2)
			{
				case DIO_D2:
					GPIODEN_D_AHB_BIT2_ALIAS->data=1;
					GPIOAMSEL_D_AHB_BIT2_ALIAS->data=0;
				  GPIOAFSEL_D_AHB_BIT2_ALIAS->data=0;	      				
					break;
				case SSI3Rx:
				case SSI1Rx:
				case M0FAULT0:
				case WT3CCP0:
				case USB0EPEN_:	
					GPIO_PORT_D_AHB_GPIOPCTL->data=GPIO_PORT_D_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortD.D2))<<8)|0XFFFFF0FF);
          GPIODEN_D_AHB_BIT2_ALIAS->data=1;
					GPIOAMSEL_D_AHB_BIT2_ALIAS->data=0;
					GPIOAFSEL_D_AHB_BIT2_ALIAS->data=1;
				break;
				/*
				case SSI3Rx:
					GPIODEN_D_AHB_BIT2_ALIAS->data=1;
					GPIOAMSEL_D_AHB_BIT2_ALIAS->data=0;
					GPIOAFSEL_D_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT9_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT10_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT11_ALIAS->data=0;
					break;
				case SSI1Rx:
					GPIODEN_D_AHB_BIT2_ALIAS->data=1;
					GPIOAMSEL_D_AHB_BIT2_ALIAS->data=0;
					GPIOAFSEL_D_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT8_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT9_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT10_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT11_ALIAS->data=0;
					break;
				case M0FAULT0:
					GPIODEN_D_AHB_BIT2_ALIAS->data=1;
					GPIOAMSEL_D_AHB_BIT2_ALIAS->data=0;
					GPIOAFSEL_D_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT8_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT9_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT10_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT11_ALIAS->data=0;
					break;
				case WT3CCP0:
					GPIODEN_D_AHB_BIT2_ALIAS->data=1;
					GPIOAMSEL_D_AHB_BIT2_ALIAS->data=0;
					GPIOAFSEL_D_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT9_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT10_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT11_ALIAS->data=0;
					break;
				case USB0EPEN_:
					GPIODEN_D_AHB_BIT2_ALIAS->data=1;
					GPIOAMSEL_D_AHB_BIT2_ALIAS->data=0;
					GPIOAFSEL_D_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT8_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT9_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT10_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT11_ALIAS->data=1;
					break;*/
				case AIN5:
					GPIODEN_D_AHB_BIT2_ALIAS->data=0;
					GPIOAFSEL_D_AHB_BIT2_ALIAS->data=0;
				  GPIOAMSEL_D_AHB_BIT2_ALIAS->data=1;
				  
					break;

			}
			   GPIODIR_D_AHB_BIT2_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_D_AHB_BIT2_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortD_InternalAttach.Pin2InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_D_AHB_BIT2_ALIAS->data=0;
					 GPIOPDR_D_AHB_BIT2_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_D_AHB_BIT2_ALIAS->data=0;
					 GPIOPUR_D_AHB_BIT2_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_D_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortD_OutputCurrent.Pin2OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_D_AHB_BIT2_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_D_AHB_BIT2_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_D_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortD_Pin3:
					
			     GPIODEN_D_AHB_BIT3_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortD.D3)
			{
				case DIO_D3:
					
				  GPIOAFSEL_D_AHB_BIT3_ALIAS->data=0;	      				
					break;
				case SSI3Tx:
				case SSI1Tx:
				case IDX0:
				case WT3CCP1:
				case USB0PFLT_:	
					
				GPIO_PORT_D_AHB_GPIOPCTL->data=GPIO_PORT_D_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortD.D3))<<12)|0XFFFF0FFF);
        GPIOAFSEL_D_AHB_BIT3_ALIAS->data=1;
				break;
				/*
				case SSI3Tx:
					GPIOAFSEL_D_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT13_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT14_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT15_ALIAS->data=0;
					break;
				case SSI1Tx:
					GPIOAFSEL_D_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT12_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT14_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT15_ALIAS->data=0;
					break;
				case IDX0:
					GPIOAFSEL_D_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT12_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT14_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT15_ALIAS->data=0;
					break;
				case WT3CCP1:
					GPIOAFSEL_D_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT14_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT15_ALIAS->data=0;
					break;
				case USB0PFLT_:
					GPIOAFSEL_D_AHB_BIT3_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT12_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT13_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT14_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT15_ALIAS->data=1;
					break;
				
					*/
					
				
			}
			   GPIODIR_D_AHB_BIT3_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_D_AHB_BIT3_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortD_InternalAttach.Pin3InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_D_AHB_BIT3_ALIAS->data=0;
					 GPIOPDR_D_AHB_BIT3_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_D_AHB_BIT3_ALIAS->data=0;
					 GPIOPUR_D_AHB_BIT3_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_D_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortD_OutputCurrent.Pin3OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_D_AHB_BIT3_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_D_AHB_BIT3_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_D_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortD_Pin4:
							   
			     
			switch(ConfigPtr->PinMode.PortD.D4)
			{
				case DIO_D4:
					GPIODEN_D_AHB_BIT4_ALIAS->data=1;
				  GPIOAFSEL_D_AHB_BIT4_ALIAS->data=0;	
          GPIOAMSEL_D_AHB_BIT4_ALIAS->data=0;				
					break;
				case U6Rx:
				case WT4CCP0:

				GPIO_PORT_D_AHB_GPIOPCTL->data=GPIO_PORT_D_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortD.D4))<<16)|0XFFF0FFFF);
          GPIODEN_D_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_D_AHB_BIT4_ALIAS->data=0;
				
				break;
				
				/*
				case U6Rx:
					GPIODEN_D_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_D_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case WT4CCP0:
					GPIODEN_D_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_D_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT16_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT19_ALIAS->data=0;
			 
					
					break;*/

				case AIN4:
					GPIODEN_D_AHB_BIT4_ALIAS->data=0;
					GPIOAMSEL_D_AHB_BIT4_ALIAS->data=1;
				  GPIOAFSEL_D_AHB_BIT4_ALIAS->data=0;
			 
					
					break;
				
			}
			   GPIODIR_D_AHB_BIT4_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_D_AHB_BIT4_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortD_InternalAttach.Pin4InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_D_AHB_BIT4_ALIAS->data=0;
					 GPIOPDR_D_AHB_BIT4_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_D_AHB_BIT4_ALIAS->data=0;
					 GPIOPUR_D_AHB_BIT4_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_D_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortD_OutputCurrent.Pin4OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_D_AHB_BIT4_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_D_AHB_BIT4_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_D_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortD_Pin5:
							  
			           GPIODEN_D_AHB_BIT5_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortD.D5)
			{
				case DIO_D5:
					
				  GPIOAFSEL_D_AHB_BIT5_ALIAS->data=0;			
					break;
				case U6Tx:
				case WT4CCP1:
				case USB0DM:
				GPIO_PORT_D_AHB_GPIOPCTL->data=GPIO_PORT_D_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortD.D5))<<20)|0XFF0FFFFF);
        GPIOAFSEL_D_AHB_BIT5_ALIAS->data=1;
				break;
				/*
				case U6Tx:
					GPIOAFSEL_D_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT20_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case WT4CCP1:
					GPIOAFSEL_D_AHB_BIT5_ALIAS->data=1;	
				  GPIOPCTL_D_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT21_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case USB0DM:
					GPIOAFSEL_D_AHB_BIT5_ALIAS->data=1;	
				  GPIOPCTL_D_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT22_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT23_ALIAS->data=0;
			 
					
					break;*/
				
				
			}
			   GPIODIR_D_AHB_BIT5_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_D_AHB_BIT5_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortD_InternalAttach.Pin5InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_D_AHB_BIT5_ALIAS->data=0;
					 GPIOPDR_D_AHB_BIT5_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_D_AHB_BIT5_ALIAS->data=0;
					 GPIOPUR_D_AHB_BIT5_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_D_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortD_OutputCurrent.Pin5OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_D_AHB_BIT5_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_D_AHB_BIT5_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_D_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortD_Pin6:
							  
			     
			switch(ConfigPtr->PinMode.PortD.D6)
			{
				case DIO_D6:
					
				  GPIOAFSEL_D_AHB_BIT6_ALIAS->data=0;
          GPIOAMSEL_D_AHB_BIT6_ALIAS->data=0;
          GPIODEN_D_AHB_BIT6_ALIAS->data=1;				
					break;
				case U2Rx:
				case M0FAULT0_:
				case PhA0:	
				case WT5CCP0:				
				GPIO_PORT_D_AHB_GPIOPCTL->data=GPIO_PORT_D_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortD.D6))<<24)|0XF0FFFFFF);
          GPIOAMSEL_D_AHB_BIT6_ALIAS->data=0;
          GPIODEN_D_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT6_ALIAS->data=1;
			    break;
				/*
				case U2Rx:
					GPIOAMSEL_D_AHB_BIT6_ALIAS->data=0;
          GPIODEN_D_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT24_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT25_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT26_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT27_ALIAS->data=0;
					break;
				case M0FAULT0_:
					GPIOAMSEL_D_AHB_BIT6_ALIAS->data=0;
          GPIODEN_D_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT24_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT25_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT26_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT27_ALIAS->data=0;
			 
					
					break;
				case PhA0:
					GPIOAMSEL_D_AHB_BIT6_ALIAS->data=0;
          GPIODEN_D_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT24_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT25_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT26_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT27_ALIAS->data=0;
			 
					
					break;
				case WT5CCP0:
					GPIOAMSEL_D_AHB_BIT6_ALIAS->data=0;
          GPIODEN_D_AHB_BIT6_ALIAS->data=1;
					GPIOAFSEL_D_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT24_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT25_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT26_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT27_ALIAS->data=0;
			 
					
					break;*/
				case USB0DP:
					GPIOAFSEL_D_AHB_BIT6_ALIAS->data=0;
				  GPIOAMSEL_D_AHB_BIT6_ALIAS->data=1;
			    GPIODEN_D_AHB_BIT7_ALIAS->data=0;
					
					break;
			}
			   GPIODIR_D_AHB_BIT6_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_D_AHB_BIT6_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortD_InternalAttach.Pin6InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_D_AHB_BIT6_ALIAS->data=0;
					 GPIOPDR_D_AHB_BIT6_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_D_AHB_BIT6_ALIAS->data=0;
					 GPIOPUR_D_AHB_BIT6_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_D_AHB_BIT6_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortD_OutputCurrent.Pin6OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_D_AHB_BIT6_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_D_AHB_BIT6_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_D_AHB_BIT6_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortD_Pin7:
					 
			     GPIODEN_D_AHB_BIT7_ALIAS->data=1;	
			switch(ConfigPtr->PinMode.PortD.D7)
			{
				case DIO_D7:
					
				  GPIOAFSEL_D_AHB_BIT7_ALIAS->data=0;	
 			
					break;
				case U2Tx:
				case PhB0:
				case WT5CCP1:	
        case NMI:					
				GPIO_PORT_D_AHB_GPIOPCTL->data=GPIO_PORT_D_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortD.D7))<<28)|0X0FFFFFFF);	
					GPIOAFSEL_D_AHB_BIT7_ALIAS->data=1;
				  break;
				/*
				case U2Tx:
					GPIOAFSEL_D_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT28_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT29_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT30_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT31_ALIAS->data=0;
					break;
				
				case PhB0:
					GPIOAFSEL_D_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT28_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT29_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT30_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT31_ALIAS->data=0;
			 
					
					break;
				case WT5CCP1:
					GPIOAFSEL_D_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT28_ALIAS->data=1;
			    GPIOPCTL_D_AHB_BIT29_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT30_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT31_ALIAS->data=0;
			 
					
					break;
					case NMI:
					GPIOAFSEL_D_AHB_BIT7_ALIAS->data=1;
				  GPIOPCTL_D_AHB_BIT28_ALIAS->data=0;
			    GPIOPCTL_D_AHB_BIT29_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT30_ALIAS->data=0;
				  GPIOPCTL_D_AHB_BIT31_ALIAS->data=1;
			 
					
					break;*/
				
					


			 
					
					
				
			}
			   GPIODIR_D_AHB_BIT7_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_D_AHB_BIT7_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortD_InternalAttach.Pin7InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_D_AHB_BIT7_ALIAS->data=0;
					 GPIOPDR_D_AHB_BIT7_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_D_AHB_BIT7_ALIAS->data=0;
					 GPIOPUR_D_AHB_BIT7_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_D_AHB_BIT7_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortD_OutputCurrent.Pin7OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_D_AHB_BIT7_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_D_AHB_BIT7_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_D_AHB_BIT7_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
				
		}
			
		GPIO_PORT_D_AHB_GPIOCR->data=1;	
		break;
		case PortE:
				GPIOHBCTL->data=GPIOHBCTL->data|1<<PortE;
		RCGCGPIO->data=RCGCGPIO->data|1<<PortE;	
   GPIO_PORT_E_AHB_GPIOLOCK->data=0x4C4F434B;	
		switch(ConfigPtr->PinType.PortE_Pins)
		{
			case PortE_Pin0:
				  
			     GPIODEN_E_AHB_BIT0_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortE.E0)
			{
				case DIO_E0:
					
				  GPIOAFSEL_E_AHB_BIT0_ALIAS->data=0;

				  
					break;
				case U7Rx:
									
				GPIO_PORT_E_AHB_GPIOPCTL->data=GPIO_PORT_E_AHB_GPIOPCTL->data&(((UINT32_L)(ConfigPtr->PinMode.PortE.E0))|0XFFFFFFF0);

					GPIOAFSEL_E_AHB_BIT0_ALIAS->data=1;
				/* 
   				GPIOPCTL_E_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_E_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT3_ALIAS->data=0;*/
					break;
				
			 }
					 GPIODIR_E_AHB_BIT0_ALIAS->data=ConfigPtr->PinDirection;
           GPIODATA_E_AHB_BIT0_ALIAS->data=ConfigPtr->PinLevel;						
			switch(ConfigPtr->InternalAttach.PortE_InternalAttach.Pin0InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_E_AHB_BIT0_ALIAS->data=0;
					 GPIOPDR_E_AHB_BIT0_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_E_AHB_BIT0_ALIAS->data=0;
					 GPIOPUR_E_AHB_BIT0_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_E_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortE_OutputCurrent.Pin0OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_E_AHB_BIT0_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_E_AHB_BIT0_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_E_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortE_Pin1:
				  
			     
			switch(ConfigPtr->PinMode.PortE.E1)
			{
				case DIO_E1:
					GPIOAMSEL_E_AHB_BIT1_ALIAS->data=0;
          GPIODEN_E_AHB_BIT1_ALIAS->data=1;			 	
				  GPIOAFSEL_E_AHB_BIT1_ALIAS->data=0;	      				
					break;
				case U7Tx:
				GPIO_PORT_E_AHB_GPIOPCTL->data=GPIO_PORT_E_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortE.E1))<<4)|0XFFFFFF0F);	
					GPIOAMSEL_E_AHB_BIT1_ALIAS->data=0;
          GPIODEN_E_AHB_BIT1_ALIAS->data=1;		
					GPIOAFSEL_E_AHB_BIT1_ALIAS->data=1;
				 /*
			  	GPIOPCTL_E_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_E_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT7_ALIAS->data=0;*/
					break;
				
				case AIN3:
					

          GPIODEN_E_AHB_BIT1_ALIAS->data=0;		
					GPIOAFSEL_E_AHB_BIT1_ALIAS->data=0;
					GPIOAMSEL_E_AHB_BIT1_ALIAS->data=1;
				  
			 
					
					break;
				
			}
			   GPIODIR_E_AHB_BIT1_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_E_AHB_BIT1_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortE_InternalAttach.Pin1InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_E_AHB_BIT1_ALIAS->data=0;
					 GPIOPDR_E_AHB_BIT1_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_E_AHB_BIT1_ALIAS->data=0;
					 GPIOPUR_E_AHB_BIT1_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_E_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortE_OutputCurrent.Pin1OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_E_AHB_BIT1_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_E_AHB_BIT1_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_E_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortE_Pin2:
					
           GPIOAFSEL_E_AHB_BIT3_ALIAS->data=0;
			switch(ConfigPtr->PinMode.PortE.E2)
			{
				case DIO_E2:
					GPIODEN_E_AHB_BIT2_ALIAS->data=1;
					GPIOAMSEL_E_AHB_BIT2_ALIAS->data=0;	      				
					break;
				
				case AIN2:
					GPIODEN_E_AHB_BIT2_ALIAS->data=0;
				  GPIOAMSEL_E_AHB_BIT2_ALIAS->data=1;
				  
					break;
				
			 
					
				
				
			}
			   GPIODIR_E_AHB_BIT2_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_E_AHB_BIT2_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortE_InternalAttach.Pin2InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_E_AHB_BIT2_ALIAS->data=0;
					 GPIOPDR_E_AHB_BIT2_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_E_AHB_BIT2_ALIAS->data=0;
					 GPIOPUR_E_AHB_BIT2_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_E_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortE_OutputCurrent.Pin2OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_E_AHB_BIT2_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_E_AHB_BIT2_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR2R_E_AHB_BIT2_ALIAS->data=0;
					 break;
			     
			 }
				
			 

				break;
			case PortE_Pin3:
					
			     GPIOAFSEL_E_AHB_BIT3_ALIAS->data=0;
			switch(ConfigPtr->PinMode.PortE.E3)
			{
				case DIO_E3:
     				GPIODEN_E_AHB_BIT3_ALIAS->data=1;
					break;

				case AIN1:
					GPIODEN_E_AHB_BIT3_ALIAS->data=0;
				  GPIOAMSEL_E_AHB_BIT3_ALIAS->data=1;
					break;
				
					
					
				
			}
			   GPIODIR_E_AHB_BIT3_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_E_AHB_BIT3_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortE_InternalAttach.Pin3InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_E_AHB_BIT3_ALIAS->data=0;
					 GPIOPDR_E_AHB_BIT3_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_E_AHB_BIT3_ALIAS->data=0;
					 GPIOPUR_E_AHB_BIT3_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_E_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortE_OutputCurrent.Pin3OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_E_AHB_BIT3_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_E_AHB_BIT3_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_E_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortE_Pin4:
							   
			     
			switch(ConfigPtr->PinMode.PortE.E4)
			{
				case DIO_E4:
					GPIODEN_E_AHB_BIT4_ALIAS->data=1;
				  GPIOAFSEL_E_AHB_BIT4_ALIAS->data=0;	
          GPIOAMSEL_E_AHB_BIT4_ALIAS->data=0;				
					break;
				case U5Rx:
				case M0PWM4:
				case M1PWM2_:
				case CAN0Rx_:
				
				GPIO_PORT_E_AHB_GPIOPCTL->data=GPIO_PORT_E_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortE.E4))<<16)|0XFFF0FFFF);	
          GPIODEN_E_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_E_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_E_AHB_BIT4_ALIAS->data=0;
				break;
				/*
				case U5Rx:
					
					GPIODEN_E_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_E_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_E_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT16_ALIAS->data=1;
			    GPIOPCTL_E_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_E_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case M0PWM4:
					GPIODEN_E_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_E_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_E_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_E_AHB_BIT17_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_E_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case M1PWM2_:
					GPIODEN_E_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_E_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_E_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT16_ALIAS->data=1;
			    GPIOPCTL_E_AHB_BIT17_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_E_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case CAN0Rx_:
					GPIODEN_E_AHB_BIT4_ALIAS->data=1;
					GPIOAFSEL_E_AHB_BIT4_ALIAS->data=1;
				  GPIOAMSEL_E_AHB_BIT4_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_E_AHB_BIT17_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT18_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT19_ALIAS->data=1;
			 
					
					break;*/

				case AIN0:
					GPIODEN_E_AHB_BIT4_ALIAS->data=0;
					GPIOAMSEL_E_AHB_BIT4_ALIAS->data=1;
				  GPIOAFSEL_E_AHB_BIT4_ALIAS->data=0;
			 
					
					break;
				
			}
			   GPIODIR_E_AHB_BIT4_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_E_AHB_BIT4_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortE_InternalAttach.Pin4InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_E_AHB_BIT4_ALIAS->data=0;
					 GPIOPDR_E_AHB_BIT4_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_E_AHB_BIT4_ALIAS->data=0;
					 GPIOPUR_E_AHB_BIT4_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_E_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortE_OutputCurrent.Pin4OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_E_AHB_BIT4_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_E_AHB_BIT4_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_E_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortE_Pin5:
							  
			           
			switch(ConfigPtr->PinMode.PortE.E5)
			{
				case DIO_E5:
					GPIODEN_E_AHB_BIT5_ALIAS->data=1;
				GPIOAMSEL_E_AHB_BIT5_ALIAS->data=0;	
				  GPIOAFSEL_E_AHB_BIT5_ALIAS->data=0;
          			
					break;
				case U5Tx:
				case I2C2SDA:
				case M0PWM5:
				case M1PWM3_:
				case CAN0Tx_:
				GPIO_PORT_E_AHB_GPIOPCTL->data=GPIO_PORT_E_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortE.E5))<<20)|0XFF0FFFFF);	
        GPIOAFSEL_E_AHB_BIT5_ALIAS->data=1;
				GPIODEN_E_AHB_BIT5_ALIAS->data=1;
				GPIOAMSEL_E_AHB_BIT5_ALIAS->data=0;	
				break;
				/*
				case U5Tx:
				GPIODEN_E_AHB_BIT5_ALIAS->data=1;
				GPIOAMSEL_E_AHB_BIT5_ALIAS->data=0;	
					GPIOAFSEL_E_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_E_AHB_BIT20_ALIAS->data=1;
			    GPIOPCTL_E_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case I2C2SDA:
				GPIODEN_E_AHB_BIT5_ALIAS->data=1;
				GPIOAMSEL_E_AHB_BIT5_ALIAS->data=0;	
					GPIOAFSEL_E_AHB_BIT5_ALIAS->data=1;	
				  GPIOPCTL_E_AHB_BIT20_ALIAS->data=1;
			    GPIOPCTL_E_AHB_BIT21_ALIAS->data=1;
				  GPIOPCTL_E_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case M0PWM5:
				GPIODEN_E_AHB_BIT5_ALIAS->data=1;
				GPIOAMSEL_E_AHB_BIT5_ALIAS->data=0;	
					GPIOAFSEL_E_AHB_BIT5_ALIAS->data=1;	
				  GPIOPCTL_E_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_E_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT22_ALIAS->data=1;
				  GPIOPCTL_E_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case M1PWM3_:
				GPIODEN_E_AHB_BIT5_ALIAS->data=1;
				GPIOAMSEL_E_AHB_BIT5_ALIAS->data=0;	
					GPIOAFSEL_E_AHB_BIT5_ALIAS->data=1;	
				  GPIOPCTL_E_AHB_BIT20_ALIAS->data=1;
			    GPIOPCTL_E_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT22_ALIAS->data=1;
				  GPIOPCTL_E_AHB_BIT23_ALIAS->data=0;
			 
					
					break;
				case CAN0Tx_:
				GPIODEN_E_AHB_BIT5_ALIAS->data=1;
				GPIOAMSEL_E_AHB_BIT5_ALIAS->data=0;	
					GPIOAFSEL_E_AHB_BIT5_ALIAS->data=1;					
				  GPIOPCTL_E_AHB_BIT20_ALIAS->data=0;
			    GPIOPCTL_E_AHB_BIT21_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT22_ALIAS->data=0;
				  GPIOPCTL_E_AHB_BIT23_ALIAS->data=1;
			 
					
					break;*/
				case AIN9:
					GPIODEN_E_AHB_BIT5_ALIAS->data=0;
					GPIOAFSEL_E_AHB_BIT5_ALIAS->data=0;	
          GPIOAMSEL_E_AHB_BIT5_ALIAS->data=1;	
					
					break;
				
				
			}
			   GPIODIR_E_AHB_BIT5_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_E_AHB_BIT5_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortE_InternalAttach.Pin5InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_E_AHB_BIT5_ALIAS->data=0;
					 GPIOPDR_E_AHB_BIT5_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_E_AHB_BIT5_ALIAS->data=0;
					 GPIOPUR_E_AHB_BIT5_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_E_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortE_OutputCurrent.Pin5OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_E_AHB_BIT5_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_E_AHB_BIT5_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_E_AHB_BIT5_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
		 }
			
			GPIO_PORT_E_AHB_GPIOCR->data=1;
		 break;
		case PortF:
				GPIOHBCTL->data=GPIOHBCTL->data|1<<PortF;
		RCGCGPIO->data=RCGCGPIO->data|1<<PortF;	
   GPIO_PORT_F_AHB_GPIOLOCK->data=0x4C4F434B;	
		switch(ConfigPtr->PinType.PortF_Pins)
		{
			case PortF_Pin0:
				   
			     
			switch(ConfigPtr->PinMode.PortF.F0)
			{
				case DIO_F0:
					
				  GPIOAFSEL_F_AHB_BIT0_ALIAS->data=0;
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					break;
				case U1RTS_:
				case SSI1Rx_:
				case CAN0Rx__:
				case M1PWM4:
				case PhA0_:
				case T0CCP0_:
				case NMI_:
				case C0o:

				GPIO_PORT_F_AHB_GPIOPCTL->data=GPIO_PORT_F_AHB_GPIOPCTL->data&(((UINT32_L)(ConfigPtr->PinMode.PortF.F0))|0XFFFFFFF0);	
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
						break;
				
			/*	case U1RTS_:
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT3_ALIAS->data=0;
					break;
				case SSI1Rx_:
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT0_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT3_ALIAS->data=0;
					break;
				case CAN0Rx__:
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT3_ALIAS->data=0;
					break;
				case M1PWM4:
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT3_ALIAS->data=0;
					break;
				case PhA0_:
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT0_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT3_ALIAS->data=0;
					break;
				case T0CCP0_:
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT2_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT3_ALIAS->data=0;
					break;
				case NMI_:
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT0_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT3_ALIAS->data=1;
					break;
				case C0o:
          GPIODEN_F_AHB_BIT0_ALIAS->data=1;
				  GPIOAMSEL_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT0_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT1_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT2_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT3_ALIAS->data=1;
					break;*/
				case AIN8:
          GPIODEN_F_AHB_BIT0_ALIAS->data=0;
					GPIOAFSEL_F_AHB_BIT0_ALIAS->data=0;
          GPIOAMSEL_F_AHB_BIT0_ALIAS->data=1;
					break;
				
			 }
					 GPIODIR_F_AHB_BIT0_ALIAS->data=ConfigPtr->PinDirection;
           GPIODATA_F_AHB_BIT0_ALIAS->data=ConfigPtr->PinLevel;						
			switch(ConfigPtr->InternalAttach.PortF_InternalAttach.Pin0InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_F_AHB_BIT0_ALIAS->data=0;
					 GPIOPDR_F_AHB_BIT0_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_F_AHB_BIT0_ALIAS->data=0;
					 GPIOPUR_F_AHB_BIT0_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_F_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortF_OutputCurrent.Pin0OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_F_AHB_BIT0_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_F_AHB_BIT0_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_F_AHB_BIT0_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortF_Pin1:
				   
			     GPIODEN_F_AHB_BIT1_ALIAS->data=1;	
			switch(ConfigPtr->PinMode.PortF.F1)
			{
				case DIO_F1:			 	
				  GPIOAFSEL_F_AHB_BIT1_ALIAS->data=0;	      				
					break;
				case U1CTS_:
				case SSI1Tx_:
				case M1PWM5:
				case PhB0_:
				case T0CCP1_:
				case C1o:
				case TRD1:
				
					GPIO_PORT_F_AHB_GPIOPCTL->data=GPIO_PORT_F_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortF.F1))<<4)|0XFFFFFF0F);	
          GPIOAFSEL_F_AHB_BIT1_ALIAS->data=1;
				break;
			/*	case U1CTS_:
					
						
					GPIOAFSEL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT7_ALIAS->data=0;
					break;
				case SSI1Tx_:
					
					
					GPIOAFSEL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT4_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT7_ALIAS->data=0;
					break;
				case M1PWM5:
					
						
					GPIOAFSEL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT7_ALIAS->data=0;
					break;
				case PhB0_:
					
					
					GPIOAFSEL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT4_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT7_ALIAS->data=0;
					break;
				case T0CCP1_:
					
				
					GPIOAFSEL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT7_ALIAS->data=0;
					break;
				case C1o:
					
							
					GPIOAFSEL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT4_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT5_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT6_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT7_ALIAS->data=1;
					break;
				case TRD1:
					
					
					GPIOAFSEL_F_AHB_BIT1_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT4_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT5_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT6_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT7_ALIAS->data=1;
					break;*/
				
				
				
			}
			   GPIODIR_F_AHB_BIT1_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_F_AHB_BIT1_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortF_InternalAttach.Pin1InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_F_AHB_BIT1_ALIAS->data=0;
					 GPIOPDR_F_AHB_BIT1_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_F_AHB_BIT1_ALIAS->data=0;
					 GPIOPUR_F_AHB_BIT1_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_F_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortF_OutputCurrent.Pin1OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_F_AHB_BIT1_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_F_AHB_BIT1_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_F_AHB_BIT1_ALIAS->data=1;
					 break;
			     
			 }
				
			 
				break;
			case PortF_Pin2:
					 
           GPIODEN_F_AHB_BIT2_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortF.F2)
			{
				case DIO_F2:
					
           GPIOAFSEL_F_AHB_BIT3_ALIAS->data=0;      				
					break;
				case SSI1Clk_:
				case M0FAULT0__:
				case M1PWM6:
				case T1CCP0_:
				case TRD0:
					GPIO_PORT_F_AHB_GPIOPCTL->data=GPIO_PORT_F_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortF.F2))<<8)|0XFFFFF0FF);	
          GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1;
				
				break;
				
				/*
				case SSI1Clk_:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1; 
				  GPIOPCTL_F_AHB_BIT8_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT9_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT10_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT11_ALIAS->data=0;
					break;
				case M0FAULT0__:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1; 
				  GPIOPCTL_F_AHB_BIT8_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT9_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT10_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT11_ALIAS->data=0;
					break;
			 case M1PWM6:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1; 
				  GPIOPCTL_F_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT9_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT10_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT11_ALIAS->data=0;
					break;
					case T1CCP0_:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1; 
				  GPIOPCTL_F_AHB_BIT8_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT9_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT10_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT11_ALIAS->data=0;
					break;
					case TRD0:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1; 
				  GPIOPCTL_F_AHB_BIT8_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT9_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT10_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT11_ALIAS->data=1;
					break;*/
				
				
			}
			   GPIODIR_F_AHB_BIT2_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_F_AHB_BIT2_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortF_InternalAttach.Pin2InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_F_AHB_BIT2_ALIAS->data=0;
					 GPIOPDR_F_AHB_BIT2_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_F_AHB_BIT2_ALIAS->data=0;
					 GPIOPUR_F_AHB_BIT2_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_F_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortF_OutputCurrent.Pin2OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_F_AHB_BIT2_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_F_AHB_BIT2_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_F_AHB_BIT2_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortF_Pin3:
					 
					GPIODEN_F_AHB_BIT3_ALIAS->data=0;
			     
			switch(ConfigPtr->PinMode.PortF.F3)
			{
				case DIO_F3:
     				GPIOAFSEL_F_AHB_BIT3_ALIAS->data=0;
					break;
				case SSI1Fss_:
				case CAN0Tx__:
				case M1PWM7:
				case T1CCP1_:
				case TRCLK:
        GPIO_PORT_F_AHB_GPIOPCTL->data=GPIO_PORT_F_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortF.F3))<<12)|0XFFFF0FFF);	
       	GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1;

				break;
				/*
				case SSI1Fss_:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1;
					GPIOPCTL_F_AHB_BIT12_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT14_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT15_ALIAS->data=0;

					break;
				case CAN0Tx__:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1;
					GPIOPCTL_F_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT14_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT15_ALIAS->data=0;

					break;
					case M1PWM7:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1;
					GPIOPCTL_F_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT13_ALIAS->data=0;
				  GPIOPCTL_F_AHB_BIT14_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT15_ALIAS->data=0;

					break;
					case T1CCP1_:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1;
					GPIOPCTL_F_AHB_BIT12_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT14_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT15_ALIAS->data=0;

					break;
					case TRCLK:
					GPIOAFSEL_F_AHB_BIT3_ALIAS->data=1;
					GPIOPCTL_F_AHB_BIT12_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT13_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT14_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT15_ALIAS->data=1;

					break;*/
					
				
			}
			   GPIODIR_F_AHB_BIT3_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_F_AHB_BIT3_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortF_InternalAttach.Pin3InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_F_AHB_BIT3_ALIAS->data=0;
					 GPIOPDR_F_AHB_BIT3_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_F_AHB_BIT3_ALIAS->data=0;
					 GPIOPUR_F_AHB_BIT3_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_F_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortF_OutputCurrent.Pin3OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_F_AHB_BIT3_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_F_AHB_BIT3_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_F_AHB_BIT3_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;
			case PortF_Pin4:
							 
			           GPIODEN_F_AHB_BIT4_ALIAS->data=1;
			switch(ConfigPtr->PinMode.PortF.F4)
			{
				case DIO_F4:
					
				  GPIOAFSEL_F_AHB_BIT4_ALIAS->data=0;	
          		
					break;
				case M1FAULT0:
				case IDX0_:
				case T2CCP0_:
				case USB0EPEN__:
        GPIO_PORT_F_AHB_GPIOPCTL->data=GPIO_PORT_F_AHB_GPIOPCTL->data&((((UINT32_L)(ConfigPtr->PinMode.PortF.F4))<<16)|0XFFF0FFFF);	
        GPIOAFSEL_F_AHB_BIT4_ALIAS->data=1;
				break;
				
				/*
				case M1FAULT0:
					GPIOAFSEL_F_AHB_BIT4_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case IDX0_:
					GPIOAFSEL_F_AHB_BIT4_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case T2CCP0_:
					GPIOAFSEL_F_AHB_BIT4_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT16_ALIAS->data=1;
			    GPIOPCTL_F_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT19_ALIAS->data=0;
			 
					
					break;
				case USB0EPEN__:
					GPIOAFSEL_F_AHB_BIT4_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT16_ALIAS->data=0;
			    GPIOPCTL_F_AHB_BIT17_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT18_ALIAS->data=1;
				  GPIOPCTL_F_AHB_BIT19_ALIAS->data=0;
			 
					
					break;*/
			}
			   GPIODIR_F_AHB_BIT4_ALIAS->data=ConfigPtr->PinDirection;
         GPIODATA_F_AHB_BIT4_ALIAS->data=ConfigPtr->PinLevel;		  
			switch(ConfigPtr->InternalAttach.PortF_InternalAttach.Pin4InternalAttach)
		   {
				 case PullDown:
					 GPIOODR_F_AHB_BIT4_ALIAS->data=0;
					 GPIOPDR_F_AHB_BIT4_ALIAS->data=1;
					 break;
				 case PullUp:
					 GPIOODR_F_AHB_BIT4_ALIAS->data=0;
					 GPIOPUR_F_AHB_BIT4_ALIAS->data=1;
					 break;
				 case OpenDrain:
					 GPIOODR_F_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
			 switch(ConfigPtr->OutputCurrent.PortF_OutputCurrent.Pin4OutputCurrent)
		   {
				 case _2mA:
					 GPIODR2R_F_AHB_BIT4_ALIAS->data=1;
					 
					 break;
				 case _4mA:
					GPIODR4R_F_AHB_BIT4_ALIAS->data=1;
					 break;
				 case _8mA:
					GPIODR8R_F_AHB_BIT4_ALIAS->data=1;
					 break;
			     
			 }
				
			 

				break;

		 }
			
			GPIO_PORT_F_AHB_GPIOCR->data=1;
		 break;
	
				
		}
			
  }



