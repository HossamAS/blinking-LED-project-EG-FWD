

#include "DIO.h"
#include "Mcu_Hw.h"

Dio_LevelType Dio_ReadChannel(Dio_ChannelType ChannelId)
{
	Dio_LevelType temp;
	switch(ChannelId)
	{
		case PortA_Pin0_:
			temp=((Dio_LevelType)(GPIODATA_A_AHB_BIT0_ALIAS->data));
			break;
		case PortA_Pin1_:
			temp=((Dio_LevelType)(GPIODATA_A_AHB_BIT1_ALIAS->data));
			break;
		
		case PortA_Pin2_:
			temp=((Dio_LevelType)(GPIODATA_A_AHB_BIT2_ALIAS->data));
			break;
		
		case PortA_Pin3_:
			temp=((Dio_LevelType)(GPIODATA_A_AHB_BIT3_ALIAS->data));
			break;
		
		case PortA_Pin4_:
			temp=((Dio_LevelType)(GPIODATA_A_AHB_BIT4_ALIAS->data));
			break;
		
		case PortA_Pin5_:
			temp=((Dio_LevelType)(GPIODATA_A_AHB_BIT5_ALIAS->data));
			break;
		
		case PortA_Pin6_:
			temp=((Dio_LevelType)(GPIODATA_A_AHB_BIT6_ALIAS->data));
			break;
		
		case PortA_Pin7_:
			temp=((Dio_LevelType)(GPIODATA_A_AHB_BIT7_ALIAS->data));
			break;
		
		case PortB_Pin0_:
			temp=((Dio_LevelType)(GPIODATA_B_AHB_BIT0_ALIAS->data));
			break;
		
		case PortB_Pin1_:
			temp=((Dio_LevelType)(GPIODATA_B_AHB_BIT1_ALIAS->data));
			break;
		
		case PortB_Pin2_:
			temp=((Dio_LevelType)(GPIODATA_B_AHB_BIT2_ALIAS->data));
			break;
		
		case PortB_Pin3_:
			temp=((Dio_LevelType)(GPIODATA_B_AHB_BIT3_ALIAS->data));
			break;
		
		case PortB_Pin4_:
			temp=((Dio_LevelType)(GPIODATA_B_AHB_BIT4_ALIAS->data));
			break;
		
		case PortB_Pin5_:
			temp=((Dio_LevelType)(GPIODATA_B_AHB_BIT5_ALIAS->data));
			break;
		
		case PortB_Pin6_:
			temp=((Dio_LevelType)(GPIODATA_B_AHB_BIT6_ALIAS->data));
			break;
		
		case PortB_Pin7_:
			temp=((Dio_LevelType)(GPIODATA_B_AHB_BIT7_ALIAS->data));
			break;
		case PortC_Pin0_:
			temp=((Dio_LevelType)(GPIODATA_C_AHB_BIT0_ALIAS->data));
			break;
		case PortC_Pin1_:
			temp=((Dio_LevelType)(GPIODATA_C_AHB_BIT1_ALIAS->data));
			break;
		case PortC_Pin2_:
			temp=((Dio_LevelType)(GPIODATA_C_AHB_BIT2_ALIAS->data));
			break;
		case PortC_Pin3_:
			temp=((Dio_LevelType)(GPIODATA_C_AHB_BIT3_ALIAS->data));
			break;
		case PortC_Pin4_:
			temp=((Dio_LevelType)(GPIODATA_C_AHB_BIT4_ALIAS->data));
			break;
		case PortC_Pin5_:
			temp=((Dio_LevelType)(GPIODATA_C_AHB_BIT5_ALIAS->data));
			break;
		case PortC_Pin6_:
			temp=((Dio_LevelType)(GPIODATA_C_AHB_BIT6_ALIAS->data));
			break;
		case PortC_Pin7_:
			temp=((Dio_LevelType)(GPIODATA_C_AHB_BIT7_ALIAS->data));
			break;
		case PortD_Pin0_:
			temp=((Dio_LevelType)(GPIODATA_D_AHB_BIT0_ALIAS->data));
			break;
		case PortD_Pin1_:
			temp=((Dio_LevelType)(GPIODATA_D_AHB_BIT1_ALIAS->data));
			break;
		case PortD_Pin2_:
			temp=((Dio_LevelType)(GPIODATA_D_AHB_BIT2_ALIAS->data));
			break;
		case PortD_Pin3_:
			temp=((Dio_LevelType)(GPIODATA_D_AHB_BIT3_ALIAS->data));
			break;
		case PortD_Pin4_:
			temp=((Dio_LevelType)(GPIODATA_D_AHB_BIT4_ALIAS->data));
			break;
		case PortD_Pin5_:
			temp=((Dio_LevelType)(GPIODATA_D_AHB_BIT5_ALIAS->data));
			break;
		case PortD_Pin6_:
			temp=((Dio_LevelType)(GPIODATA_D_AHB_BIT6_ALIAS->data));
			break;
		case PortD_Pin7_:
			temp=((Dio_LevelType)(GPIODATA_D_AHB_BIT7_ALIAS->data));
			break;
		case PortE_Pin0_:
			temp=((Dio_LevelType)(GPIODATA_E_AHB_BIT0_ALIAS->data));
			break;
		case PortE_Pin1_:
			temp=((Dio_LevelType)(GPIODATA_E_AHB_BIT1_ALIAS->data));
			break;
		case PortE_Pin2_:
			temp=((Dio_LevelType)(GPIODATA_E_AHB_BIT2_ALIAS->data));
			break;
		case PortE_Pin3_:
			temp=((Dio_LevelType)(GPIODATA_E_AHB_BIT3_ALIAS->data));
			break;
		case PortE_Pin4_:
			temp=((Dio_LevelType)(GPIODATA_E_AHB_BIT4_ALIAS->data));
			break;
		case PortE_Pin5_:
			temp=((Dio_LevelType)(GPIODATA_E_AHB_BIT5_ALIAS->data));
			break;
		case PortF_Pin0_:
			temp=((Dio_LevelType)(GPIODATA_F_AHB_BIT0_ALIAS->data));
			break;
		case PortF_Pin1_:
			temp=((Dio_LevelType)(GPIODATA_F_AHB_BIT1_ALIAS->data));
			break;
		case PortF_Pin2_:
			temp=((Dio_LevelType)(GPIODATA_F_AHB_BIT2_ALIAS->data));
			break;
		case PortF_Pin3_:
			temp=((Dio_LevelType)(GPIODATA_F_AHB_BIT3_ALIAS->data));
			break;
		case PortF_Pin4_:
			temp=((Dio_LevelType)(GPIODATA_F_AHB_BIT4_ALIAS->data));
			break;
	}
	return temp;
}

void Dio_WriteChannel(Dio_ChannelType ChannelId,Dio_LevelType Level)
{
	switch(ChannelId)
	{
		case PortA_Pin0_:
			GPIODATA_A_AHB_BIT0_ALIAS->data=Level;
			break;
		case PortA_Pin1_:
			GPIODATA_A_AHB_BIT1_ALIAS->data=Level;
			break;
		
		case PortA_Pin2_:
			GPIODATA_A_AHB_BIT2_ALIAS->data=Level;
			break;
		
		case PortA_Pin3_:
			GPIODATA_A_AHB_BIT3_ALIAS->data=Level;
			break;
		
		case PortA_Pin4_:
			GPIODATA_A_AHB_BIT4_ALIAS->data=Level;
			break;
		
		case PortA_Pin5_:
			GPIODATA_A_AHB_BIT5_ALIAS->data=Level;
			break;
		
		case PortA_Pin6_:
			GPIODATA_A_AHB_BIT6_ALIAS->data=Level;
			break;
		
		case PortA_Pin7_:
			GPIODATA_A_AHB_BIT7_ALIAS->data=Level;
			break;
		
		case PortB_Pin0_:
			GPIODATA_B_AHB_BIT0_ALIAS->data=Level;
			break;
		
		case PortB_Pin1_:
			GPIODATA_B_AHB_BIT1_ALIAS->data=Level;
			break;
		
		case PortB_Pin2_:
			GPIODATA_B_AHB_BIT2_ALIAS->data=Level;
			break;
		
		case PortB_Pin3_:
			GPIODATA_B_AHB_BIT3_ALIAS->data=Level;
			break;
		
		case PortB_Pin4_:
			GPIODATA_B_AHB_BIT4_ALIAS->data=Level;
			break;
		
		case PortB_Pin5_:
			GPIODATA_B_AHB_BIT5_ALIAS->data=Level;
			break;
		
		case PortB_Pin6_:
			GPIODATA_B_AHB_BIT6_ALIAS->data=Level;
			break;
		
		case PortB_Pin7_:
			GPIODATA_B_AHB_BIT7_ALIAS->data=Level;
			break;
		case PortC_Pin0_:
			GPIODATA_C_AHB_BIT0_ALIAS->data=Level;
			break;
		case PortC_Pin1_:
			GPIODATA_C_AHB_BIT1_ALIAS->data=Level;
			break;
		case PortC_Pin2_:
			GPIODATA_C_AHB_BIT2_ALIAS->data=Level;
			break;
		case PortC_Pin3_:
			GPIODATA_C_AHB_BIT3_ALIAS->data=Level;
			break;
		case PortC_Pin4_:
			GPIODATA_C_AHB_BIT4_ALIAS->data=Level;
			break;
		case PortC_Pin5_:
			GPIODATA_C_AHB_BIT5_ALIAS->data=Level;
			break;
		case PortC_Pin6_:
			GPIODATA_C_AHB_BIT6_ALIAS->data=Level;
			break;
		case PortC_Pin7_:
			GPIODATA_C_AHB_BIT7_ALIAS->data=Level;
			break;
		case PortD_Pin0_:
			GPIODATA_D_AHB_BIT0_ALIAS->data=Level;
			break;
		case PortD_Pin1_:
			GPIODATA_D_AHB_BIT1_ALIAS->data=Level;
			break;
		case PortD_Pin2_:
			GPIODATA_D_AHB_BIT2_ALIAS->data=Level;
			break;
		case PortD_Pin3_:
			GPIODATA_D_AHB_BIT3_ALIAS->data=Level;
			break;
		case PortD_Pin4_:
			GPIODATA_D_AHB_BIT4_ALIAS->data=Level;
			break;
		case PortD_Pin5_:
			GPIODATA_D_AHB_BIT5_ALIAS->data=Level;
			break;
		case PortD_Pin6_:
			GPIODATA_D_AHB_BIT6_ALIAS->data=Level;
			break;
		case PortD_Pin7_:
			GPIODATA_D_AHB_BIT7_ALIAS->data=Level;
			break;
		case PortE_Pin0_:
			GPIODATA_E_AHB_BIT0_ALIAS->data=Level;
			break;
		case PortE_Pin1_:
			GPIODATA_E_AHB_BIT1_ALIAS->data=Level;
			break;
		case PortE_Pin2_:
			GPIODATA_E_AHB_BIT2_ALIAS->data=Level;
			break;
		case PortE_Pin3_:
			GPIODATA_E_AHB_BIT3_ALIAS->data=Level;
			break;
		case PortE_Pin4_:
			GPIODATA_E_AHB_BIT4_ALIAS->data=Level;
			break;
		case PortE_Pin5_:
			GPIODATA_E_AHB_BIT5_ALIAS->data=Level;
			break;
		case PortF_Pin0_:
			GPIODATA_F_AHB_BIT0_ALIAS->data=Level;
			break;
		case PortF_Pin1_:
			GPIODATA_F_AHB_BIT1_ALIAS->data=Level;
			break;
		case PortF_Pin2_:
			GPIODATA_F_AHB_BIT2_ALIAS->data=Level;
			break;
		case PortF_Pin3_:
			GPIODATA_F_AHB_BIT3_ALIAS->data=Level;
			break;
		case PortF_Pin4_:
			GPIODATA_F_AHB_BIT4_ALIAS->data=Level;
			break;
	}
}
Dio_LevelType Dio_FlipChannel(Dio_ChannelType ChannelId)
{
	Dio_LevelType temp;
	switch(ChannelId)
	{
		case PortA_Pin0_:
			temp=!((Dio_LevelType)(GPIODATA_A_AHB_BIT0_ALIAS->data));
		  GPIODATA_A_AHB_BIT0_ALIAS->data=temp;
		break;
		case PortA_Pin1_:
			temp=!((Dio_LevelType)(GPIODATA_A_AHB_BIT1_ALIAS->data));
		
		break;
		case PortA_Pin2_:
			temp=!((Dio_LevelType)(GPIODATA_A_AHB_BIT2_ALIAS->data));
		
		break;
		case PortA_Pin3_:
			temp=!((Dio_LevelType)(GPIODATA_A_AHB_BIT3_ALIAS->data));
		  GPIODATA_A_AHB_BIT3_ALIAS->data=temp;
		  break;
		case PortA_Pin4_:
			temp=!((Dio_LevelType)(GPIODATA_A_AHB_BIT4_ALIAS->data));
		
		  GPIODATA_A_AHB_BIT4_ALIAS->data=temp;
			break;
		
		case PortA_Pin5_:
			temp=!((Dio_LevelType)(GPIODATA_A_AHB_BIT5_ALIAS->data));
		  GPIODATA_A_AHB_BIT5_ALIAS->data=temp;
			break;
		
		case PortA_Pin6_:
			temp=!((Dio_LevelType)(GPIODATA_A_AHB_BIT6_ALIAS->data));
		  GPIODATA_A_AHB_BIT6_ALIAS->data=temp;
			break;
		
		case PortA_Pin7_:
			temp=!((Dio_LevelType)(GPIODATA_A_AHB_BIT7_ALIAS->data));
		  GPIODATA_A_AHB_BIT7_ALIAS->data=temp;
			break;
		
		case PortB_Pin0_:
			temp=!((Dio_LevelType)(GPIODATA_B_AHB_BIT0_ALIAS->data));
		  GPIODATA_B_AHB_BIT0_ALIAS->data=temp;
			break;
		
		case PortB_Pin1_:
			temp=!((Dio_LevelType)(GPIODATA_B_AHB_BIT1_ALIAS->data));
		  GPIODATA_B_AHB_BIT1_ALIAS->data=temp;
			break;
		
		case PortB_Pin2_:
			temp=!((Dio_LevelType)(GPIODATA_B_AHB_BIT2_ALIAS->data));
		  GPIODATA_B_AHB_BIT2_ALIAS->data=temp;
			break;
		
		case PortB_Pin3_:
			temp=!((Dio_LevelType)(GPIODATA_B_AHB_BIT3_ALIAS->data));
		  GPIODATA_B_AHB_BIT3_ALIAS->data=temp;
			break;
		
		case PortB_Pin4_:
			temp=!((Dio_LevelType)(GPIODATA_B_AHB_BIT4_ALIAS->data));
		  GPIODATA_B_AHB_BIT4_ALIAS->data=temp;
			break;
		
		case PortB_Pin5_:
			temp=!((Dio_LevelType)(GPIODATA_B_AHB_BIT5_ALIAS->data));
		  GPIODATA_B_AHB_BIT5_ALIAS->data=temp;
			break;
		
		case PortB_Pin6_:
			temp=!((Dio_LevelType)(GPIODATA_B_AHB_BIT6_ALIAS->data));
		  GPIODATA_B_AHB_BIT6_ALIAS->data=temp;
			break;
		
		case PortB_Pin7_:
			temp=!((Dio_LevelType)(GPIODATA_B_AHB_BIT7_ALIAS->data));
		  GPIODATA_B_AHB_BIT7_ALIAS->data=temp;
			break;
		case PortC_Pin0_:
			temp=!((Dio_LevelType)(GPIODATA_C_AHB_BIT0_ALIAS->data));
		  GPIODATA_C_AHB_BIT0_ALIAS->data=temp;
			break;
		case PortC_Pin1_:
			temp=!((Dio_LevelType)(GPIODATA_C_AHB_BIT1_ALIAS->data));
		  GPIODATA_C_AHB_BIT1_ALIAS->data=temp;
			break;
		case PortC_Pin2_:
			temp=!((Dio_LevelType)(GPIODATA_C_AHB_BIT2_ALIAS->data));
		  GPIODATA_C_AHB_BIT2_ALIAS->data=temp;
			break;
		case PortC_Pin3_:
			temp=!((Dio_LevelType)(GPIODATA_C_AHB_BIT3_ALIAS->data));
		  GPIODATA_C_AHB_BIT3_ALIAS->data=temp;
			break;
		case PortC_Pin4_:
			temp=!((Dio_LevelType)(GPIODATA_C_AHB_BIT4_ALIAS->data));
		  GPIODATA_C_AHB_BIT4_ALIAS->data=temp;
			break;
		case PortC_Pin5_:
			temp=!((Dio_LevelType)(GPIODATA_C_AHB_BIT5_ALIAS->data));
		  GPIODATA_C_AHB_BIT5_ALIAS->data=temp;
			break;
		case PortC_Pin6_:
			temp=!((Dio_LevelType)(GPIODATA_C_AHB_BIT6_ALIAS->data));
		  GPIODATA_C_AHB_BIT6_ALIAS->data=temp;
			break;
		case PortC_Pin7_:
			temp=!((Dio_LevelType)(GPIODATA_C_AHB_BIT7_ALIAS->data));
		  GPIODATA_C_AHB_BIT7_ALIAS->data=temp;
			break;
		case PortD_Pin0_:
			temp=!((Dio_LevelType)(GPIODATA_D_AHB_BIT0_ALIAS->data));
		  GPIODATA_D_AHB_BIT0_ALIAS->data=temp;
			break;
		case PortD_Pin1_:
			temp=!((Dio_LevelType)(GPIODATA_D_AHB_BIT1_ALIAS->data));
		  GPIODATA_D_AHB_BIT1_ALIAS->data=temp;
			break;
		case PortD_Pin2_:
			temp=!((Dio_LevelType)(GPIODATA_D_AHB_BIT2_ALIAS->data));
		  GPIODATA_D_AHB_BIT2_ALIAS->data=temp;
			break;
		case PortD_Pin3_:
			temp=!((Dio_LevelType)(GPIODATA_D_AHB_BIT3_ALIAS->data));
		  GPIODATA_D_AHB_BIT3_ALIAS->data=temp;
			break;
		case PortD_Pin4_:
			temp=!((Dio_LevelType)(GPIODATA_D_AHB_BIT4_ALIAS->data));
		  GPIODATA_D_AHB_BIT4_ALIAS->data=temp;
			break;
		case PortD_Pin5_:
			temp=!((Dio_LevelType)(GPIODATA_D_AHB_BIT5_ALIAS->data));
		  GPIODATA_D_AHB_BIT5_ALIAS->data=temp;
			break;
		case PortD_Pin6_:
			temp=!((Dio_LevelType)(GPIODATA_D_AHB_BIT6_ALIAS->data));
		  GPIODATA_D_AHB_BIT6_ALIAS->data=temp;
			break;
		case PortD_Pin7_:
			temp=!((Dio_LevelType)(GPIODATA_D_AHB_BIT7_ALIAS->data));
		  GPIODATA_D_AHB_BIT7_ALIAS->data=temp;
			break;
		case PortE_Pin0_:
			temp=!((Dio_LevelType)(GPIODATA_E_AHB_BIT0_ALIAS->data));
		  GPIODATA_E_AHB_BIT0_ALIAS->data=temp;
			break;
		case PortE_Pin1_:
			temp=!((Dio_LevelType)(GPIODATA_E_AHB_BIT1_ALIAS->data));
		  GPIODATA_E_AHB_BIT1_ALIAS->data=temp;
			break;
		case PortE_Pin2_:
			temp=!((Dio_LevelType)(GPIODATA_E_AHB_BIT2_ALIAS->data));
		  GPIODATA_E_AHB_BIT2_ALIAS->data=temp;
			break;
		case PortE_Pin3_:
			temp=!((Dio_LevelType)(GPIODATA_E_AHB_BIT3_ALIAS->data));
		  GPIODATA_E_AHB_BIT3_ALIAS->data=temp;
			break;
		case PortE_Pin4_:
			temp=!((Dio_LevelType)(GPIODATA_E_AHB_BIT4_ALIAS->data));
		  GPIODATA_E_AHB_BIT4_ALIAS->data=temp;
			break;
		case PortE_Pin5_:
			temp=!((Dio_LevelType)(GPIODATA_E_AHB_BIT5_ALIAS->data));
		  GPIODATA_E_AHB_BIT5_ALIAS->data=temp;
			break;
		case PortF_Pin0_:
			temp=!((Dio_LevelType)(GPIODATA_F_AHB_BIT0_ALIAS->data));
		  GPIODATA_F_AHB_BIT0_ALIAS->data=temp;
			break;
		case PortF_Pin1_:
			temp=!((Dio_LevelType)(GPIODATA_F_AHB_BIT1_ALIAS->data));
		  GPIODATA_F_AHB_BIT1_ALIAS->data=temp;
			break;
		case PortF_Pin2_:
			temp=!((Dio_LevelType)(GPIODATA_F_AHB_BIT2_ALIAS->data));
		  GPIODATA_F_AHB_BIT2_ALIAS->data=temp;
			break;
		case PortF_Pin3_:
			temp=!((Dio_LevelType)(GPIODATA_F_AHB_BIT3_ALIAS->data));
		  GPIODATA_F_AHB_BIT3_ALIAS->data=temp;
			break;
		case PortF_Pin4_:
			temp=!((Dio_LevelType)(GPIODATA_F_AHB_BIT4_ALIAS->data));
		  GPIODATA_F_AHB_BIT4_ALIAS->data=temp;
			break;
	}
	return temp;
	
}

Dio_PortLevelType Dio_ReadPort(Dio_PortType PortId)
{
	Dio_PortLevelType temp;
	switch(PortId)
	{
		case PortA:
			temp=((Dio_PortLevelType)(GPIO_PORT_A_AHB_GPIODATA->data));
			break;
		case PortB:
			temp=((Dio_PortLevelType)(GPIO_PORT_B_AHB_GPIODATA->data));
			break;
		case PortC:
			temp=((Dio_PortLevelType)(GPIO_PORT_C_AHB_GPIODATA->data));
			break;
		case PortD:
			temp=((Dio_PortLevelType)(GPIO_PORT_D_AHB_GPIODATA->data));
			break;
		case PortE:
			temp=((Dio_PortLevelType)(GPIO_PORT_E_AHB_GPIODATA->data));
			break;
		case PortF:
			temp=((Dio_PortLevelType)(GPIO_PORT_F_AHB_GPIODATA->data));
			break;
		
	}
	return temp;
}

void Dio_WritePort(Dio_PortType PortId,Dio_PortLevelType Level)
{
	switch(PortId)
	{
		case PortA:
			GPIO_PORT_A_AHB_GPIODATA->data=Level;
			break;
		case PortB:
		  GPIO_PORT_B_AHB_GPIODATA->data=Level;
			break;
		case PortC:
			GPIO_PORT_C_AHB_GPIODATA->data=Level;
			break;
		case PortD:
			GPIO_PORT_D_AHB_GPIODATA->data=Level;
			break;
		case PortE:
			GPIO_PORT_E_AHB_GPIODATA->data=Level;
			break;
		case PortF:
			GPIO_PORT_F_AHB_GPIODATA->data=Level;
			break;
		
	}
}
