/*
 * Port.h
 *
 * Created:
 *  Author: hossam
 */ 


#ifndef PORT_H_
#define PORT_H_
typedef enum
{
	DIO_A0,
	U0Rx,
	CAN1Rx=8
	
	
}PortA_Pin0Mode;

typedef enum
{
	DIO_A1,
	U0Tx,
	CAN1Tx
}PortA_Pin1Mode;
typedef enum
{
	DIO_A2,
	SSI0Clk
}PortA_Pin2Mode;
typedef enum
{
	DIO_A3,
	SSI0Fss=2
}PortA_Pin3Mode;
typedef enum
{
	DIO_A4,
	SSI0Rx=2
}PortA_Pin4Mode;
typedef enum
{
	DIO_A5,
	SSI0Tx=2
}PortA_Pin5Mode;
typedef enum
{
	DIO_A6,
	I2C1SCL=3,
	M1PWM2=5
}PortA_Pin6Mode;
typedef enum
{
	DIO_A7,
	I2C1SDA=3,
	M1PWM3=5,
	
}PortA_Pin7Mode;

typedef struct
{
  PortA_Pin0Mode A0;
	PortA_Pin1Mode A1;
	PortA_Pin2Mode A2;
	PortA_Pin3Mode A3;
	PortA_Pin4Mode A4;
	PortA_Pin5Mode A5;
	PortA_Pin6Mode A6;
	PortA_Pin7Mode A7;
}PortA_PinMode;
typedef enum
{
	DIO_B0,
	U1Rx,
	T2CCP0=7,
	USB0ID=16
	
}PortB_Pin0Mode;
typedef enum
{
	DIO_B1,
	U1Tx,
	T2CCP1=7,
	USB0VBUS=16
	
}PortB_Pin1Mode;
typedef enum
{
	DIO_B2,
	I2C0SCL=3,
	T3CCP0=7
}PortB_Pin2Mode;
typedef enum
{
	DIO_B3,
	I2C0SDA=3,
	T3CCP1=7
}PortB_Pin3Mode;
typedef enum
{
	DIO_B4,
	SSI2Clk=2,
	M0PWM2=4,
	T1CCP0=7,
	CAN0Rx,
	AIN10=16
}PortB_Pin4Mode;
typedef enum
{
	DIO_B5,
	SSI2Fss=2,
	M0PWM3=4,
	T1CCP1=7,
	CAN0Tx,
	AIN11=16
}PortB_Pin5Mode;
typedef enum
{
	DIO_B6,
	SSI2Rx=2,
	M0PWM0=4,
	T0CCP0=7
}PortB_Pin6Mode;
typedef enum
{
	DIO_B7,
	SSI2Tx=2,
	M0PWM1=4,
	T0CCP1=7
}PortB_Pin7Mode;


typedef struct
{
  PortB_Pin0Mode B0;
	PortB_Pin1Mode B1;
	PortB_Pin2Mode B2;
	PortB_Pin3Mode B3;
	PortB_Pin4Mode B4;
	PortB_Pin5Mode B5;
	PortB_Pin6Mode B6;
	PortB_Pin7Mode B7;
}PortB_PinMode;


typedef enum
{
	DIO_C0,
	TCK_SWCLK,
	T4CCP0=7
}PortC_Pin0Mode;
typedef enum
{
	DIO_C1,
	TMS_SWDIO,
	T4CCP1=7,
}PortC_Pin1Mode;
typedef enum
{
	DIO_C2,
	TDI,
	T5CCP0=7,
}PortC_Pin2Mode;
typedef enum
{
	DIO_C3,
	TDO_SWO,
	T5CCP1=7,
}PortC_Pin3Mode;
typedef enum
{
	DIO_C4,
	U4Rx,
	U1Rx_,
	M0PWM6=4,
	IDX1=6,
	WT0CCP0,
	U1RTS,
	C1_MINUS=16
}PortC_Pin4Mode;
typedef enum
{
	DIO_C5,
	U4Tx,
	U1Tx_,
	M0PWM7=4,
	PhA1=6,
	WT0CCP1,
	U1CTS,
	C1_PLUS=16
}PortC_Pin5Mode;
typedef enum
{
	DIO_C6,
	U3Rx,
	PhB1=6,
	WT1CCP0,
	USB0EPEN,
	C0_PLUS=16
}PortC_Pin6Mode;
typedef enum
{
	DIO_C7,
	U3Tx,
	WT1CCP1=7,
	USB0PFLT,
	C0_MINUS=16
}PortC_Pin7Mode;

typedef struct
{
  PortC_Pin0Mode C0;
	PortC_Pin1Mode C1;
	PortC_Pin2Mode C2;
	PortC_Pin3Mode C3;
	PortC_Pin4Mode C4;
	PortC_Pin5Mode C5;
	PortC_Pin6Mode C6;
	PortC_Pin7Mode C7;
}PortC_PinMode;

typedef enum
{
	DIO_D0,
	SSI3Clk,
	SSI1Clk,
	I2C3SCL,
	M0PWM6_,
	M1PWM0,
	WT2CCP0=7,
	AIN7=16
}PortD_Pin0Mode;
typedef enum
{
	DIO_D1,
	SSI3Fss,
	SSI1Fss,
	I2C3SDA,
	M0PWM7_,
	M1PWM1,
	WT2CCP1=7,
	AIN6=16
}PortD_Pin1Mode;
typedef enum
{
	DIO_D2,
	SSI3Rx,
	SSI1Rx,
	M0FAULT0=4,
	WT3CCP0=7,
	USB0EPEN_,
	AIN5=16
}PortD_Pin2Mode;
typedef enum
{
	DIO_D3,
	SSI3Tx,
	SSI1Tx,
	IDX0=6,
	WT3CCP1,
	USB0PFLT_
}PortD_Pin3Mode;
typedef enum
{
	DIO_D4,
	U6Rx,
	WT4CCP0=7,
	AIN4=16
}PortD_Pin4Mode;
typedef enum
{
	DIO_D5,
	U6Tx,
	WT4CCP1=7,
	USB0DM=16
}PortD_Pin5Mode;
typedef enum
{
	DIO_D6,
	U2Rx,
	M0FAULT0_=4,
	PhA0=6,
	WT5CCP0,
	USB0DP=16
}PortD_Pin6Mode;
typedef enum
{
	DIO_D7,
	U2Tx,
	PhB0=6,
	WT5CCP1,
	NMI
}PortD_Pin7Mode;


typedef struct
{
  PortD_Pin0Mode D0;
	PortD_Pin1Mode D1;
	PortD_Pin2Mode D2;
	PortD_Pin3Mode D3;
	PortD_Pin4Mode D4;
	PortD_Pin5Mode D5;
	PortD_Pin6Mode D6;
	PortD_Pin7Mode D7;
}PortD_PinMode;





typedef enum
{
	DIO_E0,
	U7Rx
}PortE_Pin0Mode;
typedef enum
{
	DIO_E1,
	U7Tx,
	AIN3=16
}PortE_Pin1Mode;
typedef enum
{
	DIO_E2,
	AIN2=16
}PortE_Pin2Mode;
typedef enum
{
	DIO_E3,
	AIN1=16
}PortE_Pin3Mode;
typedef enum
{
	DIO_E4,
	U5Rx=3,
	M0PWM4,
	M1PWM2_,
	CAN0Rx_=8,
	AIN0=16
}PortE_Pin4Mode;
typedef enum
{
	DIO_E5,
	U5Tx,
	I2C2SDA=3,
	M0PWM5,
	M1PWM3_,
	CAN0Tx_=8,
	AIN9=16
}PortE_Pin5Mode;


typedef struct
{
  PortE_Pin0Mode E0;
	PortE_Pin1Mode E1;
	PortE_Pin2Mode E2;
	PortE_Pin3Mode E3;
	PortE_Pin4Mode E4;
	PortE_Pin5Mode E5;

}PortE_PinMode;





typedef enum
{
	DIO_F0,
	U1RTS_,
	SSI1Rx_,
	CAN0Rx__,
	M1PWM4=5,
	PhA0_,
	T0CCP0_,
	NMI_,
	C0o,
	AIN8=16
}PortF_Pin0Mode;
typedef enum
{
	DIO_F1,
	U1CTS_,
	SSI1Tx_,
	M1PWM5=5,
	PhB0_,
	T0CCP1_,
	C1o=9,
	TRD1=14,
}PortF_Pin1Mode;
typedef enum
{
	DIO_F2,
	SSI1Clk_=2,
	M0FAULT0__=4,
	M1PWM6,
	T1CCP0_=7,
	TRD0=14
	
}PortF_Pin2Mode;
typedef enum
{
	DIO_F3,
	SSI1Fss_=2,
	CAN0Tx__,
	M1PWM7=5,
	T1CCP1_=7,
	TRCLK=14
}PortF_Pin3Mode;
typedef enum
{
	DIO_F4,
	M1FAULT0=5,
	IDX0_,
	T2CCP0_,
	USB0EPEN__
}PortF_Pin4Mode;


typedef struct
{
  PortF_Pin0Mode F0;
	PortF_Pin1Mode F1;
	PortF_Pin2Mode F2;
	PortF_Pin3Mode F3;
	PortF_Pin4Mode F4;

}PortF_PinMode;

typedef struct
{
	PortA_PinMode PortA;
	PortB_PinMode PortB;
	PortC_PinMode PortC;
	PortD_PinMode PortD;
  PortE_PinMode PortE;
	PortF_PinMode PortF;
}Port_PinMode;




typedef enum
{
	Input,
	Output
}Port_PinDirection;


typedef enum
{
	PullUp,
	PullDown,
	OpenDrain
}Port_PinInternalAttach;

typedef struct
{
	Port_PinInternalAttach Pin0InternalAttach;
	Port_PinInternalAttach Pin1InternalAttach;
	Port_PinInternalAttach Pin2InternalAttach;
	Port_PinInternalAttach Pin3InternalAttach;
	Port_PinInternalAttach Pin4InternalAttach;
	Port_PinInternalAttach Pin5InternalAttach;
	Port_PinInternalAttach Pin6InternalAttach;
	Port_PinInternalAttach Pin7InternalAttach;
}Port_A_TO_D_InternalAttach;

typedef struct
{
	Port_PinInternalAttach Pin0InternalAttach;
	Port_PinInternalAttach Pin1InternalAttach;
	Port_PinInternalAttach Pin2InternalAttach;
	Port_PinInternalAttach Pin3InternalAttach;
	Port_PinInternalAttach Pin4InternalAttach;
	Port_PinInternalAttach Pin5InternalAttach;

}Port_E_InternalAttach;
typedef struct
{
	Port_PinInternalAttach Pin0InternalAttach;
	Port_PinInternalAttach Pin1InternalAttach;
	Port_PinInternalAttach Pin2InternalAttach;
	Port_PinInternalAttach Pin3InternalAttach;
	Port_PinInternalAttach Pin4InternalAttach;


}Port_F_InternalAttach;
typedef struct
{
	Port_A_TO_D_InternalAttach      PortA_InternalAttach   ;
	Port_A_TO_D_InternalAttach      PortB_InternalAttach   ;
	Port_A_TO_D_InternalAttach      PortC_InternalAttach   ;
	Port_A_TO_D_InternalAttach      PortD_InternalAttach   ;
	Port_E_InternalAttach      PortE_InternalAttach   ;
	Port_F_InternalAttach      PortF_InternalAttach  ;
}Port_InternalAttach;

typedef enum
{
	_2mA,
	_4mA,
	_8mA
}Port_PinOutputCurrent;

typedef struct
{
	Port_PinOutputCurrent Pin0OutputCurrent;
	Port_PinOutputCurrent Pin1OutputCurrent;
	Port_PinOutputCurrent Pin2OutputCurrent;
	Port_PinOutputCurrent Pin3OutputCurrent;
	Port_PinOutputCurrent Pin4OutputCurrent;
	Port_PinOutputCurrent Pin5OutputCurrent;
	Port_PinOutputCurrent Pin6OutputCurrent;
	Port_PinOutputCurrent Pin7OutputCurrent;
}Port_A_TO_D_OutputCurrent;

typedef struct
{
	Port_PinOutputCurrent Pin0OutputCurrent;
	Port_PinOutputCurrent Pin1OutputCurrent;
	Port_PinOutputCurrent Pin2OutputCurrent;
	Port_PinOutputCurrent Pin3OutputCurrent;
	Port_PinOutputCurrent Pin4OutputCurrent;
	Port_PinOutputCurrent Pin5OutputCurrent;


}Port_E_OutputCurrent;
typedef struct
{
  Port_PinOutputCurrent Pin0OutputCurrent;
	Port_PinOutputCurrent Pin1OutputCurrent;
	Port_PinOutputCurrent Pin2OutputCurrent;
	Port_PinOutputCurrent Pin3OutputCurrent;
	Port_PinOutputCurrent Pin4OutputCurrent;



}Port_F_OutputCurrent;
typedef struct
{
	Port_A_TO_D_OutputCurrent       PortA_OutputCurrent;
	Port_A_TO_D_OutputCurrent       PortB_OutputCurrent;
	Port_A_TO_D_OutputCurrent       PortC_OutputCurrent;
	Port_A_TO_D_OutputCurrent       PortD_OutputCurrent;
	Port_E_OutputCurrent       PortE_OutputCurrent;
	Port_F_OutputCurrent       PortF_OutputCurrent;
}Port_OutputCurrent;
typedef enum
	{
		LOW,
		HIGH,
  }Port_PinLevel;
typedef enum
	{

		PortA,
		PortB,
		PortC,
		PortD,
		PortE,
		PortF,
  }Port_Type;	
	
	typedef enum
	{
		PortA_Pin0,
		PortA_Pin1,
		PortA_Pin2,
		PortA_Pin3,
		PortA_Pin4,
		PortA_Pin5,
		PortA_Pin6,
		PortA_Pin7,
  } Port_A_PinType;	
	typedef enum
	{
		PortB_Pin0,
		PortB_Pin1,
		PortB_Pin2,
		PortB_Pin3,
		PortB_Pin4,
		PortB_Pin5,
		PortB_Pin6,
		PortB_Pin7,
  } Port_B_PinType;
	typedef enum
	{
		PortC_Pin0,
		PortC_Pin1,
		PortC_Pin2,
		PortC_Pin3,
		PortC_Pin4,
		PortC_Pin5,
		PortC_Pin6,
		PortC_Pin7,
  } Port_C_PinType;
	typedef enum
	{
		PortD_Pin0,
		PortD_Pin1,
		PortD_Pin2,
		PortD_Pin3,
		PortD_Pin4,
		PortD_Pin5,
		PortD_Pin6,
		PortD_Pin7,
  } Port_D_PinType;
	typedef enum
	{
		PortE_Pin0,
		PortE_Pin1,
		PortE_Pin2,
		PortE_Pin3,
		PortE_Pin4,
		PortE_Pin5,

  }Port_E_PinType;
	typedef enum
	{
		PortF_Pin0,
		PortF_Pin1,
		PortF_Pin2,
		PortF_Pin3,
		PortF_Pin4,
		

  }Port_F_PinType;
	
typedef struct
	{
		Port_A_PinType PortA_Pins ;
    Port_B_PinType PortB_Pins ;	
    Port_C_PinType PortC_Pins ;	
    Port_D_PinType PortD_Pins ;		
		Port_E_PinType PortE_Pins;
		Port_F_PinType PortF_Pins;

  }Port_PinType;	
typedef struct
{
	Port_Type     Port;
	Port_PinType  PinType;
	Port_PinDirection PinDirection;
	Port_PinLevel PinLevel;
	Port_PinMode PinMode ;
	Port_InternalAttach InternalAttach;
	Port_OutputCurrent  OutputCurrent;
}Port_Config;

void Port_Init(const Port_Config* ConfigPtr);

#endif /* PORT_H_ */
