/*
 * ClkCtrl.h
 *
 * Created: 
 *  Author: hossam
 */ 


#ifndef CLKCTRL_H_
#define CLKCTRL_H_
#include "Mcu_Hw.h"
#include "ClkCtrl_Cfg.h"

void ClkCtrl_Init(void);

#endif /* CLKCTRL_H_ */
