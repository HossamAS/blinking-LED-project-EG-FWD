/*
 * GPT.h
 *
 *  Author: hossam
 */ 


#ifndef GPT_H_
#define GPT_H_
#include "Std_Types.h"
#define  EN    1
#define  DIS   0

#define GPT_Predef_TIMER_1US_16BIT_     DIS
#define GPT_Predef_TIMER_1US_24BIT_     DIS
#define GPT_Predef_TIMER_1US_32BIT_     DIS
#define GPT_Predef_TIMER_128US_32BIT_   DIS



typedef UINT32_L GPT_ValueType;
typedef UINT8_C Std_ReturnType; 
typedef enum
{
	 One_Shot=1,
   Periodic,
	 PWM_One_Shot=5,
	 PWM_Periodic=6,
}GPT_ChannelModeType;

typedef enum
	{
		GPT_0_A_16BIT,
		GPT_1_A_16BIT,
		GPT_2_A_16BIT,
		GPT_3_A_16BIT,
		GPT_4_A_16BIT,
		GPT_5_A_16BIT,
		GPWT_0_A_32BIT,
		GPWT_1_A_32BIT,
		GPWT_2_A_32BIT,
		GPWT_3_A_32BIT,
		GPWT_4_A_32BIT,
		GPWT_5_A_32BIT,
		GPT_0_B_16BIT,
		GPT_1_B_16BIT,
		GPT_2_B_16BIT,
		GPT_3_B_16BIT,
		GPT_4_B_16BIT,
		GPT_5_B_16BIT,
		GPWT_0_B_32BIT,
		GPWT_1_B_32BIT,
		GPWT_2_B_32BIT,
		GPWT_3_B_32BIT,
		GPWT_4_B_32BIT,
		GPWT_5_B_32BIT,
		GPT_0_32BIT,
		GPT_1_32BIT,
		GPT_2_32BIT,
		GPT_3_32BIT,
		GPT_4_32BIT,
		GPT_5_32BIT,
		GPWT_0_64BIT,
		GPWT_1_64BIT,
		GPWT_2_64BIT,
		GPWT_3_64BIT,
		GPWT_4_64BIT,
		GPWT_5_64BIT,
	}GPT_ChannelType;

	typedef enum
	{
		Time_Out,
		PWM
		
	}GPT_InterruptType;
typedef struct
{
 
 void (*GPT_Notification)(void);
 UINT32_L TickValueMax; 
 UINT8_C TickFrequancy;	
 GPT_ChannelModeType   ChannelMode;
 GPT_ChannelType  Channel;
}GPT_Config;


typedef enum
{
 GPT_Predef_TIMER_1US_16BIT,
 GPT_Predef_TIMER_1US_24BIT,
 GPT_Predef_TIMER_1US_32BIT,
 GPT_Predef_TIMER_128US_32BIT
}GPT_PredefTimerType;



void GPT_Init(const GPT_Config* ConfigPtr);
void GPT_DisableNotification(GPT_ChannelType Channel,GPT_InterruptType Interrupt);
void GPT_EableNotification(GPT_ChannelType Channel,GPT_InterruptType Interrupt);
void GPT_StartTimer(GPT_ChannelType Channel,GPT_ValueType Value);
void GPT_StopTimer(GPT_ChannelType Channel);

GPT_ValueType GPT_GetTimeElapsed(GPT_ChannelType Channel);
GPT_ValueType GPT_GetTimeRemaining(GPT_ChannelType Channel);
Std_ReturnType GPT_GetPredefTimerValue(GPT_PredefTimerType PredefTimer,UINT32_L* TimeValuePtr);




typedef struct{
 void (*GPT_Notification_GPT0A)(void);
 void (*GPT_Notification_GPT1A)(void);
 void (*GPT_Notification_GPT2A)(void);
 void (*GPT_Notification_GPT3A)(void);
 void (*GPT_Notification_GPT4A)(void);
 void (*GPT_Notification_GPT5A)(void);
 void (*GPT_Notification_GPWT0A)(void);
 void (*GPT_Notification_GPWT1A)(void);
 void (*GPT_Notification_GPWT2A)(void);
 void (*GPT_Notification_GPWT3A)(void);
 void (*GPT_Notification_GPWT4A)(void);
 void (*GPT_Notification_GPWT5A)(void);
 void (*GPT_Notification_GPT0B)(void);
 void (*GPT_Notification_GPT1B)(void);
 void (*GPT_Notification_GPT2B)(void);
 void (*GPT_Notification_GPT3B)(void);
 void (*GPT_Notification_GPT4B)(void);
 void (*GPT_Notification_GPT5B)(void);
 void (*GPT_Notification_GPWT0B)(void);
 void (*GPT_Notification_GPWT1B)(void);
 void (*GPT_Notification_GPWT2B)(void);
 void (*GPT_Notification_GPWT3B)(void);
 void (*GPT_Notification_GPWT4B)(void);
 void (*GPT_Notification_GPWT5B)(void);
}Ptr_Notification_Functions;
 
void	TIMER0A_Handler(void);

void	TIMER1A_Handler(void);

void	TIMER2A_Handler(void);
	
void	TIMER3A_Handler(void);
	
void	TIMER4A_Handler(void);
	
void	TIMER5A_Handler(void);
	
void	WTIMER0A_Handler(void);
	
void	WTIMER1A_Handler(void);
	
void	WTIMER2A_Handler(void);
	
void	WTIMER3A_Handler(void);
	
void	WTIMER4A_Handler(void);
	
void	WTIMER5A_Handler(void);
	
void	TIMER0B_Handler(void);
	
void	TIMER1B_Handler(void);
	
void	TIMER2B_Handler(void);
	
void	TIMER3B_Handler(void);
	
void	TIMER4B_Handler(void);

void	TIMER5B_Handler(void);

void	WTIMER0B_Handler(void);

void	WTIMER1B_Handler(void);

void	WTIMER2B_Handler(void);
	
void	WTIMER3B_Handler(void);

void	WTIMER4B_Handler(void);
	
void	WTIMER5B_Handler(void);
	
#endif /* GPT_H_ */
