/*
 * DIO.h
 *
 * Created: 16/03/2019 12:12:03 ?
 *  Author: hossam
 */ 


#ifndef DIO_H_
#define DIO_H_
#include "Port.h"
#include "Std_Types.h"

typedef enum
{
	PortA_Pin0_,
	PortA_Pin1_,
	PortA_Pin2_,
	PortA_Pin3_,
	PortA_Pin4_,
	PortA_Pin5_,
	PortA_Pin6_,
	PortA_Pin7_,
	PortB_Pin0_,
	PortB_Pin1_,
	PortB_Pin2_,
	PortB_Pin3_,
	PortB_Pin4_,
	PortB_Pin5_,
	PortB_Pin6_,
	PortB_Pin7_,
	PortC_Pin0_,
	PortC_Pin1_,
	PortC_Pin2_,
	PortC_Pin3_,
	PortC_Pin4_,
	PortC_Pin5_,
	PortC_Pin6_,
	PortC_Pin7_,
	PortD_Pin0_,
	PortD_Pin1_,
	PortD_Pin2_,
	PortD_Pin3_,
	PortD_Pin4_,
	PortD_Pin5_,
	PortD_Pin6_,
	PortD_Pin7_,
	PortE_Pin0_,
	PortE_Pin1_,
	PortE_Pin2_,
	PortE_Pin3_,
	PortE_Pin4_,
	PortE_Pin5_,
	PortF_Pin0_,
	PortF_Pin1_,
	PortF_Pin2_,
	PortF_Pin3_,
	PortF_Pin4_,

}Dio_ChannelType;

typedef Port_PinLevel   Dio_LevelType;
typedef Port_Type Dio_PortType;


#define Dio_PortLevelType UINT8_C

Dio_LevelType Dio_ReadChannel(Dio_ChannelType ChannelId);
void Dio_WriteChannel(Dio_ChannelType ChannelId,Dio_LevelType Level);
Dio_PortLevelType Dio_ReadPort(Dio_PortType PortId);
void Dio_WritePort(Dio_PortType PortId,Dio_PortLevelType Level);
Dio_LevelType Dio_FlipChannel(Dio_ChannelType ChannelId);


#endif /* DIO_H_ */

