/*
 * IntCtrl.h
 *
 */ 


#ifndef INTCTRL_H_
#define INTCTRL_H_

void SVC_Handler(void);

void IntCtrl_Init(void);

#endif /* INTCTRL_H_ */
