/*
 * SysTick_T.h
 *
 * Created: 
 *  Author: hossam
 */ 


#ifndef SYSTICK_T_H_
#define SYSTICK_T_H_
#include "Std_Types.h"
#define _4MHZ        0
#define System_Clock 4

#define Clock_Source System_Clock

void SysTick_Init(void);
#define SysTick_SetTickValue(TickValue) STRELOAD->data=TickValue
#define SysTick_Enable()      STCTRL->data= STCTRL->data|0x00000001
#define SysTick_Disable()     STCTRL->data= STCTRL->data&0xfffffffD
#define SysTick_Notification_Enable()      STCTRL->data= STCTRL->data|0x00000002
#define SysTick_Notification_Disable()     STCTRL->data= STCTRL->data&0xfffffffD
void SysTick_Handler(void);
#endif /* SYSTICK_T_H_ */
