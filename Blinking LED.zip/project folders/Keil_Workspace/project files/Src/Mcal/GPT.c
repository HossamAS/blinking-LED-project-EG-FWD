



#include "GPT.h"




#include "Mcu_Hw.h"



SINT8_C Ignored_Bits[24];
UINT32_L MAX_VALUE[24];
UINT8_C  Concatonation_state[12];
 
Ptr_Notification_Functions Notification_Functions;
void GPT_Init(const GPT_Config* ConfigPtr)
{
 
UINT8_C	Prescaler=16/ConfigPtr->TickFrequancy; 	

	switch(ConfigPtr->Channel)
	{ 
		case GPT_0_32BIT:
		Concatonation_state[0]=1;
		case GPT_0_A_16BIT:
		RCGCTIMER->data=RCGCTIMER->data|1;
		GPT_0_GPTMCTL_BIT0_ALIAS->data=0;
		
		
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_0_GPTMTAMR_BIT2_ALIAS->data=0;
		GPT_0_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPT_0_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_0_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_0_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPT0A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPT_0_32BIT)
		{
			GPT_0_GPTMCFG->data=0;
		}
		else
		{
			GPT_0_GPTMCFG->data=4;
		}
		
		  

 	Ignored_Bits[GPT_0_A_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_0_A_16BIT]++;
	  }
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;
		case GPT_1_32BIT:
			Concatonation_state[1]=1;
		case GPT_1_A_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|2;
		GPT_1_GPTMCTL_BIT0_ALIAS->data=0;
		
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_1_GPTMTAMR_BIT2_ALIAS->data=0;
		GPT_1_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPT_1_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_1_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_1_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPT1A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPT_1_32BIT)
		{
			GPT_1_GPTMCFG->data=0;
		}
		else
		{
			GPT_1_GPTMCFG->data=4;
		}
		Ignored_Bits[GPT_1_A_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_1_A_16BIT]++;
	  }
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;
		case GPT_2_32BIT:
			Concatonation_state[2]=1;
		case GPT_2_A_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|4;
		GPT_2_GPTMCTL_BIT0_ALIAS->data=0;
		
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_2_GPTMTAMR_BIT2_ALIAS->data=0;
		GPT_2_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPT_2_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_2_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_2_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPT2A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPT_2_32BIT)
		{
			GPT_2_GPTMCFG->data=0;
		}
		else
		{
			GPT_2_GPTMCFG->data=4;
		}
		Ignored_Bits[GPT_2_A_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_2_A_16BIT]++;
	  }
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;	
		case GPT_3_32BIT:
			Concatonation_state[3]=1;
		case GPT_3_A_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|8;
			GPT_3_GPTMCTL_BIT0_ALIAS->data=0;
		
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_3_GPTMTAMR_BIT2_ALIAS->data=0;
		GPT_3_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPT_3_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_3_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_3_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPT3A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPT_3_32BIT)
		{
			GPT_3_GPTMCFG->data=0;
		}
		else
		{
			GPT_3_GPTMCFG->data=4;
		}
		Ignored_Bits[GPT_3_A_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_3_A_16BIT]++;
	  }
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;	
		case GPT_4_32BIT:
			Concatonation_state[4]=1;
		case GPT_4_A_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|16;
		GPT_4_GPTMCTL_BIT0_ALIAS->data=0;
		
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_4_GPTMTAMR_BIT2_ALIAS->data=0;
		GPT_4_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPT_4_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_4_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_4_GPTMTAMR_BIT4_ALIAS->data=1;
		Notification_Functions.GPT_Notification_GPT4A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPT_4_32BIT)
		{
			GPT_4_GPTMCFG->data=0;
		}
		else
		{
			GPT_4_GPTMCFG->data=4;
		}
		Ignored_Bits[GPT_4_A_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_4_A_16BIT]++;
	  }
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;	
		case GPT_5_32BIT:
			Concatonation_state[5]=1;
		case GPT_5_A_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|32;
		GPT_5_GPTMCTL_BIT0_ALIAS->data=0;
		
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_5_GPTMTAMR_BIT2_ALIAS->data=0;
		GPT_5_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPT_5_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_5_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_5_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPT5A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPT_5_32BIT)
		{
			GPT_5_GPTMCFG->data=0;
		}
		else
		{
			GPT_5_GPTMCFG->data=4;
		}
		Ignored_Bits[GPT_5_A_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_5_A_16BIT]++;
	  }
	
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		
		break;	
		case GPWT_0_64BIT:
			Concatonation_state[6]=1;
		case GPWT_0_A_32BIT:
		RCGCWTIMER->data=RCGCWTIMER->data|1;
		GPWT_0_GPTMCTL_BIT0_ALIAS->data=0;
		
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_0_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_0_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPWT_0_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_0_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_0_GPTMTAMR_BIT4_ALIAS->data=1;
		
		
		Notification_Functions.GPT_Notification_GPWT0A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPWT_0_64BIT)
		{
			GPWT_0_GPTMCFG->data=0;
		}
		else
		{
			GPWT_0_GPTMCFG->data=4;
		}
		Ignored_Bits[GPWT_0_A_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_0_A_32BIT]++;
	  }
	
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;
    case GPWT_1_64BIT:
			Concatonation_state[7]=1;		
		case GPWT_1_A_32BIT:
		RCGCWTIMER->data=RCGCWTIMER->data|2;
		GPWT_1_GPTMCTL_BIT0_ALIAS->data=0;
		
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_1_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_1_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPWT_1_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_1_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_1_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT1A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPWT_1_64BIT)
		{
			GPWT_1_GPTMCFG->data=0;
		}
		else
		{
			GPWT_1_GPTMCFG->data=4;
		}
		Ignored_Bits[GPWT_1_A_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_1_A_32BIT]++;
	  }
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		
		break;
    case GPWT_2_64BIT:	
			Concatonation_state[8]=1;			
		case GPWT_2_A_32BIT:
		RCGCWTIMER->data=RCGCWTIMER->data|4;
		GPWT_2_GPTMCTL_BIT0_ALIAS->data=0;
		GPWT_2_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_2_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_2_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPWT_2_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_2_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_2_GPTMTAMR_BIT4_ALIAS->data=1;
		
		
		Notification_Functions.GPT_Notification_GPWT2A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPWT_2_64BIT)
		{
			GPWT_2_GPTMCFG->data=0;
		}
		else
		{
			GPWT_2_GPTMCFG->data=4;
		}
		Ignored_Bits[GPWT_2_A_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_2_A_32BIT]++;
	  }
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;
    case GPWT_3_64BIT:	
			Concatonation_state[9]=1;		
		case GPWT_3_A_32BIT:
		RCGCWTIMER->data=RCGCWTIMER->data|8;
		GPWT_3_GPTMCTL_BIT0_ALIAS->data=0;
		GPWT_3_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_3_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_3_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPWT_3_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_3_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_3_GPTMTAMR_BIT4_ALIAS->data=1;
		
		
		Notification_Functions.GPT_Notification_GPWT3A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPWT_3_64BIT)
		{
			GPWT_3_GPTMCFG->data=0;
		}
		else
		{
			GPWT_3_GPTMCFG->data=4;
		}
		Ignored_Bits[GPWT_3_A_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_3_A_32BIT]++;
	  }
		
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;	
    case GPWT_4_64BIT:	
			Concatonation_state[10]=1;	
		case GPWT_4_A_32BIT:
		RCGCWTIMER->data=RCGCWTIMER->data|16;
		GPWT_4_GPTMCTL_BIT0_ALIAS->data=0;
		
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_4_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_4_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPWT_4_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_4_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_4_GPTMTAMR_BIT4_ALIAS->data=1;
		
		
		Notification_Functions.GPT_Notification_GPWT4A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPWT_4_64BIT)
		{
			GPWT_4_GPTMCFG->data=0;
		}
		else
		{
			GPWT_4_GPTMCFG->data=4;
		}
		Ignored_Bits[GPWT_4_A_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_4_A_32BIT]++;
	  }
	
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;	
    case GPWT_5_64BIT:		
			Concatonation_state[11]=1;
		case GPWT_5_A_32BIT:
#if((GPT_Predef_TIMER_1US_16BIT_==DIS)&&(GPT_Predef_TIMER_1US_24BIT_==DIS)&&(GPT_Predef_TIMER_1US_32BIT_==DIS)&&(GPT_Predef_TIMER_128US_32BIT_==DIS))

		RCGCWTIMER->data=RCGCWTIMER->data|32;
		GPWT_5_GPTMCTL_BIT0_ALIAS->data=0;
		
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_5_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_5_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPWT_5_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_5_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_5_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT5A=ConfigPtr->GPT_Notification;
		if(ConfigPtr->Channel==GPWT_5_64BIT)
		{
			GPWT_5_GPTMCFG->data=0;	
		}
		else
		{
			GPWT_5_GPTMCFG->data=4;
		}
		Ignored_Bits[GPWT_5_A_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_5_A_32BIT]++;
	  }
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		#endif
		#if(GPT_Predef_TIMER_1US_16BIT_==EN)

		RCGCWTIMER->data=RCGCTIMER->data|32;
		GPWT_5_GPTMCTL_BIT8_ALIAS->data=0;
		if(ConfigPtr->Channel==GPWT_5_64BIT)
		{
			GPWT_5_GPTMCFG->data=0;
		GPWT_5_GPTMTBILR->data=0;	
		}
		else
		{
			GPWT_5_GPTMCFG->data=4;
		GPWT_5_GPTMTAPR->data=0;	
		}
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_5_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_5_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
	  
		GPWT_5_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_5_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_5_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT5B=ConfigPtr->GPT_Notification;

		MAX_VALUE[ConfigPtr->Channel]=65535;
		GPWT_5_GPTMTAILR->data=(0X0000FFFF&ConfigPtr->TickValueMax)<<4;
		GPWT_5_GPTMTAPR->data=0;
		GPWT_5_GPTMCTL_BIT8_ALIAS->data=1;
		
		
	#endif
		#if(GPT_Predef_TIMER_1US_24BIT_==EN)
		RCGCWTIMER->data=RCGCTIMER->data|32;
		GPWT_5_GPTMCTL_BIT8_ALIAS->data=0;
		if(ConfigPtr->Channel==GPWT_5_64BIT)
		{
			GPWT_5_GPTMCFG->data=0;
			GPWT_5_GPTMTBILR->data=0;	
		}
		else
		{
			GPWT_5_GPTMCFG->data=4;
			GPWT_5_GPTMTAPR->data=0;	
		}
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_5_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_5_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
	 
		GPWT_5_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_5_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_5_GPTMTAMR_BIT4_ALIAS->data=1;
	
		Notification_Functions.GPT_Notification_GPWT5B=ConfigPtr->GPT_Notification;

		MAX_VALUE[ConfigPtr->Channel]=0X01FFFFFF;
		if(ConfigPtr->Concatonation_Mode==ON)
		{
	  }
		GPWT_5_GPTMTAILR->data=(0X01FFFFFF&(ConfigPtr->TickValueMax))<<4;
		
		GPWT_5_GPTMCTL_BIT8_ALIAS->data=1;
		
		
		#endif
		#if(GPT_Predef_TIMER_1US_32BIT_==EN)
		RCGCWTIMER->data=RCGCTIMER->data|32;
		GPWT_5_GPTMCTL_BIT8_ALIAS->data=0;
		if(ConfigPtr->Channel==GPWT_5_64BIT)
		{
			GPWT_5_GPTMCFG->data=0;
			GPWT_5_GPTMTBILR->data=((ConfigPtr->TickValueMax)>>28);
		}
		else
		{
			GPWT_5_GPTMCFG->data=4;
			GPWT_5_GPTMTAPR->data=((ConfigPtr->TickValueMax)>>28);
		}
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		
	  GPWT_5_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_5_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		
		GPWT_5_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_5_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_5_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT5B=ConfigPtr->GPT_Notification;

		MAX_VALUE[ConfigPtr->Channel]=0XFFFFFFFF;
		if(ConfigPtr->Concatonation_Mode==ON)
		{
	  }
		GPWT_5_GPTMTAILR->data=(ConfigPtr->TickValueMax)<<4;
		
		GPWT_5_GPTMCTL_BIT8_ALIAS->data=1;
		
		
		#endif
		#if(GPT_Predef_TIMER_128US_32BIT_==EN)
		RCGCWTIMER->data=RCGCTIMER->data|32;
		GPWT_5_GPTMCTL_BIT0_ALIAS->data=0;
		GPWT_5_GPTMTAILR->data=(ConfigPtr->TickValueMax)<<10;
		 
		if(ConfigPtr->Channel==GPWT_5_64BIT)
		{
			GPWT_5_GPTMCFG->data=0;
			GPWT_5_GPTMTBILR->data=(ConfigPtr->TickValueMax)>>22;
		}
		else
		{
			GPWT_5_GPTMCFG->data=4;
			 GPWT_5_GPTMTAPR->data=(ConfigPtr->TickValueMax)>>22;
		}
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_5_GPTMTAMR_BIT2_ALIAS->data=0;
		GPWT_5_GPTMTAMR_BIT3_ALIAS->data=1;
	  }
		GPWT_5_GPTMTAMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_5_GPTMTAMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_5_GPTMTAMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT5B=ConfigPtr->GPT_Notification;

		MAX_VALUE[ConfigPtr->Channel]=0XFFFFFFFF;
		
		
		GPWT_5_GPTMCTL_BIT8_ALIAS->data=1;
		
		
		#endif
		break;
    case GPT_0_B_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|1;
		GPT_0_GPTMCTL_BIT8_ALIAS->data=0;
		GPT_0_GPTMCFG->data=4;
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_0_GPTMTBMR_BIT2_ALIAS->data=0;
		GPT_0_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPT_0_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_0_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_0_GPTMTBMR_BIT4_ALIAS->data=1;
		
    Notification_Functions.GPT_Notification_GPT0B=ConfigPtr->GPT_Notification;	
    Ignored_Bits[GPT_0_B_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_0_B_16BIT]++;
	  }
		
		
				
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;	
		break;
		case GPT_1_B_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|2;
		GPT_1_GPTMCTL_BIT8_ALIAS->data=0;
		GPT_1_GPTMCFG->data=4;
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_1_GPTMTBMR_BIT2_ALIAS->data=0;
		GPT_1_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPT_1_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_1_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_5_GPTMTBMR_BIT4_ALIAS->data=1;
		
    Notification_Functions.GPT_Notification_GPT1B=ConfigPtr->GPT_Notification;
     Ignored_Bits[GPT_1_B_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_1_B_16BIT]++;
	  }
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		break;
		case GPT_2_B_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|4;
			GPT_2_GPTMCTL_BIT8_ALIAS->data=0;
		GPT_2_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_2_GPTMTBMR_BIT2_ALIAS->data=0;
		GPT_2_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPT_2_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_2_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_2_GPTMTBMR_BIT4_ALIAS->data=1;
		
    Notification_Functions.GPT_Notification_GPT2B=ConfigPtr->GPT_Notification;
     Ignored_Bits[GPT_2_B_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_2_B_16BIT]++;
	  }
		
	
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
							
		break;	
		case GPT_3_B_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|8;
		GPT_3_GPTMCTL_BIT8_ALIAS->data=0;
		GPT_3_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_3_GPTMTBMR_BIT2_ALIAS->data=0;
		GPT_3_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPT_3_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_3_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_3_GPTMTBMR_BIT4_ALIAS->data=1;
		
    Notification_Functions.GPT_Notification_GPT3B=ConfigPtr->GPT_Notification;
     Ignored_Bits[GPT_3_B_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_3_B_16BIT]++;
	  }
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
							
		break;	
		case GPT_4_B_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|16;
		GPT_4_GPTMCTL_BIT8_ALIAS->data=0;
		GPT_4_GPTMCFG->data=4;
	if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_4_GPTMTBMR_BIT2_ALIAS->data=0;
		GPT_4_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPT_4_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_4_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_4_GPTMTBMR_BIT4_ALIAS->data=1;
		
    Notification_Functions.GPT_Notification_GPT4B=ConfigPtr->GPT_Notification;
     Ignored_Bits[GPT_4_B_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_4_B_16BIT]++;
	  }
		
		
			
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;				
		break;	
		case GPT_5_B_16BIT:
			RCGCTIMER->data=RCGCTIMER->data|32;
		GPT_5_GPTMCTL_BIT8_ALIAS->data=0;
		GPT_5_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPT_5_GPTMTBMR_BIT2_ALIAS->data=0;
		GPT_5_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPT_5_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPT_5_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPT_5_GPTMTBMR_BIT4_ALIAS->data=1;
		
    Notification_Functions.GPT_Notification_GPT5B=ConfigPtr->GPT_Notification;

     Ignored_Bits[GPT_5_B_16BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPT_5_B_16BIT]++;
	  }
		
		
			
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;			
		break;	
		case GPWT_0_B_32BIT:
		RCGCWTIMER->data=RCGCWTIMER->data|1;
		GPWT_0_GPTMCTL_BIT8_ALIAS->data=0;
		GPWT_0_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_0_GPTMTBMR_BIT2_ALIAS->data=0;
		GPWT_0_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPWT_0_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_0_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_0_GPTMTBMR_BIT4_ALIAS->data=1;
		
			

		Notification_Functions.GPT_Notification_GPWT0B=ConfigPtr->GPT_Notification;
     Ignored_Bits[GPWT_0_B_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_0_B_32BIT]++;
	  }
		
		
			
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;	
		break;	
		case GPWT_1_B_32BIT:
			RCGCWTIMER->data=RCGCWTIMER->data|2;
		GPWT_1_GPTMCTL_BIT8_ALIAS->data=0;
		GPWT_1_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_1_GPTMTBMR_BIT2_ALIAS->data=0;
		GPWT_1_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPWT_1_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_1_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_1_GPTMTBMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT1B=ConfigPtr->GPT_Notification;
     Ignored_Bits[GPWT_1_B_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_1_B_32BIT]++;
	  }
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
						
		break;	
		case GPWT_2_B_32BIT:
			RCGCWTIMER->data=RCGCWTIMER->data|4;
		GPWT_2_GPTMCTL_BIT8_ALIAS->data=0;
		GPWT_2_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_2_GPTMTBMR_BIT2_ALIAS->data=0;
		GPWT_2_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPWT_2_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_2_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_2_GPTMTBMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT2B=ConfigPtr->GPT_Notification;	
     Ignored_Bits[GPWT_2_B_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_2_B_32BIT]++;
	  }
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		
						
		break;	
		case GPWT_3_B_32BIT:
			RCGCWTIMER->data=RCGCWTIMER->data|8;
		GPWT_3_GPTMCTL_BIT8_ALIAS->data=0;
		GPWT_3_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_3_GPTMTBMR_BIT2_ALIAS->data=0;
		GPWT_3_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPWT_3_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_3_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_3_GPTMTBMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT3B=ConfigPtr->GPT_Notification;
     Ignored_Bits[GPWT_3_B_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_3_B_32BIT]++;
	  }
		
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
						
		break;	
		case GPWT_4_B_32BIT:
		
			RCGCWTIMER->data=RCGCWTIMER->data|16;
		GPWT_4_GPTMCTL_BIT8_ALIAS->data=0;
		GPWT_4_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_4_GPTMTBMR_BIT2_ALIAS->data=0;
		GPWT_4_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPWT_4_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_4_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_4_GPTMTBMR_BIT4_ALIAS->data=1;
		
		Notification_Functions.GPT_Notification_GPWT4B=ConfigPtr->GPT_Notification;
     Ignored_Bits[GPWT_4_B_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_4_B_32BIT]++;
	  }
		
		
		
		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
					
		break;	
		 case GPWT_5_B_32BIT:

		RCGCWTIMER->data=RCGCWTIMER->data|32;
		GPWT_5_GPTMCTL_BIT8_ALIAS->data=0;
		GPWT_5_GPTMCFG->data=4;
		if(ConfigPtr->ChannelMode==PWM_Periodic||ConfigPtr->ChannelMode==PWM_One_Shot)
		{
		GPWT_5_GPTMTBMR_BIT2_ALIAS->data=0;
		GPWT_5_GPTMTBMR_BIT3_ALIAS->data=1;
	  }
		GPWT_5_GPTMTBMR_BIT0_ALIAS->data=ConfigPtr->ChannelMode;
		GPWT_5_GPTMTBMR_BIT1_ALIAS->data=ConfigPtr->ChannelMode>>1;
		GPWT_5_GPTMTBMR_BIT4_ALIAS->data=1;
		GPWT_5_GPTMIMR_BIT8_ALIAS->data=0;
		Notification_Functions.GPT_Notification_GPWT5B=ConfigPtr->GPT_Notification;

     Ignored_Bits[GPWT_5_B_32BIT]=-1;
	   while(Prescaler)
   	{
		Prescaler/=2;
		Ignored_Bits[GPWT_5_B_32BIT]++;
	  }

		MAX_VALUE[ConfigPtr->Channel]=ConfigPtr->TickValueMax;
		
		
					break;		
	  
	
					
	}
   
}	

void GPT_DisableNotification(GPT_ChannelType Channel,GPT_InterruptType Interrupt)
{
	
	switch(Channel)
	{
		case GPT_0_32BIT:
	  case GPT_0_A_16BIT: 
			switch(Interrupt)
			{
				case Time_Out:
					GPT_0_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_0_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
    
		
  	break;
		case GPT_1_32BIT:
		case GPT_1_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_1_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_1_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
  	break;
		case GPT_2_32BIT:
		case GPT_2_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_2_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_2_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
  	break;
		case GPT_3_32BIT:
		case GPT_3_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_3_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_3_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
  	break;
		case GPT_4_32BIT:
		case GPT_4_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_4_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_4_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
	  break;
		case GPT_5_32BIT:
		case GPT_5_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_5_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_5_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
  	break;
		case GPWT_0_64BIT:
		case GPWT_0_A_32BIT: 
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_0_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_0_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
  	break;
		case GPWT_1_64BIT:
		case GPWT_1_A_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_1_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_1_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
  	break;
		case GPWT_2_64BIT:
		case GPWT_2_A_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_2_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_2_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
	  break;
		case GPWT_3_64BIT:
		case GPWT_3_A_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_3_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_3_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
	  break;
		case GPWT_4_64BIT:
		case GPWT_4_A_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_4_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_4_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
		break;
		case GPWT_5_64BIT:
		case GPWT_5_A_32BIT: 
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_5_GPTMIMR_BIT0_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_5_GPTMTAMR_BIT9_ALIAS->data=0;
					break;
			}
		break;
		case GPT_0_B_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_0_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_0_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPT_1_B_16BIT:
		switch(Interrupt)
			{
				case Time_Out:
					GPT_1_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_1_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPT_2_B_16BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPT_2_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_2_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPT_3_B_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_3_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_3_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}
		break;
		case GPT_4_B_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_4_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPT_4_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPT_5_B_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPWT_5_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_5_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}
		break;
		case GPWT_0_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_0_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_0_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPWT_1_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_1_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_1_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPWT_2_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_2_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_2_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPWT_3_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_3_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_3_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPWT_4_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_4_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_4_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
		case GPWT_5_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_5_GPTMIMR_BIT8_ALIAS->data=0;
					break;
				
				case PWM:
					GPWT_5_GPTMTBMR_BIT9_ALIAS->data=0;
					break;
			}	
		break;
	}
}
void GPT_EableNotification(GPT_ChannelType Channel,GPT_InterruptType Interrupt)
{
		switch(Channel)
	{
		case GPT_0_32BIT:
	  case GPT_0_A_16BIT: 
			switch(Interrupt)
			{
				case Time_Out:
					GPT_0_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_0_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
    
		
  	break;
		case GPT_1_32BIT:
		case GPT_1_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_1_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_1_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
  	break;
		case GPT_2_32BIT:
		case GPT_2_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_2_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_2_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
  	break;
		case GPT_3_32BIT:
		case GPT_3_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_3_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_3_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
  	break;
		case GPT_4_32BIT:
		case GPT_4_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_4_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_4_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
	  break;
		case GPT_5_32BIT:
		case GPT_5_A_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_5_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_5_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
  	break;
		case GPWT_0_64BIT:
		case GPWT_0_A_32BIT: 
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_0_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_0_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
  	break;
		case GPWT_1_64BIT:
		case GPWT_1_A_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_1_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_1_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
  	break;
		case GPWT_2_64BIT:
		case GPWT_2_A_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_2_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_2_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
	  break;
		case GPWT_3_64BIT:
		case GPWT_3_A_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_3_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_3_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
	  break;
		case GPWT_4_64BIT:
		case GPWT_4_A_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_4_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_4_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
		break;
		case GPWT_5_64BIT:
		case GPWT_5_A_32BIT: 
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_5_GPTMIMR_BIT0_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_5_GPTMTAMR_BIT9_ALIAS->data=1;
					break;
			}
		break;
		case GPT_0_B_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_0_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_0_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPT_1_B_16BIT:
		switch(Interrupt)
			{
				case Time_Out:
					GPT_1_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_1_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPT_2_B_16BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPT_2_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_2_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPT_3_B_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_3_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_3_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}
		break;
		case GPT_4_B_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPT_4_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPT_4_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPT_5_B_16BIT: 
		switch(Interrupt)
			{
				case Time_Out:
					GPWT_5_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_5_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}
		break;
		case GPWT_0_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_0_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_0_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPWT_1_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_1_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_1_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPWT_2_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_2_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_2_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPWT_3_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_3_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_3_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPWT_4_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_4_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_4_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
		case GPWT_5_B_32BIT:
			switch(Interrupt)
			{
				case Time_Out:
					GPWT_5_GPTMIMR_BIT8_ALIAS->data=1;
					break;
				
				case PWM:
					GPWT_5_GPTMTBMR_BIT9_ALIAS->data=1;
					break;
			}	
		break;
	}
}

void GPT_StartTimer(GPT_ChannelType Channel,GPT_ValueType Value)
{
	switch(Channel)
	{
		case GPT_0_32BIT:
	  case GPT_0_A_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		
		GPT_0_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_0_A_16BIT];
		if(Channel==GPT_0_32BIT)
		{
		GPT_0_GPTMTAPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_0_A_16BIT]);
    }
		
		
	}	
else
		{
		GPT_0_GPTMTAILR->data=Value<<Ignored_Bits[GPT_0_A_16BIT];
		if(Channel==GPT_0_32BIT)
		{
		GPT_0_GPTMTAPR->data=Value>>(16-Ignored_Bits[GPT_0_A_16BIT]);
		}
		
		}
    GPT_0_GPTMCTL_BIT0_ALIAS->data=1;	
			
  	break;
		case GPT_1_32BIT:
		case GPT_1_A_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_1_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_1_A_16BIT];
		if(Channel==GPT_1_32BIT)
		{
		GPT_1_GPTMTAPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_1_A_16BIT]);
    }
		
		
	}	
else
		{
		GPT_1_GPTMTAILR->data=Value<<Ignored_Bits[GPT_1_A_16BIT];
			if(Channel==GPT_1_32BIT)
		{
		GPT_1_GPTMTAPR->data=Value>>(16-Ignored_Bits[GPT_1_A_16BIT]);
		}
		
    		}
    GPT_1_GPTMCTL_BIT0_ALIAS->data=1;	
  	break;
		case GPT_2_32BIT:
		case GPT_2_A_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_2_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_2_A_16BIT];
		if(Channel==GPT_2_32BIT)
		{
		GPT_2_GPTMTAPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_2_A_16BIT]);
		}
		
		
	}	
else
		{
		GPT_2_GPTMTAILR->data=Value<<Ignored_Bits[GPT_2_A_16BIT];
			if(Channel==GPT_2_32BIT)
		{
		GPT_2_GPTMTAPR->data=Value>>(16-Ignored_Bits[GPT_2_A_16BIT]);
		}
		
    }
    GPT_2_GPTMCTL_BIT0_ALIAS->data=1;		
  	break;
		case GPT_3_32BIT:
		case GPT_3_A_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_3_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_3_A_16BIT];
		if(Channel==GPT_3_32BIT)
		{
		GPT_3_GPTMTAPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_3_A_16BIT]);
		}
		
		
	}	
else
		{
		GPT_3_GPTMTAILR->data=Value<<Ignored_Bits[GPT_3_A_16BIT];
			if(Channel==GPT_3_32BIT)
		{
		GPT_3_GPTMTAPR->data=Value>>(16-Ignored_Bits[GPT_3_A_16BIT]);
		}
    }
    GPT_3_GPTMCTL_BIT0_ALIAS->data=1;	
  	break;
		case GPT_4_32BIT:
		case GPT_4_A_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_4_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_4_A_16BIT];
		if(Channel==GPT_4_32BIT)
		{
		GPT_4_GPTMTAPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_4_A_16BIT]);
		}
		
    
		
	}	
else
		{
		GPT_4_GPTMTAILR->data=Value<<Ignored_Bits[GPT_4_A_16BIT];
			if(Channel==GPT_4_32BIT)
		{
		GPT_4_GPTMTAPR->data=Value>>(16-Ignored_Bits[GPT_4_A_16BIT]);
		}
		
    }
    GPT_4_GPTMCTL_BIT0_ALIAS->data=1;	
	  break;
		case GPT_5_32BIT:
		case GPT_5_A_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_5_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_5_A_16BIT];
		if(Channel==GPT_5_32BIT)
		{
		GPT_5_GPTMTAPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_5_A_16BIT]);
		}
		
    
		
	}	
else
		{
		GPT_5_GPTMTAILR->data=Value<<Ignored_Bits[GPT_5_A_16BIT];
			if(Channel==GPT_5_32BIT)
		{
		GPT_5_GPTMTAPR->data=Value>>(16-Ignored_Bits[GPT_5_A_16BIT]);
		}
	
    }
    GPT_5_GPTMCTL_BIT0_ALIAS->data=1;		
  	break;
		case GPWT_0_64BIT:
		case GPWT_0_A_32BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_0_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_0_A_32BIT];
		if(Channel==GPWT_0_64BIT)
		{
		GPWT_0_GPTMTAPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_0_A_32BIT]);
		}
		else
		{
			
		}
    
		
	}	
else
		{
		GPWT_0_GPTMTAILR->data=Value<<Ignored_Bits[GPWT_0_A_32BIT];
		if(Channel==GPWT_0_64BIT)
		{
		GPWT_0_GPTMTAPR->data=Value>>(32-Ignored_Bits[GPWT_0_A_32BIT]);
		}
		GPWT_0_GPTMTBILR->data=Value>>(32-Ignored_Bits[GPWT_0_A_32BIT]);
    }
    GPWT_0_GPTMCTL_BIT0_ALIAS->data=1;	
  	break;
		case GPWT_1_64BIT:
		case GPWT_1_A_32BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_1_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_1_A_32BIT];
		if(Channel==GPWT_1_64BIT)
		{
		GPWT_1_GPTMTAPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_1_A_32BIT]);
    }
		else
		{
			GPWT_1_GPTMTBILR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_1_A_32BIT]);
		}
		
	}	
else
		{
		GPWT_1_GPTMTAILR->data=Value<<Ignored_Bits[GPWT_1_A_32BIT];
		if(Channel==GPWT_1_64BIT)
		{
		GPWT_1_GPTMTAPR->data=Value>>(32-Ignored_Bits[GPWT_1_A_32BIT]);
		}
		else
		{
			GPWT_1_GPTMTBILR->data=Value>>(32-Ignored_Bits[GPWT_1_A_32BIT]);
		}
    }
    GPWT_1_GPTMCTL_BIT0_ALIAS->data=1;	
  	break;
		case GPWT_2_64BIT:
		case GPWT_2_A_32BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_2_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_2_A_32BIT];
		if(Channel==GPWT_2_64BIT)
		{
		GPWT_2_GPTMTAPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_2_A_32BIT]);
		}
		else
		{
			GPWT_2_GPTMTBILR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_2_A_32BIT]);
		}
    
		
	}	
else
		{
		GPWT_2_GPTMTAILR->data=Value<<Ignored_Bits[GPWT_2_A_32BIT];
			if(Channel==GPWT_2_64BIT)
		{
		GPWT_2_GPTMTAPR->data=Value>>(32-Ignored_Bits[GPWT_2_A_32BIT]);
		}
		else
		{
			GPWT_2_GPTMTBILR->data=Value>>(32-Ignored_Bits[GPWT_2_A_32BIT]);
		}
		
    }
    GPWT_2_GPTMCTL_BIT0_ALIAS->data=1;	
	  break;
		case GPWT_3_64BIT:
		case GPWT_3_A_32BIT: 
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_2_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_2_A_32BIT];
			if(Channel==GPWT_3_64BIT)
		{
		GPWT_2_GPTMTAPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_2_A_32BIT]);
		}
		else
		{
			GPWT_2_GPTMTBILR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_2_A_32BIT]);
		}
    
		
	}	
else
		{
		GPWT_2_GPTMTAILR->data=Value<<Ignored_Bits[GPWT_2_A_32BIT];
			if(Channel==GPWT_3_64BIT)
		{
		GPWT_2_GPTMTAPR->data=Value>>(32-Ignored_Bits[GPWT_2_A_32BIT]);
		}
		else
		{
			GPWT_2_GPTMTBILR->data=Value>>(32-Ignored_Bits[GPWT_2_A_32BIT]);
		}
    }
    GPWT_3_GPTMCTL_BIT0_ALIAS->data=1;		
	  break;
		case GPWT_4_64BIT:
		case GPWT_4_A_32BIT: 
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_4_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_4_A_32BIT];
			if(Channel==GPWT_4_64BIT)
		{
		GPWT_4_GPTMTAPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_4_A_32BIT]);
		}
		else
		{
			GPWT_4_GPTMTBILR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_4_A_32BIT]);
		}
    
		
	}	
else
		{
		GPWT_4_GPTMTAILR->data=Value<<Ignored_Bits[GPWT_4_A_32BIT];
			if(Channel==GPWT_4_64BIT)
		{
		GPWT_4_GPTMTAPR->data=Value>>(32-Ignored_Bits[GPWT_4_A_32BIT]);
		}
		else
		{
			GPWT_4_GPTMTBILR->data=Value>>(32-Ignored_Bits[GPWT_4_A_32BIT]);
		}
    }
    GPWT_4_GPTMCTL_BIT0_ALIAS->data=1;		
		break;
		case GPWT_5_64BIT:
		case GPWT_5_A_32BIT:   
  
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_5_GPTMTAILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_5_A_32BIT];
			if(Channel==GPWT_5_64BIT)
		{
		GPWT_5_GPTMTAPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_5_A_32BIT]);
		}
		else
		{
			GPWT_5_GPTMTBILR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_5_A_32BIT]);
		}
    
		
	}	
else
		{
		GPWT_5_GPTMTAILR->data=Value<<Ignored_Bits[GPWT_5_A_32BIT];
	if(Channel==GPWT_5_64BIT)
		{
		GPWT_5_GPTMTAPR->data=Value>>(32-Ignored_Bits[GPWT_5_A_32BIT]);
		}
		else
		{
			GPWT_5_GPTMTBILR->data=Value>>(32-Ignored_Bits[GPWT_5_A_32BIT]);
		}
    }
    GPWT_5_GPTMCTL_BIT0_ALIAS->data=1;		
		break;
		case GPT_0_B_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_0_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_0_B_16BIT];
		GPT_0_GPTMTBPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_0_B_16BIT]);
	}	
else
		{
		GPT_0_GPTMTBILR->data=Value<<Ignored_Bits[GPT_0_B_16BIT];
		GPT_0_GPTMTBPR->data=Value>>(16-Ignored_Bits[GPT_0_B_16BIT]);
    }
    GPT_0_GPTMCTL_BIT8_ALIAS->data=1;		
		break;
		case GPT_1_B_16BIT: 
  if(Value>MAX_VALUE[Channel])
  {
		GPT_1_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_1_B_16BIT];
		GPT_1_GPTMTBPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_1_B_16BIT]);
    
		
	}	
else
		{
		GPT_1_GPTMTBILR->data=Value<<Ignored_Bits[GPT_1_B_16BIT];
		GPT_1_GPTMTBPR->data=Value>>(16-Ignored_Bits[GPT_1_B_16BIT]);
    }
    GPT_1_GPTMCTL_BIT8_ALIAS->data=1;	
		break;
		case GPT_2_B_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_2_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_2_B_16BIT];
		GPT_2_GPTMTBPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_2_B_16BIT]);
    
		
	}	
else
		{
		GPT_2_GPTMTBILR->data=Value<<Ignored_Bits[GPT_2_B_16BIT];
		GPT_2_GPTMTBPR->data=Value>>(16-Ignored_Bits[GPT_2_B_16BIT]);
    }
    GPT_2_GPTMCTL_BIT8_ALIAS->data=1;		
		break;
		case GPT_3_B_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_3_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_3_B_16BIT];
		GPT_3_GPTMTBPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_3_B_16BIT]);
    
		
	}	
else
		{
		GPT_3_GPTMTBILR->data=Value<<Ignored_Bits[GPT_3_B_16BIT];
		GPT_3_GPTMTBPR->data=Value>>(16-Ignored_Bits[GPT_3_B_16BIT]);
    }
    GPT_3_GPTMCTL_BIT8_ALIAS->data=1;		
		break;
		case GPT_4_B_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_4_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_4_B_16BIT];
		GPT_4_GPTMTBPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_4_B_16BIT]);
    
		
	}	
else
		{
		GPT_4_GPTMTBILR->data=Value<<Ignored_Bits[GPT_4_B_16BIT];
		GPT_4_GPTMTBPR->data=Value>>(16-Ignored_Bits[GPT_4_B_16BIT]);
    }
    GPT_4_GPTMCTL_BIT8_ALIAS->data=1;	
		break;
		case GPT_5_B_16BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPT_5_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPT_5_B_16BIT];
		GPT_5_GPTMTBPR->data=MAX_VALUE[Channel]>>(16-Ignored_Bits[GPT_5_B_16BIT]);
    
		
	}	
else
		{
		GPT_5_GPTMTBILR->data=Value<<Ignored_Bits[GPT_5_B_16BIT];
		GPT_5_GPTMTBPR->data=Value>>(16-Ignored_Bits[GPT_5_B_16BIT]);
    }
    GPT_5_GPTMCTL_BIT8_ALIAS->data=1;	
		break;
		case GPWT_0_B_32BIT:   
  if(Value>MAX_VALUE[Channel])
  {
  
		GPWT_0_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_0_B_32BIT];
		GPWT_0_GPTMTBPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_0_B_32BIT]);
    
		
	}	

else
		{
		GPWT_0_GPTMTBILR->data=Value<<Ignored_Bits[GPWT_0_B_32BIT];
		GPWT_0_GPTMTBPR->data=Value>>(32-Ignored_Bits[GPWT_0_B_32BIT]);
    }
    GPWT_0_GPTMCTL_BIT8_ALIAS->data=1;		
		break;
		case GPWT_1_B_32BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_1_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_1_B_32BIT];
		GPWT_1_GPTMTBPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_1_B_32BIT]);
    
		
	}	
else
		{
		GPWT_1_GPTMTBILR->data=Value<<Ignored_Bits[GPWT_1_B_32BIT];
		GPWT_1_GPTMTBPR->data=Value>>(32-Ignored_Bits[GPWT_1_B_32BIT]);
    }
    GPWT_1_GPTMCTL_BIT8_ALIAS->data=1;	
		break;
		case GPWT_2_B_32BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_2_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_2_B_32BIT];
		GPWT_2_GPTMTBPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_2_B_32BIT]);
    
		
	}	
else
		{
		GPWT_2_GPTMTBILR->data=Value<<Ignored_Bits[GPWT_2_B_32BIT];
		GPWT_2_GPTMTBPR->data=Value>>(32-Ignored_Bits[GPWT_2_B_32BIT]);
    }
    GPWT_2_GPTMCTL_BIT8_ALIAS->data=1;		
		break;
		case GPWT_3_B_32BIT:  
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_3_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_3_B_32BIT];
		GPWT_3_GPTMTBPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_3_B_32BIT]);
    
		
	}	

else
		{
		GPWT_3_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_3_B_32BIT];
		GPWT_3_GPTMTBPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_3_B_32BIT]);
    }
    GPWT_3_GPTMCTL_BIT8_ALIAS->data=1;	
		break;
		case GPWT_4_B_32BIT: 
  if(Value>MAX_VALUE[Channel])
  {
		GPWT_4_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_4_B_32BIT];
		GPWT_4_GPTMTBPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_4_B_32BIT]);
    
		
	}	
else
		{
		GPWT_4_GPTMTBILR->data=Value<<Ignored_Bits[GPWT_4_B_32BIT];
		GPWT_4_GPTMTBPR->data=Value>>(32-Ignored_Bits[GPWT_4_B_32BIT]);
    }
    GPWT_4_GPTMCTL_BIT8_ALIAS->data=1;	
		break;
	case GPWT_5_B_32BIT: 
#if((GPT_Predef_TIMER_1US_16BIT_==DIS)&&(GPT_Predef_TIMER_1US_24BIT_==DIS)&&(GPT_Predef_TIMER_1US_32BIT_==DIS)&&(GPT_Predef_TIMER_128US_32BIT_==DIS))

  if(Value>MAX_VALUE[Channel])
  {
		GPWT_5_GPTMTBILR->data=MAX_VALUE[Channel]<<Ignored_Bits[GPWT_5_B_32BIT];
		GPWT_5_GPTMTBPR->data=MAX_VALUE[Channel]>>(32-Ignored_Bits[GPWT_5_B_32BIT]);
    
		
	}	
else
		{
		GPWT_5_GPTMTBILR->data=Value<<Ignored_Bits[GPWT_5_B_32BIT];
		GPWT_5_GPTMTBPR->data=Value>>(32-Ignored_Bits[GPWT_5_B_32BIT]);
   
	}		
	GPWT_5_GPTMCTL_BIT8_ALIAS->data=1;
		#else
	GPWT_5_GPTMCTL_BIT8_ALIAS->data=1;
	#endif
		 
		break;
	

}
    
	}
void GPT_StopTimer(GPT_ChannelType Channel)
{
	switch(Channel)
	{
		case GPT_0_32BIT:
	  case GPT_0_A_16BIT: 
		
    GPT_0_GPTMCTL_BIT0_ALIAS->data=0;		
  	break;
		case GPT_1_32BIT:
		case GPT_1_A_16BIT: 
    GPT_1_GPTMCTL_BIT0_ALIAS->data=0;	
  	break;
		case GPT_2_32BIT:
		case GPT_2_A_16BIT: 
		
    GPT_2_GPTMCTL_BIT0_ALIAS->data=0;		
  	break;
		case GPT_3_32BIT:
		case GPT_3_A_16BIT: 
		
    GPT_3_GPTMCTL_BIT0_ALIAS->data=0;	
  	break;
		case GPT_4_32BIT:
		case GPT_4_A_16BIT: 
		
    GPT_4_GPTMCTL_BIT0_ALIAS->data=0;	
	  break;
		case GPT_5_32BIT:
		case GPT_5_A_16BIT: 
		
    GPT_5_GPTMCTL_BIT0_ALIAS->data=0;		
  	break;
		case GPWT_0_64BIT:
		case GPWT_0_A_32BIT: 
		
    GPWT_0_GPTMCTL_BIT0_ALIAS->data=0;	
  	break;
		case GPWT_1_64BIT:
		case GPWT_1_A_32BIT: 
		
    GPWT_1_GPTMCTL_BIT0_ALIAS->data=0;	
  	break;
		case GPWT_2_64BIT:
		case GPWT_2_A_32BIT: 
		
    GPWT_2_GPTMCTL_BIT0_ALIAS->data=0;	
	  break;
		case GPWT_3_64BIT:
		case GPWT_3_A_32BIT:
		
    GPWT_3_GPTMCTL_BIT0_ALIAS->data=0;		
	  break;
		case GPWT_4_64BIT:
		case GPWT_4_A_32BIT:
		
    GPWT_4_GPTMCTL_BIT0_ALIAS->data=0;		
		break;
		case GPWT_5_64BIT:
		case GPWT_5_A_32BIT: 
		
    GPWT_5_GPTMCTL_BIT0_ALIAS->data=0;		
		break;
		case GPT_0_B_16BIT: 
		
    GPT_0_GPTMCTL_BIT8_ALIAS->data=0;		
		break;
		case GPT_1_B_16BIT:
		
    GPT_1_GPTMCTL_BIT8_ALIAS->data=0;	
		break;
		case GPT_2_B_16BIT: 
		
    GPT_2_GPTMCTL_BIT8_ALIAS->data=0;		
		break;
		case GPT_3_B_16BIT: 
		
    GPT_3_GPTMCTL_BIT8_ALIAS->data=0;		
		break;
		case GPT_4_B_16BIT: 
		
    GPT_4_GPTMCTL_BIT8_ALIAS->data=0;	
		break;
		case GPT_5_B_16BIT: 
		
    GPT_5_GPTMCTL_BIT8_ALIAS->data=0;	
		break;
		case GPWT_0_B_32BIT: 
		
    GPWT_0_GPTMCTL_BIT8_ALIAS->data=0;		
		break;
		case GPWT_1_B_32BIT: 
		
    GPWT_1_GPTMCTL_BIT8_ALIAS->data=0;	
		break;
		case GPWT_2_B_32BIT: 
		
    GPWT_2_GPTMCTL_BIT8_ALIAS->data=0;		
		break;
		case GPWT_3_B_32BIT: 
		
    GPWT_3_GPTMCTL_BIT8_ALIAS->data=0;	
		break;
		case GPWT_4_B_32BIT:
		
    GPWT_4_GPTMCTL_BIT8_ALIAS->data=0;	
		break;
		case GPWT_5_B_32BIT: 
		
    GPWT_5_GPTMCTL_BIT8_ALIAS->data=0;		
		break;
}
}








GPT_ValueType GPT_GetTimeElapsed(GPT_ChannelType Channel)
{
	GPT_ValueType TEMP=0;
	switch(Channel)
	{
		
		case GPT_0_32BIT:
			TEMP=(((GPT_0_GPTMTAV->data)>>Ignored_Bits[GPT_0_A_16BIT]));
  	
		break;
	  case GPT_0_A_16BIT: 
			
			TEMP=(((GPT_0_GPTMTAV->data)>>Ignored_Bits[GPT_0_A_16BIT])|((GPT_0_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_0_A_16BIT])));
  	
		break;
		case GPT_1_32BIT:
				TEMP=(((GPT_0_GPTMTAV->data)>>Ignored_Bits[GPT_1_A_16BIT]));
  	
  	break;
		case GPT_1_A_16BIT: 
			TEMP=(((GPT_0_GPTMTAV->data)>>Ignored_Bits[GPT_1_A_16BIT])|((GPT_0_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_1_A_16BIT])));
  	
  	break;
		case GPT_2_32BIT:
			TEMP=(((GPT_2_GPTMTAV->data)>>Ignored_Bits[GPT_2_A_16BIT]));
  	
  	break;
		case GPT_2_A_16BIT: 
			TEMP=(((GPT_2_GPTMTAV->data)>>Ignored_Bits[GPT_2_A_16BIT])|((GPT_2_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_2_A_16BIT])));
  	
  	break;
		case GPT_3_32BIT:
			TEMP=(((GPT_3_GPTMTAV->data)>>Ignored_Bits[GPT_3_A_16BIT]));
  	
  	break;
		case GPT_3_A_16BIT:
    			
		TEMP=(((GPT_3_GPTMTAV->data)>>Ignored_Bits[GPT_3_A_16BIT])|((GPT_3_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_3_A_16BIT])));
  	
  	break;
		case GPT_4_32BIT:
			TEMP=(((GPT_4_GPTMTAV->data)>>Ignored_Bits[GPT_4_A_16BIT]));
  	
	  break;
		case GPT_4_A_16BIT: 
		TEMP=(((GPT_4_GPTMTAV->data)>>Ignored_Bits[GPT_4_A_16BIT])|((GPT_4_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_4_A_16BIT])));
  	
	  break;
		case GPT_5_32BIT:
			TEMP=(((GPT_5_GPTMTAV->data)>>Ignored_Bits[GPT_5_A_16BIT]));
  	
  	break;
		case GPT_5_A_16BIT: 
		TEMP=(((GPT_5_GPTMTAV->data)>>Ignored_Bits[GPT_5_A_16BIT])|((GPT_5_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_5_A_16BIT])));
  	
  	break;
		case GPWT_0_64BIT:
			TEMP=(((GPWT_0_GPTMTAV->data)>>Ignored_Bits[GPWT_0_A_32BIT])|((GPWT_0_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_0_A_32BIT])));
  	
  	break;
		case GPWT_0_A_32BIT: 
		TEMP=(((GPWT_0_GPTMTAV->data)>>Ignored_Bits[GPWT_0_A_32BIT])|((GPWT_0_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_0_A_32BIT])));
  	
  	break;
		case GPWT_1_64BIT:
			TEMP=(((GPWT_1_GPTMTAV->data)>>Ignored_Bits[GPWT_1_A_32BIT])|((GPWT_1_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_1_A_32BIT])));
  	
  	break;
		case GPWT_1_A_32BIT: 
		TEMP=(((GPWT_1_GPTMTAV->data)>>Ignored_Bits[GPWT_1_A_32BIT])|((GPWT_1_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_1_A_32BIT])));
  	
  	break;
		case GPWT_2_64BIT:
			TEMP=(((GPWT_2_GPTMTAV->data)>>Ignored_Bits[GPWT_2_A_32BIT])|((GPWT_2_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_2_A_32BIT])));
  	
	  break;
		case GPWT_2_A_32BIT: 
			TEMP=(((GPWT_2_GPTMTAV->data)>>Ignored_Bits[GPWT_2_A_32BIT])|((GPWT_2_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_2_A_32BIT])));
  	
	  break;
		case GPWT_3_64BIT:
			TEMP=(((GPWT_3_GPTMTAV->data)>>Ignored_Bits[GPWT_3_A_32BIT])|((GPWT_3_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_3_A_32BIT])));
  	
	  break;
		case GPWT_3_A_32BIT:
			TEMP=(((GPWT_3_GPTMTAV->data)>>Ignored_Bits[GPWT_3_A_32BIT])|((GPWT_3_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_3_A_32BIT])));
  	
	  break;
		case GPWT_4_64BIT:
			TEMP=(((GPWT_4_GPTMTAV->data)>>Ignored_Bits[GPWT_4_A_32BIT])|((GPWT_4_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_4_A_32BIT])));
  	
		break;
		case GPWT_4_A_32BIT:
		TEMP=(((GPWT_4_GPTMTAV->data)>>Ignored_Bits[GPWT_4_A_32BIT])|((GPWT_4_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_4_A_32BIT])));
  	
		break;
		case GPWT_5_64BIT:
			TEMP=(((GPWT_5_GPTMTAV->data)>>Ignored_Bits[GPWT_5_A_32BIT])|((GPWT_5_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_5_A_32BIT])));
  	
		break;
		case GPWT_5_A_32BIT: 
		TEMP=(((GPWT_5_GPTMTAV->data)>>Ignored_Bits[GPWT_5_A_32BIT])|((GPWT_5_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_5_A_32BIT])));
  	
		break;
		case GPT_0_B_16BIT: 
		TEMP=(((GPT_0_GPTMTBV->data)>>Ignored_Bits[GPT_0_B_16BIT])|((GPT_0_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_0_B_16BIT])));
  	
		break;
		case GPT_1_B_16BIT:
		TEMP=(((GPT_1_GPTMTBV->data)>>Ignored_Bits[GPT_1_B_16BIT])|((GPT_1_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_1_B_16BIT])));
  	
		break;
		case GPT_2_B_16BIT: 
		TEMP=(((GPT_2_GPTMTBV->data)>>Ignored_Bits[GPT_2_B_16BIT])|((GPT_2_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_2_B_16BIT])));
  	
		break;
		case GPT_3_B_16BIT: 
			TEMP=(((GPT_3_GPTMTBV->data)>>Ignored_Bits[GPT_3_B_16BIT])|((GPT_3_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_3_B_16BIT])));
  	
		break;
		case GPT_4_B_16BIT: 
			TEMP=(((GPT_4_GPTMTBV->data)>>Ignored_Bits[GPT_4_B_16BIT])|((GPT_4_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_4_B_16BIT])));
  	
		break;
		case GPT_5_B_16BIT: 
			TEMP=(((GPT_5_GPTMTBV->data)>>Ignored_Bits[GPT_5_B_16BIT])|((GPT_5_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_5_B_16BIT])));
  	
		break;
		case GPWT_0_B_32BIT: 
		TEMP=(((GPWT_0_GPTMTBV->data)>>Ignored_Bits[GPWT_0_B_32BIT])|((GPWT_0_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_0_B_32BIT])));
  	
		break;
		case GPWT_1_B_32BIT: 
		TEMP=(((GPWT_1_GPTMTBV->data)>>Ignored_Bits[GPWT_1_B_32BIT])|((GPWT_1_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_1_B_32BIT])));
  	
		break;
		case GPWT_2_B_32BIT: 
			TEMP=(((GPWT_2_GPTMTBV->data)>>Ignored_Bits[GPWT_2_B_32BIT])|((GPWT_2_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_2_B_32BIT])));
  	
		break;
		case GPWT_3_B_32BIT: 
		TEMP=(((GPWT_3_GPTMTBV->data)>>Ignored_Bits[GPWT_3_B_32BIT])|((GPWT_3_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_3_B_32BIT])));
  	
		break;
		case GPWT_4_B_32BIT:
			TEMP=(((GPWT_4_GPTMTBV->data)>>Ignored_Bits[GPWT_4_B_32BIT])|((GPWT_4_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_4_B_32BIT])));
  	
		break;
		case GPWT_5_B_32BIT: 
			TEMP=(((GPWT_5_GPTMTBV->data)>>Ignored_Bits[GPWT_5_B_32BIT])|((GPWT_5_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_5_B_32BIT])));
  	
		break;
	}
	return TEMP;
	
}
GPT_ValueType GPT_GetTimeRemaining(GPT_ChannelType Channel)
{
	
	GPT_ValueType TEMP=0;
	switch(Channel)
	{
		
		case GPT_0_32BIT:
			TEMP=GPT_0_GPTMTAILR->data-(((GPT_0_GPTMTAV->data)>>Ignored_Bits[GPT_0_A_16BIT]));
  	
		break;
	  case GPT_0_A_16BIT: 
			
			TEMP=(GPT_0_GPTMTAILR->data+GPT_0_GPTMTAPR->data)-(((GPT_0_GPTMTAV->data)>>Ignored_Bits[GPT_0_A_16BIT])|((GPT_0_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_0_A_16BIT])));
  	
		break;
		case GPT_1_32BIT:
				TEMP=(GPT_1_GPTMTAILR->data+GPT_1_GPTMTAPR->data)-(((GPT_0_GPTMTAV->data)>>Ignored_Bits[GPT_1_A_16BIT]));
  	
  	break;
		case GPT_1_A_16BIT: 
			TEMP=GPT_1_GPTMTAILR->data-(((GPT_0_GPTMTAV->data)>>Ignored_Bits[GPT_1_A_16BIT])|((GPT_0_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_1_A_16BIT])));
  	
  	break;
		case GPT_2_32BIT:
			TEMP=GPT_2_GPTMTAILR->data-(((GPT_2_GPTMTAV->data)>>Ignored_Bits[GPT_2_A_16BIT]));
  	
  	break;
		case GPT_2_A_16BIT: 
			TEMP=(GPT_2_GPTMTAILR->data+GPT_2_GPTMTAPR->data)-(((GPT_2_GPTMTAV->data)>>Ignored_Bits[GPT_2_A_16BIT])|((GPT_2_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_2_A_16BIT])));
  	
  	break;
		case GPT_3_32BIT:
			TEMP=GPT_3_GPTMTAILR->data-(((GPT_3_GPTMTAV->data)>>Ignored_Bits[GPT_3_A_16BIT]));
  	
  	break;
		case GPT_3_A_16BIT:
    			
		TEMP=(GPT_3_GPTMTAILR->data+GPT_3_GPTMTAPR->data)-(((GPT_3_GPTMTAV->data)>>Ignored_Bits[GPT_3_A_16BIT])|((GPT_3_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_3_A_16BIT])));
  	
  	break;
		case GPT_4_32BIT:
			TEMP=GPT_4_GPTMTAILR->data-(((GPT_4_GPTMTAV->data)>>Ignored_Bits[GPT_4_A_16BIT]));
  	
	  break;
		case GPT_4_A_16BIT: 
		TEMP=(GPT_4_GPTMTAILR->data+GPT_4_GPTMTAPR->data)-(((GPT_4_GPTMTAV->data)>>Ignored_Bits[GPT_4_A_16BIT])|((GPT_4_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_4_A_16BIT])));
  	
	  break;
		case GPT_5_32BIT:
			TEMP=GPT_5_GPTMTAILR->data-(((GPT_5_GPTMTAV->data)>>Ignored_Bits[GPT_5_A_16BIT]));
  	
  	break;
		case GPT_5_A_16BIT: 
		TEMP=(GPT_5_GPTMTAILR->data+GPT_5_GPTMTAPR->data)-(((GPT_5_GPTMTAV->data)>>Ignored_Bits[GPT_5_A_16BIT])|((GPT_5_GPTMTAPV->data)<<(16-Ignored_Bits[GPT_5_A_16BIT])));
  	
  	break;
		case GPWT_0_64BIT:
			TEMP=(GPWT_0_GPTMTAILR->data+GPWT_0_GPTMTBILR->data)-(((GPWT_0_GPTMTAV->data)>>Ignored_Bits[GPWT_0_A_32BIT])|((GPWT_0_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_0_A_32BIT])));
  	
  	break;
		case GPWT_0_A_32BIT: 
		TEMP=(GPWT_0_GPTMTAILR->data+GPWT_0_GPTMTAPR->data)-(((GPWT_0_GPTMTAV->data)>>Ignored_Bits[GPWT_0_A_32BIT])|((GPWT_0_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_0_A_32BIT])));
  	
  	break;
		case GPWT_1_64BIT:
			TEMP=(GPWT_1_GPTMTAILR->data+GPWT_0_GPTMTBILR->data)-(((GPWT_1_GPTMTAV->data)>>Ignored_Bits[GPWT_1_A_32BIT])|((GPWT_1_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_1_A_32BIT])));
  	
  	break;
		case GPWT_1_A_32BIT: 
		TEMP=(GPWT_1_GPTMTAILR->data+GPWT_1_GPTMTAPR->data)-(((GPWT_1_GPTMTAV->data)>>Ignored_Bits[GPWT_1_A_32BIT])|((GPWT_1_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_1_A_32BIT])));
  	
  	break;
		case GPWT_2_64BIT:
			TEMP=(GPWT_2_GPTMTAILR->data+GPWT_2_GPTMTBILR->data)-(((GPWT_2_GPTMTAV->data)>>Ignored_Bits[GPWT_2_A_32BIT])|((GPWT_2_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_2_A_32BIT])));
  	
	  break;
		case GPWT_2_A_32BIT: 
			TEMP=(GPWT_2_GPTMTAILR->data+GPWT_2_GPTMTAPR->data)-(((GPWT_2_GPTMTAV->data)>>Ignored_Bits[GPWT_2_A_32BIT])|((GPWT_2_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_2_A_32BIT])));
  	
	  break;
		case GPWT_3_64BIT:
			TEMP=(GPWT_3_GPTMTAILR->data+GPWT_3_GPTMTBILR->data)-(((GPWT_3_GPTMTAV->data)>>Ignored_Bits[GPWT_3_A_32BIT])|((GPWT_3_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_3_A_32BIT])));
  	
	  break;
		case GPWT_3_A_32BIT:
			TEMP=(GPWT_3_GPTMTAILR->data+GPWT_3_GPTMTAPR->data)-(((GPWT_3_GPTMTAV->data)>>Ignored_Bits[GPWT_3_A_32BIT])|((GPWT_3_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_3_A_32BIT])));
  	
	  break;
		case GPWT_4_64BIT:
			TEMP=(GPWT_4_GPTMTAILR->data+GPWT_4_GPTMTBILR->data)-(((GPWT_4_GPTMTAV->data)>>Ignored_Bits[GPWT_4_A_32BIT])|((GPWT_4_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_4_A_32BIT])));
  	
		break;
		case GPWT_4_A_32BIT:
		TEMP=(GPWT_4_GPTMTAILR->data+GPWT_4_GPTMTAPR->data)-(((GPWT_4_GPTMTAV->data)>>Ignored_Bits[GPWT_4_A_32BIT])|((GPWT_4_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_4_A_32BIT])));
  	
		break;
		case GPWT_5_64BIT:
			TEMP=(GPWT_5_GPTMTAILR->data+GPWT_5_GPTMTBILR->data)-(((GPWT_5_GPTMTAV->data)>>Ignored_Bits[GPWT_5_A_32BIT])|((GPWT_5_GPTMTBV->data)<<(32-Ignored_Bits[GPWT_5_A_32BIT])));
  	
		break;
		case GPWT_5_A_32BIT: 
		TEMP=(GPWT_0_GPTMTAILR->data+GPWT_0_GPTMTAPR->data)-(((GPWT_5_GPTMTAV->data)>>Ignored_Bits[GPWT_5_A_32BIT])|((GPWT_5_GPTMTAPV->data)<<(32-Ignored_Bits[GPWT_5_A_32BIT])));
  	
		break;
		case GPT_0_B_16BIT: 
		TEMP=(GPT_0_GPTMTBILR->data+GPT_0_GPTMTBPR->data)-(((GPT_0_GPTMTBV->data)>>Ignored_Bits[GPT_0_B_16BIT])|((GPT_0_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_0_B_16BIT])));
  	
		break;
		case GPT_1_B_16BIT:
		TEMP=(GPT_1_GPTMTBILR->data+GPT_1_GPTMTBPR->data)-(((GPT_1_GPTMTBV->data)>>Ignored_Bits[GPT_1_B_16BIT])|((GPT_1_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_1_B_16BIT])));
  	
		break;
		case GPT_2_B_16BIT: 
		TEMP=(GPT_2_GPTMTBILR->data+GPT_2_GPTMTBPR->data)-(((GPT_2_GPTMTBV->data)>>Ignored_Bits[GPT_2_B_16BIT])|((GPT_2_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_2_B_16BIT])));
  	
		break;
		case GPT_3_B_16BIT: 
			TEMP=(GPT_3_GPTMTBILR->data+GPT_3_GPTMTBPR->data)-(((GPT_3_GPTMTBV->data)>>Ignored_Bits[GPT_3_B_16BIT])|((GPT_3_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_3_B_16BIT])));
  	
		break;
		case GPT_4_B_16BIT: 
			TEMP=(GPT_4_GPTMTBILR->data+GPT_4_GPTMTBPR->data)-(((GPT_4_GPTMTBV->data)>>Ignored_Bits[GPT_4_B_16BIT])|((GPT_4_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_4_B_16BIT])));
  	
		break;
		case GPT_5_B_16BIT: 
			TEMP=(GPT_5_GPTMTBILR->data+GPT_5_GPTMTBPR->data)-(((GPT_5_GPTMTBV->data)>>Ignored_Bits[GPT_5_B_16BIT])|((GPT_5_GPTMTBPV->data)<<(16-Ignored_Bits[GPT_5_B_16BIT])));
  	
		break;
		case GPWT_0_B_32BIT: 
		TEMP=(GPWT_0_GPTMTBILR->data+GPWT_0_GPTMTBPR->data)-(((GPWT_0_GPTMTBV->data)>>Ignored_Bits[GPWT_0_B_32BIT])|((GPWT_0_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_0_B_32BIT])));
  	
		break;
		case GPWT_1_B_32BIT: 
		TEMP=(GPWT_1_GPTMTBILR->data+GPWT_1_GPTMTBPR->data)-(((GPWT_1_GPTMTBV->data)>>Ignored_Bits[GPWT_1_B_32BIT])|((GPWT_1_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_1_B_32BIT])));
  	
		break;
		case GPWT_2_B_32BIT: 
			TEMP=(GPWT_2_GPTMTBILR->data+GPWT_2_GPTMTBPR->data)-(((GPWT_2_GPTMTBV->data)>>Ignored_Bits[GPWT_2_B_32BIT])|((GPWT_2_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_2_B_32BIT])));
  	
		break;
		case GPWT_3_B_32BIT: 
		TEMP=(GPWT_3_GPTMTBILR->data+GPWT_3_GPTMTBPR->data)-(((GPWT_3_GPTMTBV->data)>>Ignored_Bits[GPWT_3_B_32BIT])|((GPWT_3_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_3_B_32BIT])));
  	
		break;
		case GPWT_4_B_32BIT:
			TEMP=(GPWT_4_GPTMTBILR->data+GPWT_4_GPTMTBPR->data)-(((GPWT_4_GPTMTBV->data)>>Ignored_Bits[GPWT_4_B_32BIT])|((GPWT_4_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_4_B_32BIT])));
  	
		break;
		case GPWT_5_B_32BIT: 
			TEMP=(GPWT_5_GPTMTBILR->data+GPWT_5_GPTMTBPR->data)-(((GPWT_5_GPTMTBV->data)>>Ignored_Bits[GPWT_5_B_32BIT])|((GPWT_5_GPTMTBPV->data)<<(32-Ignored_Bits[GPWT_5_B_32BIT])));
  	
		break;
	}
	return TEMP;
	
	
	
	
	
}








Std_ReturnType GPT_GetPredefTimerValue(GPT_PredefTimerType PredefTimer,UINT32_L* TimeValuePtr)
{
	switch(PredefTimer)
	{
		case GPT_Predef_TIMER_1US_16BIT:
			*TimeValuePtr=0X0000FFFF&(GPWT_5_GPTMTAV->data>>4);
		break;
		case GPT_Predef_TIMER_1US_24BIT:
			*TimeValuePtr=0X01FFFFFF&(GPWT_5_GPTMTAV->data>>4);
		break;
		case GPT_Predef_TIMER_1US_32BIT:
			*TimeValuePtr=GPWT_5_GPTMTAV->data>>4|GPWT_5_GPTMTBV->data<<28;
		break;
		case GPT_Predef_TIMER_128US_32BIT:
			*TimeValuePtr=GPWT_5_GPTMTAV->data>>10|GPWT_5_GPTMTBV->data<<22;
		break;
		
	}
	return 0;
	
	
}





































void	TIMER0A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT0A)();
	GPT_0_GPTMICR_BIT0_ALIAS->data=1;
}
void	TIMER1A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT1A)();
	GPT_1_GPTMICR_BIT0_ALIAS->data=1;
}
void	TIMER2A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT2A)();
	GPT_2_GPTMICR_BIT0_ALIAS->data=1;
}	
void	TIMER3A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT3A)();
	GPT_3_GPTMICR_BIT0_ALIAS->data=1;
}	
void	TIMER4A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT4A)();
	GPT_4_GPTMICR_BIT0_ALIAS->data=1;
}	
void	TIMER5A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT5A)();
	GPT_5_GPTMICR_BIT0_ALIAS->data=1;
}	
void	WTIMER0A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT0A)();
	GPWT_0_GPTMICR_BIT0_ALIAS->data=1;
}	
void	WTIMER1A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT1A)();
	GPWT_1_GPTMICR_BIT0_ALIAS->data=1;
}	
void	WTIMER2A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT2A)();
	GPWT_2_GPTMICR_BIT0_ALIAS->data=1;
}	
void	WTIMER3A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT3A)();
	GPWT_3_GPTMICR_BIT0_ALIAS->data=1;
}	
void	WTIMER4A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT4A)();
	GPWT_4_GPTMICR_BIT0_ALIAS->data=1;
}	
void	WTIMER5A_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT5A)();
	GPWT_5_GPTMICR_BIT0_ALIAS->data=1;
}	
void	TIMER0B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT0B)();
	GPT_0_GPTMICR_BIT8_ALIAS->data=1;
}	
void	TIMER1B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT1B)();
	GPT_1_GPTMICR_BIT8_ALIAS->data=1;
}	
void	TIMER2B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT2B)();
	GPT_2_GPTMICR_BIT8_ALIAS->data=1;
}	
void	TIMER3B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT3B)();
	GPT_3_GPTMICR_BIT8_ALIAS->data=1;
}	
void	TIMER4B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT4B)();
	GPT_4_GPTMICR_BIT8_ALIAS->data=1;
}	
void	TIMER5B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPT5B)();
	GPT_5_GPTMICR_BIT8_ALIAS->data=1;
}
void	WTIMER0B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT0B)();
	GPWT_0_GPTMICR_BIT8_ALIAS->data=1;
}	
void	WTIMER1B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT1B)();
	GPWT_1_GPTMICR_BIT8_ALIAS->data=1;
}	
void	WTIMER2B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT2B)();
	GPWT_2_GPTMICR_BIT8_ALIAS->data=1;
}	
void	WTIMER3B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT3B)();
	GPWT_3_GPTMICR_BIT8_ALIAS->data=1;
}	
void	WTIMER4B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT4B)();
	GPWT_4_GPTMICR_BIT8_ALIAS->data=1;
}	
void	WTIMER5B_Handler(void)
{
	(*Notification_Functions.GPT_Notification_GPWT5B)();
	GPWT_5_GPTMICR_BIT8_ALIAS->data=1;
}	
	
	
	
	


