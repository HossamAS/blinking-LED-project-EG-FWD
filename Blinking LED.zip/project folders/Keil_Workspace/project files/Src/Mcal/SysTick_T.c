


#include "SysTick_T.h"
#include "Mcu_Hw.h"


void (*SysTick_Notification)(void);

void SysTick_Init(void)
{
	STCTRL->data=Clock_Source;
	STCURRENT->data=0;
}

void SysTick_Handler(void)
{
	 
	 (*SysTick_Notification)();
}

