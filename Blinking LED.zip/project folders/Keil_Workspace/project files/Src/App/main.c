


#include "IntCtrl.h"
#include "ClkCtrl.h"
#include "LED.h" 
#define MAX_TIME_us 1000000ul 
#define ON_TIME_us  500000ul
#define OFF_TIME_us 500000ul

int main()
{
	IntCtrl_Init();
	ClkCtrl_Init();
	LED_Init();
	while(1)
	{
		LED_TOGGLE(ON_TIME_us,OFF_TIME_us);
	}
}



