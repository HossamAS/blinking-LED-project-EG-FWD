/*
 * IntCtrl_Cfg.h
 *
 */ 


#ifndef INTCTRL_CFG_H_
#define INTCTRL_CFG_H_
#define ENABLE  1
#define DISABLE 0


//SELECT ENABILITY STATE OF THE INTX (EN/DISABLE)

#define Memory_Management                           DISABLE
#define Bus_Fault                                   DISABLE
#define Usage Fault                                 DISABLE
#define Memory_Management_Fault                     DISABLE

#define GPIO_PORT_A                                 DISABLE       
#define GPIO_PORT_B                                 DISABLE 
#define GPIO_PORT_C                                 DISABLE 
#define GPIO_PORT_D                                 DISABLE 
#define GPIO_PORT_E                                 DISABLE 
#define UART0                                       DISABLE 
#define UART1                                       DISABLE 
#define SSI0                                        DISABLE 
#define I2C0                                        DISABLE 
#define PWM0_FAULT                                  DISABLE 
#define PWM0_GENERATOR_0                            DISABLE 
#define PWM0_GENERATOR_1                            DISABLE 
#define PWM0_GENERATOR_2                            DISABLE 
#define QEI0                                        DISABLE 
#define ADC0_SEQUANCE_0                             DISABLE 
#define ADC0_SEQUANCE_1                             DISABLE 
#define ADC0_SEQUANCE_2                             DISABLE 
#define ADC0_SEQUANCE_3                             DISABLE 
#define WATCHDOG_TIMERS_0_AND_1                     DISABLE 
#define _16_OR_32_BIT_TIMER_0A                      DISABLE 
#define _16_OR_32_BIT_TIMER_0B                      DISABLE 
#define _16_OR_32_BIT_TIMER_1A                      DISABLE 
#define _16_OR_32_BIT_TIMER_1B                      DISABLE 
#define _16_OR_32_BIT_TIMER_2A                      DISABLE 
#define _16_OR_32_BIT_TIMER_2B                      DISABLE 
#define ANALOG_COMPARATOR_0                         DISABLE 
#define ANALOG_COMPARATOR_1                         DISABLE 
#define INT27                                       DISABLE 
#define SYSTEM_CONTROL                              DISABLE 
#define FLASH_MEMORY_CONTROL_AND_EEPROM_CONTROL     DISABLE 
#define GPIO_PORT_F                                 DISABLE 
#define INT31                                       DISABLE 
#define INT32                                       DISABLE 
#define UART2                                       DISABLE 
#define SSI1                                        DISABLE 
#define _16_OR_32_BIT_TIMER_3A                      DISABLE 
#define _16_OR_32_BIT_TIMER_3B                      DISABLE 
#define I2C1                                        DISABLE 
#define QEI1                                        DISABLE 
#define CAN0                                        DISABLE 
#define CAN1                                        DISABLE 
#define INT41                                       DISABLE 
#define INT42                                       DISABLE 
#define HIBERNATION_MODULE                          DISABLE 
#define USB                                         DISABLE 
#define PWM_GENERATOR_3                             DISABLE 
#define _MICRO_DMA_SOFTWARE                         DISABLE 
#define _MICRO_DMA_ERROR                            DISABLE 
#define ADC1_SEQUENCE_0                             DISABLE 
#define ADC1_SEQUENCE_1                             DISABLE 
#define ADC1_SEQUENCE_2                             DISABLE 
#define ADC1_SEQUENCE_3                             DISABLE 
#define INT52                                       DISABLE 
#define INT53                                       DISABLE 
#define INT54                                       DISABLE 
#define INT55                                       DISABLE 
#define INT56                                       DISABLE 
#define SSI2                                        DISABLE 
#define SSI3                                        DISABLE 
#define UART3                                       DISABLE 
#define UART4                                       DISABLE 
#define UART5                                       DISABLE 
#define UART6                                       DISABLE 
#define UART7                                       DISABLE 
#define INT64                                       DISABLE 
#define INT65                                       DISABLE 
#define INT66                                       DISABLE 
#define INT67                                       DISABLE 
#define I2C2                                        DISABLE 
#define I2C3                                        DISABLE 
#define _16_OR_32_BIT_TIMER_4A                      DISABLE 
#define _16_OR_32_BIT_TIMER_4B                      DISABLE 
#define INT72                                       DISABLE 
#define INT73                                       DISABLE 
#define INT74                                       DISABLE 
#define INT75                                       DISABLE 
#define INT76                                       DISABLE 
#define INT77                                       DISABLE 
#define INT78                                       DISABLE 
#define INT79                                       DISABLE 
#define INT80                                       DISABLE 
#define INT81                                       DISABLE 
#define INT82                                       DISABLE 
#define INT83                                       DISABLE 
#define INT84                                       DISABLE 
#define INT85                                       DISABLE 
#define INT86                                       DISABLE 
#define INT87                                       DISABLE 
#define INT88                                       DISABLE 
#define INT89                                       DISABLE 
#define INT90                                       DISABLE 
#define INT91                                       DISABLE 
#define _16_OR_32_BIT_TIMER_5A                      DISABLE 
#define _16_OR_32_BIT_TIMER_5B                      DISABLE 
#define _32_OR_64_BIT_TIMER_0A                      DISABLE 
#define _32_OR_64_BIT_TIMER_0B                      DISABLE 
#define _32_OR_64_BIT_TIMER_1A                      DISABLE 
#define _32_OR_64_BIT_TIMER_1B                      DISABLE 
#define _32_OR_64_BIT_TIMER_2A                      DISABLE 
#define _32_OR_64_BIT_TIMER_2B                      DISABLE 
#define _32_OR_64_BIT_TIMER_3A                      DISABLE 
#define _32_OR_64_BIT_TIMER_3B                      DISABLE 
#define _32_OR_64_BIT_TIMER_4A                      DISABLE 
#define _32_OR_64_BIT_TIMER_4B                      DISABLE 
#define _32_OR_64_BIT_TIMER_5A                      DISABLE 
#define _32_OR_64_BIT_TIMER_5B                      DISABLE 
#define SYSTEM_EXCEPTION____IMPRECISE__             DISABLE 
#define INT107                                      DISABLE 
#define INT108                                      DISABLE 
#define INT109                                      DISABLE 
#define INT110                                      DISABLE 
#define INT111                                      DISABLE 
#define INT112                                      DISABLE 
#define INT113                                      DISABLE 
#define INT114                                      DISABLE 
#define INT115                                      DISABLE 
#define INT116                                      DISABLE 
#define INT117                                      DISABLE 
#define INT118                                      DISABLE 
#define INT119                                      DISABLE 
#define INT120                                      DISABLE 
#define INT121                                      DISABLE 
#define INT122                                      DISABLE 
#define INT123                                      DISABLE 
#define INT124                                      DISABLE 
#define INT125                                      DISABLE 
#define INT126                                      DISABLE 
#define INT127                                      DISABLE 
#define INT128                                      DISABLE 
#define INT129                                      DISABLE 
#define INT130                                      DISABLE 
#define INT131                                      DISABLE 
#define INT132                                      DISABLE 
#define INT133                                      DISABLE 
#define PWM1_GENERATOR_0                            DISABLE 
#define PWM1_GENERATOR_1                            DISABLE 
#define PWM1_GENERATOR_2                            DISABLE 
#define PWM1_GENERATOR_3                            DISABLE 
#define PWM1_FAULT                                  DISABLE


//SELECTING THE GROUP AND SUBGROUP TYPE 

#define BXXX_  0X400     //8 GROUPS  , 1 SUBGROUP
#define BXX_Y  0X500    //4 GROUPS  , 2 SUBGROUPS
#define BX_YY  0X600     //2 GROUPS  , 4 SUBGROUPS
#define B_YYY  0X700    //1 GROUP   , 8 SUBGROUPS

#define GROUPING_CONFIG   BXXX_


//SELECTING THE GROUP AND SUBGROUP TYPE FOR EVERY INTERRUPT

#if (GROUPING_CONFIG==BXXX_)

typedef	enum 
		{
			GROUP0_SUBGROUP0=0,
			GROUP1_SUBGROUP0,
			GROUP2_SUBGROUP0,
	    GROUP3_SUBGROUP0,
	    GROUP4_SUBGROUP0,
	    GROUP5_SUBGROUP0,
	    GROUP6_SUBGROUP0,
	    GROUP7_SUBGROUP0
	
	  }GROUPS_SUBGROUPS_TAG;

#endif

#if (GROUPING_CONFIG==BXX_Y)

		
typedef	enum
		{
			GROUP0_SUBGROUP0=0,
			GROUP0_SUBGROUP1,
			GROUP1_SUBGROUP0,
	    GROUP1_SUBGROUP1,
	    GROUP2_SUBGROUP0,
	    GROUP2_SUBGROUP1,
	    GROUP3_SUBGROUP0,
	    GROUP3_SUBGROUP1
	
	  }GROUPS_SUBGROUPS_TAG;


#endif

#if (GROUPING_CONFIG==BX_YY)

		
		enum
		{
			GROUP0_SUBGROUP0=0,
			GROUP0_SUBGROUP1,
			GROUP0_SUBGROUP2,
	    GROUP0_SUBGROUP3,
	    GROUP1_SUBGROUP0,
	    GROUP1_SUBGROUP1,
	    GROUP1_SUBGROUP2,
	    GROUP1_SUBGROUP3
	
	  }GROUPS_SUBGROUPS_TAG;


#endif

#if(GROUPING_CONFIG==B_YYY)



		
		enum
		{
			GROUP0_SUBGROUP0=0,
			GROUP0_SUBGROUP1,
			GROUP0_SUBGROUP2,
	    GROUP0_SUBGROUP3,
	    GROUP0_SUBGROUP4,
	    GROUP0_SUBGROUP5,
	    GROUP0_SUBGROUP6,
	    GROUP0_SUBGROUP7
	
	  }GROUPS_SUBGROUPS_TAG;


#endif


#define GPIO_PORT_A_PRI                                  GROUP0_SUBGROUP0      
#define GPIO_PORT_B_PRI                                  GROUP0_SUBGROUP0
#define GPIO_PORT_C_PRI                                  GROUP0_SUBGROUP0
#define GPIO_PORT_D_PRI                                  GROUP0_SUBGROUP0

#define GPIO_PORT_E_PRI                                  GROUP0_SUBGROUP0 
#define UART0_PRI                                        GROUP0_SUBGROUP0  
#define UART1_PRI                                        GROUP0_SUBGROUP0  
#define SSI0_PRI                                         GROUP0_SUBGROUP0 

#define I2C0_PRI                                         GROUP0_SUBGROUP0  
#define PWM0_FAULT_PRI                                   GROUP0_SUBGROUP0  
#define PWM0_GENERATOR_0_PRI                             GROUP0_SUBGROUP0  
#define PWM0_GENERATOR_1_PRI                             GROUP0_SUBGROUP0 

#define PWM0_GENERATOR_2_PRI                             GROUP0_SUBGROUP0  
#define QEI0_PRI                                         GROUP0_SUBGROUP0  
#define ADC0_SEQUANCE_0_PRI                              GROUP0_SUBGROUP0  
#define ADC0_SEQUANCE_1_PRI                              GROUP0_SUBGROUP0 

#define ADC0_SEQUANCE_2_PRI                              GROUP0_SUBGROUP0  
#define ADC0_SEQUANCE_3_PRI                              GROUP0_SUBGROUP0  
#define WATCHDOG_TIMERS_0_AND_1_PRI                      GROUP0_SUBGROUP0  
#define _16_OR_32_BIT_TIMER_0A_PRI                       GROUP0_SUBGROUP0 

#define _16_OR_32_BIT_TIMER_0B_PRI                       GROUP0_SUBGROUP0  
#define _16_OR_32_BIT_TIMER_1A_PRI                       GROUP0_SUBGROUP0  
#define _16_OR_32_BIT_TIMER_1B_PRI                       GROUP0_SUBGROUP0  
#define _16_OR_32_BIT_TIMER_2A_PRI                       GROUP0_SUBGROUP0

#define _16_OR_32_BIT_TIMER_2B_PRI                       GROUP0_SUBGROUP0  
#define ANALOG_COMPARATOR_0_PRI                          GROUP0_SUBGROUP0  
#define ANALOG_COMPARATOR_1_PRI                          GROUP0_SUBGROUP0  
#define INT27_PRI                                        GROUP0_SUBGROUP0 

#define SYSTEM_CONTROL_PRI                               GROUP0_SUBGROUP0  
#define FLASH_MEMORY_CONTROL_AND_EEPROM_CONTROL_PRI      GROUP0_SUBGROUP0  
#define GPIO_PORT_F_PRI                                  GROUP0_SUBGROUP0  
#define INT31_PRI                                        GROUP0_SUBGROUP0 

#define INT32_PRI                                        GROUP0_SUBGROUP0  
#define UART2_PRI                                        GROUP0_SUBGROUP0  
#define SSI1_PRI                                         GROUP0_SUBGROUP0  
#define _16_OR_32_BIT_TIMER_3A_PRI                       GROUP0_SUBGROUP0

#define _16_OR_32_BIT_TIMER_3B_PRI                       GROUP0_SUBGROUP0  
#define I2C1_PRI                                         GROUP0_SUBGROUP0  
#define QEI1_PRI                                         GROUP0_SUBGROUP0  
#define CAN0_PRI                                         GROUP0_SUBGROUP0

#define CAN1_PRI                                         GROUP0_SUBGROUP0  
#define INT41_PRI                                        GROUP0_SUBGROUP0  
#define INT42_PRI                                        GROUP0_SUBGROUP0  
#define HIBERNATION_MODULE_PRI                           GROUP0_SUBGROUP0 

#define USB_PRI                                          GROUP0_SUBGROUP0  
#define PWM_GENERATOR_3_PRI                              GROUP0_SUBGROUP0  
#define MICRO_DMA_SOFTWARE_PRI                           GROUP0_SUBGROUP0  
#define MICRO_DMA_ERROR_PRI                              GROUP0_SUBGROUP0

#define ADC1_SEQUENCE_0_PRI                              GROUP0_SUBGROUP0  
#define ADC1_SEQUENCE_1_PRI                              GROUP0_SUBGROUP0  
#define ADC1_SEQUENCE_2_PRI                              GROUP0_SUBGROUP0  
#define ADC1_SEQUENCE_3_PRI                              GROUP0_SUBGROUP0 

#define INT52_PRI                                        GROUP0_SUBGROUP0  
#define INT53_PRI                                        GROUP0_SUBGROUP0  
#define INT54_PRI                                        GROUP0_SUBGROUP0  
#define INT55_PRI                                        GROUP0_SUBGROUP0 

#define INT56_PRI                                        GROUP0_SUBGROUP0  
#define SSI2_PRI                                         GROUP0_SUBGROUP0  
#define SSI3_PRI                                         GROUP0_SUBGROUP0  
#define UART3_PRI                                        GROUP0_SUBGROUP0 

#define UART4_PRI                                        GROUP0_SUBGROUP0  
#define UART5_PRI                                        GROUP0_SUBGROUP0  
#define UART6_PRI                                        GROUP0_SUBGROUP0  
#define UART7_PRI                                        GROUP0_SUBGROUP0

#define INT64_PRI                                        GROUP0_SUBGROUP0  
#define INT65_PRI                                        GROUP0_SUBGROUP0  
#define INT66_PRI                                        GROUP0_SUBGROUP0  
#define INT67_PRI                                        GROUP0_SUBGROUP0

#define I2C2_PRI                                         GROUP0_SUBGROUP0  
#define I2C3_PRI                                         GROUP0_SUBGROUP0  
#define _16_OR_32_BIT_TIMER_4A_PRI                       GROUP0_SUBGROUP0  
#define _16_OR_32_BIT_TIMER_4B_PRI                       GROUP0_SUBGROUP0

#define INT72_PRI                                        GROUP0_SUBGROUP0  
#define INT73_PRI                                        GROUP0_SUBGROUP0  
#define INT74_PRI                                        GROUP0_SUBGROUP0  
#define INT75_PRI                                        GROUP0_SUBGROUP0

#define INT76_PRI                                        GROUP0_SUBGROUP0  
#define INT77_PRI                                        GROUP0_SUBGROUP0  
#define INT78_PRI                                        GROUP0_SUBGROUP0  
#define INT79_PRI                                        GROUP0_SUBGROUP0

#define INT80_PRI                                        GROUP0_SUBGROUP0  
#define INT81_PRI                                        GROUP0_SUBGROUP0  
#define INT82_PRI                                        GROUP0_SUBGROUP0  
#define INT83_PRI                                        GROUP0_SUBGROUP0

#define INT84_PRI                                        GROUP0_SUBGROUP0  
#define INT85_PRI                                        GROUP0_SUBGROUP0  
#define INT86_PRI                                        GROUP0_SUBGROUP0  
#define INT87_PRI                                        GROUP0_SUBGROUP0

#define INT88_PRI                                        GROUP0_SUBGROUP0  
#define INT89_PRI                                        GROUP0_SUBGROUP0  
#define INT90_PRI                                        GROUP0_SUBGROUP0  
#define INT91_PRI                                        GROUP0_SUBGROUP0 

#define _16_OR_32_BIT_TIMER_5A_PRI                       GROUP0_SUBGROUP0  
#define _16_OR_32_BIT_TIMER_5B_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_0A_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_0B_PRI                       GROUP0_SUBGROUP0 

#define _32_OR_64_BIT_TIMER_1A_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_1B_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_2A_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_2B_PRI                       GROUP0_SUBGROUP0

#define _32_OR_64_BIT_TIMER_3A_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_3B_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_4A_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_4B_PRI                       GROUP0_SUBGROUP0 

#define _32_OR_64_BIT_TIMER_5A_PRI                       GROUP0_SUBGROUP0  
#define _32_OR_64_BIT_TIMER_5B_PRI                       GROUP0_SUBGROUP0  
#define SYSTEM_EXCEPTION____IMPRECISE___PRI              GROUP0_SUBGROUP0  
#define INT107_PRI                                       GROUP0_SUBGROUP0 

#define INT108_PRI                                       GROUP0_SUBGROUP0  
#define INT109_PRI                                       GROUP0_SUBGROUP0  
#define INT110_PRI                                       GROUP0_SUBGROUP0  
#define INT111_PRI                                       GROUP0_SUBGROUP0 

#define INT112_PRI                                       GROUP0_SUBGROUP0  
#define INT113_PRI                                       GROUP0_SUBGROUP0  
#define INT114_PRI                                       GROUP0_SUBGROUP0  
#define INT115_PRI                                       GROUP0_SUBGROUP0  

#define INT116_PRI                                       GROUP0_SUBGROUP0  
#define INT117_PRI                                       GROUP0_SUBGROUP0  
#define INT118_PRI                                       GROUP0_SUBGROUP0  
#define INT119_PRI                                       GROUP0_SUBGROUP0  

#define INT120_PRI                                       GROUP0_SUBGROUP0  
#define INT121_PRI                                       GROUP0_SUBGROUP0  
#define INT122_PRI                                       GROUP0_SUBGROUP0  
#define INT123_PRI                                       GROUP0_SUBGROUP0  

#define INT124_PRI                                       GROUP0_SUBGROUP0  
#define INT125_PRI                                       GROUP0_SUBGROUP0  
#define INT126_PRI                                       GROUP0_SUBGROUP0  
#define INT127_PRI                                       GROUP0_SUBGROUP0 

#define INT128_PRI                                       GROUP0_SUBGROUP0  
#define INT129_PRI                                       GROUP0_SUBGROUP0  
#define INT130_PRI                                       GROUP0_SUBGROUP0  
#define INT131_PRI                                       GROUP0_SUBGROUP0 

#define INT132_PRI                                       GROUP0_SUBGROUP0  
#define INT133_PRI                                       GROUP0_SUBGROUP0  
#define PWM1_GENERATOR_0_PRI                             GROUP0_SUBGROUP0  
#define PWM1_GENERATOR_1_PRI                             GROUP0_SUBGROUP0 

#define PWM1_GENERATOR_2_PRI                             GROUP0_SUBGROUP0  
#define PWM1_GENERATOR_3_PRI                             GROUP0_SUBGROUP0  
#define PWM1_FAULT_PRI                                   GROUP0_SUBGROUP0 



































































//SELECT PENDING STATE OF THE INTX (EN/DISABLE)

//#define INT0_PEND     DISABLE       
//#define INT1_PEND     DISABLE 
//#define INT2_PEND     DISABLE 
//#define INT3_PEND     DISABLE 
//#define INT4_PEND     DISABLE 
//#define INT5_PEND     DISABLE 
//#define INT6_PEND     DISABLE 
//#define INT7_PEND     DISABLE 
//#define INT8_PEND     DISABLE 
//#define INT9_PEND     DISABLE 
//#define INT10_PEND     DISABLE 
//#define INT11_PEND     DISABLE 
//#define INT12_PEND    DISABLE 
//#define INT13_PEND     DISABLE 
//#define INT14_PEND     DISABLE 
//#define INT15_PEND     DISABLE 
//#define INT16_PEND     DISABLE 
//#define INT17_PEND     DISABLE 
//#define INT18_PEND     DISABLE 
//#define INT19_PEND     DISABLE 
//#define INT20_PEND     DISABLE 
//#define INT21_PEND     DISABLE 
//#define INT22_PEND     DISABLE 
//#define INT23_PEND     DISABLE 
//#define INT24_PEND     DISABLE 
//#define INT25_PEND     DISABLE 
//#define INT26_PEND     DISABLE 
//#define INT27_PEND     DISABLE 
//#define INT28_PEND     DISABLE 
//#define INT29_PEND    DISABLE 
//#define INT30_PEND     DISABLE 
//#define INT31_PEND     DISABLE 
//#define INT32_PEND     DISABLE 
//#define INT33_PEND     DISABLE 
//#define INT34_PEND     DISABLE 
//#define INT35_PEND     DISABLE 
//#define INT36_PEND     DISABLE 
//#define INT37_PEND     DISABLE 
//#define INT38_PEND     DISABLE 
//#define INT39_PEND     DISABLE 
//#define INT40_PEND     DISABLE 
//#define INT41_PEND     DISABLE 
//#define INT42_PEND     DISABLE 
//#define INT43_PEND     DISABLE 
//#define INT44_PEND     DISABLE 
//#define INT45_PEND     DISABLE 
//#define INT46_PEND     DISABLE 
//#define INT47_PEND     DISABLE 
//#define INT48_PEND    DISABLE 
//#define INT49_PEND     DISABLE 
//#define INT50_PEND     DISABLE 
//#define INT51_PEND     DISABLE 
//#define INT52_PEND    DISABLE 
//#define INT53_PEND     DISABLE 
//#define INT54_PEND     DISABLE 
//#define INT55_PEND     DISABLE 
//#define INT56_PEND     DISABLE 
//#define INT57_PEND     DISABLE 
//#define INT58_PEND     DISABLE 
//#define INT59_PEND     DISABLE 
//#define INT60_PEND     DISABLE 
//#define INT61_PEND     DISABLE 
//#define INT62_PEND     DISABLE 
//#define INT63_PEND     DISABLE 
//#define INT64_PEND     DISABLE 
//#define INT65_PEND     DISABLE 
//#define INT66_PEND     DISABLE 
//#define INT67_PEND     DISABLE 
//#define INT68_PEND     DISABLE 
//#define INT69_PEND     DISABLE 
//#define INT70_PEND     DISABLE 
//#define INT71_PEND     DISABLE 
//#define INT72_PEND    DISABLE 
//#define INT73_PEND     DISABLE 
//#define INT74_PEND     DISABLE 
//#define INT75_PEND     DISABLE 
//#define INT76_PEND     DISABLE 
//#define INT77_PEND     DISABLE 
//#define INT78_PEND     DISABLE 
//#define INT79_PEND     DISABLE 
//#define INT80_PEND     DISABLE 
//#define INT81_PEND     DISABLE 
//#define INT82_PEND     DISABLE 
//#define INT83_PEND     DISABLE 
//#define INT84_PEND     DISABLE 
//#define INT85_PEND     DISABLE 
//#define INT86_PEND     DISABLE 
//#define INT87_PEND     DISABLE 
//#define INT88_PEND     DISABLE 
//#define INT89_PEND     DISABLE 
//#define INT90_PEND     DISABLE 
//#define INT91_PEND     DISABLE 
//#define INT92_PEND     DISABLE 
//#define INT93_PEND     DISABLE 
//#define INT94_PEND     DISABLE 
//#define INT95_PEND     DISABLE 
//#define INT96_PEND    DISABLE 
//#define INT97_PEND     DISABLE 
//#define INT98_PEND     DISABLE 
//#define INT99_PEND     DISABLE 
//#define INT100_PEND     DISABLE 
//#define INT101_PEND     DISABLE 
//#define INT102_PEND     DISABLE 
//#define INT103_PEND     DISABLE 
//#define INT104_PEND    DISABLE 
//#define INT105_PEND     DISABLE 
//#define INT106_PEND     DISABLE 
//#define INT107_PEND     DISABLE 
//#define INT108_PEND     DISABLE 
//#define INT109_PEND     DISABLE 
//#define INT110_PEND     DISABLE 
//#define INT111_PEND     DISABLE 
//#define INT112_PEND     DISABLE 
//#define INT113_PEND     DISABLE 
//#define INT114_PEND    DISABLE 
//#define INT115_PEND     DISABLE 
//#define INT116_PEND     DISABLE 
//#define INT117_PEND     DISABLE 
//#define INT118_PEND     DISABLE 
//#define INT119_PEND     DISABLE 
//#define INT120_PEND     DISABLE 
//#define INT121_PEND    DISABLE 
//#define INT122_PEND     DISABLE 
//#define INT123_PEND     DISABLE 
//#define INT124_PEND     DISABLE 
//#define INT125_PEND     DISABLE 
//#define INT126_PEND     DISABLE 
//#define INT127_PEND     DISABLE 
//#define INT128_PEND     DISABLE 
//#define INT129_PEND     DISABLE 
//#define INT130_PEND     DISABLE 
//#define INT131_PEND     DISABLE 
//#define INT132_PEND     DISABLE 
//#define INT133_PEND     DISABLE 
//#define INT134_PEND     DISABLE 
//#define INT135_PEND     DISABLE 
//#define INT136_PEND     DISABLE 
//#define INT137_PEND     DISABLE 
//#define INT138_PEND     DISABLE 





#endif /* INTCTRL_CFG_H_ */
