
/*
 * Std_Types.h
 *
 * Created: 16/03/2019 12:12:03 ?
 *  Author: hossam
 */ 


#ifndef STD_TYPES_H_
#define STD_TYPES_H_


typedef char INT8_C ;
typedef unsigned char UINT8_C;
typedef signed char   SINT8_C;
typedef volatile char VINT8_C ;
typedef volatile unsigned char VUINT8_C;
typedef volatile signed char   VSINT8_C;

typedef short INT16_S ;
typedef unsigned short UINT16_S;
typedef signed short   SINT16_S;
typedef volatile short VINT16_S ;
typedef volatile unsigned short VUINT16_S;
typedef volatile signed short   vSINT16_S;

typedef int INT16_I ;
typedef unsigned int UINT16_I;
typedef signed int   SINT16_I;
typedef volatile int VINT16_I ;
typedef volatile unsigned int VUINT16_I;
typedef volatile signed int   vSINT16_I;

typedef long INT32_L ;
typedef unsigned long UINT32_L;
typedef signed long   SINT32_L;
typedef volatile long VINT32_L ;
typedef volatile unsigned long VUINT32_L;
typedef volatile signed long   vSINT32_L;

typedef long long INT64_L ;
typedef unsigned long long UINT64_LL;
typedef signed long long   SINT64_LL;
typedef volatile long long VINT64_LL ;
typedef volatile unsigned long long VUINT64_LL;
typedef volatile signed long long   vSINT64_LL;

typedef long int int64_L ;
typedef unsigned long int UInt64_LI;
typedef signed long int   SINT64_LI;
typedef volatile long int VINT64_LI ;
typedef volatile unsigned long int VUInt64_LI;
typedef volatile signed long int   vSINT64_LI;

typedef float FLOAT32_F ;
typedef volatile float VFLOAT32_F ;

typedef double FLOAT64_F ;
typedef volatile double VFLOAT64_F ;

 

	


#endif /* STD_TYPES_H_ */
