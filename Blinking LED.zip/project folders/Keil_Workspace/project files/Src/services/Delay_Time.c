#include "Delay_Time.h"
#include "SysTick_T.h"
#include "Mcu_Hw.h"
#include "GPT.h"


UINT8_C flag=DIS;

void Delay_us_init(void)
{
  SysTick_Init();
	extern void(*SysTick_Notification)(void);
	SysTick_Notification=Delay_ISR;
}



void Delay_us(UINT32_L Match)
{
	SysTick_Notification_Enable();
	SysTick_SetTickValue(Match);
	STCURRENT->data=0;
	SysTick_Enable();
	while(flag==DIS);
	SysTick_Disable();
	flag=DIS;
	
	
}


void Delay_ISR(void)
{
	flag=EN;
}
