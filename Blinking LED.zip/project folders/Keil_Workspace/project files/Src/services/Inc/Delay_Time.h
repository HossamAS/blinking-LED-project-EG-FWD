
/*
 * Delay_Time.h
 *
 * Created: 
 *  Author: hossam
 */ 


#ifndef DELAY_TIME_H_
#define DELAY_TIME_H_
#include "Std_Types.h"

void Delay_us_init(void);
void Delay_us(UINT32_L Match);
void Delay_ISR(void);

#endif /* DELAY_TIME_H_ */


