




#include "LED.h"
#include "Port.h"
#include "Std_Types.h"
#include "Delay_Time.h"
void LED_Init(void)
{
  Port_Config arr[1];
	arr->Port=PortA;
	arr->PinType.PortA_Pins=PortA_Pin0;
	arr->PinMode.PortA.A0=DIO_A0;
	arr->PinLevel=LOW;
	arr->PinDirection=Output;
	arr->OutputCurrent.PortA_OutputCurrent.Pin0OutputCurrent=_8mA;
	arr->InternalAttach.PortA_InternalAttach.Pin0InternalAttach=PullDown;	
	Port_Init(arr);
	Delay_us_init();
}

void LED_TOGGLE(UINT32_L OnTime,UINT32_L OffTime)
{
	 Dio_FlipChannel(PortA_Pin0_);
	Delay_us((UINT32_L)(((FLOAT32_F)(OnTime))*16.777215f));
	 Dio_FlipChannel(PortA_Pin0_);
	Delay_us((UINT32_L)(((FLOAT32_F)(OffTime))*16.777215f));
 
	
}
