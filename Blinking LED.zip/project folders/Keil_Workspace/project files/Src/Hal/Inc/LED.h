/*
 * LED.h
 *
 * Created: 
 *  Author: hossam
 */ 


#ifndef LED_H_
#define LED_H_

#include "Port.h"
#include "DIO.h"
void LED_Init(void);
void LED_TOGGLE(UINT32_L OnTime,UINT32_L OffTime);
#endif /* LED_H_ */
